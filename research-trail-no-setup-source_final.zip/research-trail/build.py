"""Bundle one offline-capable QM app; Live service remains separate."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parent

def build():
    static = ROOT / 'static'
    template = (static / 'app.template.html').read_text(encoding='utf-8')
    values = {
        '__STYLE__': (static / 'workspace.css').read_text(encoding='utf-8') + (static / 'trail-base.css').read_text(encoding='utf-8') + (static / 'trail-merge.css').read_text(encoding='utf-8'),
        '__TRAIL_MARKUP__': (static / 'trail-markup.html').read_text(encoding='utf-8'),
        '__TRAIL_ADAPTER__': (static / 'trail-adapter.js').read_text(encoding='utf-8'),
        '__TRAIL_FLOW__': (static / 'trail-flow.js').read_text(encoding='utf-8'),
        '__GUIDE__': (ROOT / 'docs/user-guide.json').read_text(encoding='utf-8').replace('<', r'\u003c'),
        '__VISUALS__': (static / 'visuals.js').read_text(encoding='utf-8'),
        '__DEMO__': (static / 'demo-provider.js').read_text(encoding='utf-8'),
        '__QUANTUM__': (static / 'quantum-data.js').read_text(encoding='utf-8'),
        '__CANVAS__': (static / 'canvas.js').read_text(encoding='utf-8'),
        '__WORKSPACE__': (static / 'workspace.js').read_text(encoding='utf-8'),
    }
    for key, value in values.items():
        assert template.count(key) == 1, key
        template = template.replace(key, value)
    (static / 'index.html').write_text(template, encoding='utf-8')
    for name in ('research-trail-quantum-demo.html', 'research-trail-no-setup-demo.html'):
        (ROOT.parent / name).write_text(template.replace('<head>', '<head><script>window.__TRAIL_DEMO_DEFAULT__=true;</script>', 1), encoding='utf-8')
        print(f'Built {name}: {len(template.encode()):,} bytes')

if __name__ == '__main__':
    build()
