# Deployment

## Local or a small group

Use Python 3.11+ and the supplied `start.bat` or `start.sh`. The backend binds to `127.0.0.1:8765` by default, creates a local SQLite database under `data/`, and serves the built HTML. API configuration reads UTF-8 explicitly on Windows.

Configure an existing Ollama or compatible inference service. Set `MODEL_PROVIDER`, `MODEL_BASE_URL` and `MODEL_NAME` to prefill the UI. API keys use `MODEL_API_KEY` or per-role variants. Optional paper discovery uses `BOND_TOKEN`; Crossref remains the fallback. Uploaded PDFs are extracted with `pypdf`, in an isolated subprocess with time and memory limits where supported.

## Shared workers

The supplied Compose configuration runs PostgreSQL, an API process and a worker. Set `POSTGRES_PASSWORD` and `TRAIL_API_TOKEN` in your local environment or an untracked `.env`, then run:

```bash
docker compose up --build -d
docker compose up --scale worker=3 -d
```

Inference is a separate service. Inside a container, `127.0.0.1` refers to that container; use the inference service's reachable hostname. Set `TRAIL_ALLOWED_ORIGINS` to your frontend origin when serving separately. Open the UI and enter the shared service URL/token. Remote serving does not inject the token into a public HTML response.

Place externally reachable installations behind TLS and an authenticated gateway. The prototype uses a shared service token and project namespaces; it does not implement organization roles or private per-user authorization.

## Optional self-hosted media discovery

A `search` Compose profile is supplied for SearXNG. Replace the development secret in `config/searxng-settings.yml`, set `TRAIL_SEARCH_URL=http://search:8080`, and run:

```bash
docker compose --profile search up --build -d
```

JSON output must be enabled in SearXNG. See [its API documentation](https://docs.searxng.org/dev/search_api.html). Alternatively set `YOUTUBE_API_KEY` on the worker/API environment. External search engines may return no results or throttle requests; those states remain visible and do not become fabricated resources.

## Resilience

- The database stores both guide jobs and full reviews.
- Workspace-scoped idempotency keys prevent duplicate job creation on request retry.
- Workers claim queued jobs transactionally.
- Run cancellation stops between tasks, not inside an active inference call.
- Restarting the API does not erase completed or paused jobs.
- An interrupted running job requires explicit stale recovery: `python -m backend.server --recover-stale`.
- Stale recovery may repeat a partially completed stage; it is not exactly-once execution.
- Back up the database. The optional Bond JSON cache is a retrieval optimization, not the authoritative project record.

## Verification

Run the commands in README before packaging. The included checks cover SQLite, HTTP, PDF extraction, queue behavior and controlled model/retrieval contracts. PostgreSQL, Docker services, external providers and browser rendering still need deployment-specific verification.
