# Research Trail · quantum mechanics demo

A visual literature and research-question workspace. The rebuild follows `DESIGN.md` and the matching user guide in `docs/user-guide.json`. It uses one document and one project across all three experience levels.

## Open the complete demo

Open **research-trail-quantum-demo.html**. The original three-road landing page asks **I’m finding my direction**, **I already have a topic**, and **I have papers to build on**. Choose a road or select **Start quantum mechanics demo** to begin Discovery. No server, model, account or API key is required. The source package also contains `static/index.html`, which can be opened directly.

- **Beginner:** field and topic billboards → learning cards → shared workspace. **Discover** (step 1) introduces ideas with large visual cards; **Map** (step 3) connects concepts to papers. Then explore broad questions and export a field guide.
- **Intermediate:** topic → subtopic choice → exactly three scope questions in Explore → suggested directions → optional papers/instructions → Landscape → Connections → Question → Review. Existing subtopic entry remains available.
- **Advanced:** Papers → Question → Explore. Prepare papers before the map appears beside the exact-question form. The investigation unlocks all 12 tools.

Use the persistent level switch to keep the same project, papers, notes and selected question. The first entry to each level opens its billboards. **My billboards** restores that route’s draft; the logo returns to all three roads. Interview answers and instructions reach the Live review agents. **Guide** contains the complete walkthrough, a four-minute recording plan and narration. **Reset demo** prepares a clean recording. Theme preferences persist.

The broad map covers states, measurement, dynamics, simple systems, entanglement, open systems and applications. The worked research thread follows decoherence into error mitigation, with calibration drift and complete sampling costs as an illustrative focused question.

## What is prepared and what is real

The demo has 12 real curated teaching, paper and software records. Four records contain short, explicitly labeled abstract excerpts checked against their linked primary pages. Complete papers were not read for the prepared demo. Thematic graph connections are curated inferences rather than verified citation edges. No venue grades, journal quartiles or repository popularity values are invented.

The separate **Illustrative benchmark** analysis context contains eight synthetic studies. It populates the eight lenses without attributing toy measurements to real papers. Curated literature and synthetic measurements do not share a measurement corpus. Benchmark records are excluded from real-evidence exports.

Prepared landscape labels demonstrate a scoped judgment; they are not a current saturation survey. A gap report distinguishes background passages, closest work, missing evidence, counter-search and uncertainty. The prepared candidate is not verified novel. The optional experiment is a proposal, not an executed result.

Demo PDF attachments retain filenames only. Their contents are neither read nor uploaded. Use Live for indexing your own documents.

## Research tools

The full workspace exposes Field map, Starting papers, Learning trail, Research scope, Literature, Paper connection graph, Eight gap lenses, Review notebook, Candidate gaps, First experiments, Agent activity and Master controls. Beginner and Intermediate have smaller guided navigation.

The graph supports topic/venue regions, relationship filters, selectable nodes and lines, source inspection, pinning, zoom and pan. Inferred links are dashed. Eight lenses show evidence coverage, method combinations, claim comparison, evaluation coverage, tradeoffs, research-to-implementation links, limitation timelines and method/context boundaries.

Fullscreen moves the actual panel into an app-root dialog. For the original billboards, it moves the whole trail root so delegated forms keep working through agent runs and subsequent billboards. Content fills the available width and height; longer forms scroll. Billboards, maps, charts, notebook, source records and setup/help dialogs can expand. Filters, selections and zoom preserve expansion. Escape restores the panel and focus. Small screens scroll dense maps and matrices rather than clipping them. The Intermediate axis caption is outside its SVG, below wrapped topic labels and status badges. Advanced also has a mobile picker exposing all 12 tools.

Export the field guide as Markdown, project evidence as JSON or the paper map as SVG. Notes save locally as you type. Access tokens and indexed PDF text are excluded from browser preference storage.

## Connect Live

Open **Setup & models**. Choose **Local Ollama**, **Rented API** or **Public or shared endpoint**. Enter both the research-service connection and the inference connection, then use **Test connection** and **Connect Live**.

The Ollama starter preset is `qwen3.5:9b`. Install the inference server and model separately. A public/shared option needs an operating endpoint from its administrator; the demo does not include a free hosted inference service. Provider keys stay on the backend.

Switching to Live clears prepared sources and outputs before loading a real corpus. A failed Live job stays failed and never turns into Demo data. **Use demo** restores the prepared project. The server version remembers Live selection and restores jobs after reconnecting. The two standalone demo HTMLs deliberately start in Demo.

### Run the service

Use `start.bat` on Windows or `bash start.sh` on Linux/macOS. Alternatively:

```bash
python -m venv .venv
# Activate the environment for your shell.
python -m pip install -r requirements.txt
python -m backend.server
```

Open the printed HTTP address. Local serving prefills the service URL and token. Model-provider credentials are environment variables on the backend:

```text
MODEL_PROVIDER=ollama
MODEL_BASE_URL=http://127.0.0.1:11434
MODEL_NAME=qwen3.5:9b
MODEL_API_KEY=optional-rented-provider-key
BOND_TOKEN=optional-bond-token
GITHUB_TOKEN=optional-token
TRAIL_SEARCH_URL=optional-searxng-url
YOUTUBE_API_KEY=optional-video-search-key
```

Role-specific keys use `MODEL_API_KEY_COORDINATOR`, `MODEL_API_KEY_READER`, etc. Master controls routes each specialist independently and accepts up to three custom specialists. The ranking specialist wraps deterministic scoring; it needs no LLM. Several roles can share one served model.

## When the agents work

Discovery, learning resources, landscape building, question investigation and experiment requests trigger bounded tasks. Opening another view reuses project results.

The coordinator scopes the review. The scout retrieves foundations before the frontier. The QM profile is journal-led; the existing computing profile remains conference-first. A full review asks the user to choose conferences or keep a broader scope after the foundational pass. Ranking, reading, mapping, gap investigation, targeted counter-search, skeptical review and an optional experiment plan follow.

**Bond is a Source Scout discovery tool.** The connected adapter uses it for foundations, recent papers and prior art, with a local query cache. Crossref enriches missing bibliographic data and is the fallback. Bond is not the model or coordinator. Software discovery uses GitHub stars and actual subscriber counts separately.

Conference A*/A/B eligibility requires a supplied dated registry. Q1/Q2 journal eligibility uses the included SJR index when matched, with ranking provenance. Preprints from prior-art searches remain labeled. Unknown rankings remain unknown and strict policy excludes them from claim evidence. Ranking is reading triage based on venue metadata, relevance, citations/recency or repository stars; it is not study-quality assessment.

Live retrieval currently indexes available metadata and abstracts. Supplied PDFs are indexed separately. The pilot does not automatically fetch every open full text, enforce open-access licensing end to end, or crawl wikis. Sources retain visible access/provenance states.

## Evidence checks and run isolation

Runs see their own discoveries, explicitly selected existing records and project PDFs. They do not absorb an unrelated earlier topic merely because it shares a workspace. `/api/sources?run_id=...` checks run ownership and returns that corpus.

Quote matching tolerates Unicode typography, whitespace and ordered ellipsis fragments. It rejects changed wording/numbers, wrong pages and short fragments. Measurements require a matching passage containing the number from the same source. Background/profile documents cannot support scientific claims. A passage match verifies provenance; it does not establish entailment, exhaustive search or novelty.

Tradeoff cohorts require matching task, dataset, platform, protocol and baseline. Unknown protocols and incompatible metric units do not merge. Empty cells are unknown in this corpus, not automatically research gaps.

## Build and verify

```bash
python build.py
python -m unittest discover -s tests -p "test_*.py"
node tests/frontend.cjs
node tests/trail.cjs
node tests/visuals.cjs
node tests/demo.cjs
node tests/experience.cjs
```

The final verification covers 48 Python tests and five Node suites. It includes SQLite concurrency, real local HTTP/PDF extraction, source isolation, provenance/numeric gates, all journeys, eight lenses, exports, cancellation, model contracts and fullscreen DOM behavior.

Node interaction tests use a small DOM harness and do not measure rendered layout. `node tests/browser.cjs` is an optional Playwright check for a machine with Chromium installed. This workspace had no browser binary, so rendered browser layout, external inference/retrieval and PostgreSQL/Docker deployment were not verified.

The restored landing/billboards are compiled in `static/trail-markup.html`, `trail-base.css` and `trail-flow.js`. `trail-adapter.js` connects them to the current evidence workspace. `trail-merge.css` controls the integrated visual polish. `restore_trail.py` can re-extract these assets from the supplied legacy trail; ordinary builds do not need to run it.

## Source and deployment

`static/quantum-data.js` contains the curated QM pack and labels. `canvas.js` renders SVG views; `visuals.js` contains pure evidence projections; `workspace.js` owns journeys, job triggers, persistence and exports. `build.py` bundles all assets and the in-app guide into a single HTML without a CDN. The teammate landing page can later feed the same shared project state.

See `ARCHITECTURE.md`, `DEPLOYMENT.md` and `THIRD_PARTY_NOTICES.md`. App code is MIT. Models, paper content, ranking datasets and infrastructure components retain their own terms. The supplied SJR data requires a redistribution-terms review before a public release. Shared deployments use a durable queue and can use PostgreSQL workers; organization identity and per-user authorization remain a production integration task.
