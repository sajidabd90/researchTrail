# Research Trail quantum mechanics design

This specification records the comprehensive design agreed in the conversation, including the later clarifications about Bond, model connections, ranking, source selection and research-gap depth. The user guide is the interaction contract for the rebuild. Date: 22 October 2026.

## Product and shared project

Research Trail helps users understand a field, connect its literature and develop a question they can defend with evidence. The complete demonstration domain is quantum mechanics. One project owns its topic, selected concepts, papers, source versions, extracted passages, claims, connections, questions, notes, reviews and agent runs. Changing experience level changes the guidance and starting point while preserving that project.

The main workspace contains a project header, persistent level switch, visible journey steps, central visual canvas, context panels and an agent-progress strip. Onboarding and research tools live in the same document; an embedded trail does not control navigation or fullscreen positioning.

## User journeys and exact entry labels

Preserve the supplied three-road landing, its starting questions and physical billboard journey. Its signs are I’m finding my direction (Beginner), I already have a topic (Intermediate), and I have papers to build on (Advanced). The primary entry action is Start quantum mechanics demo. Demo uses prepared QM content and is explicit about scripted analysis; Live uses the authenticated backend and real retrieval/model tasks.

Beginner steps: Discover, Learn, Map, Open questions, Field guide. The discovery billboards choose a field and topic and build visual learning cards. They hand off to the shared map. Within the workspace, Discover uses illustrated intuition cards, while Map shows concepts, source papers and connections; steps 1 and 3 must remain visually and functionally distinct. Unfold papers and their relationships. Broad open questions link back to relevant concepts and literature. Export a field guide. A beginner may finish without a narrow research gap.

Intermediate steps: Focus, Landscape, Connections, Question, Review. Choose an area such as Open systems and decoherence. Preserve the subtopic choice, exactly three visual scope questions in Explore, suggested directions, confirmation and optional context billboard. Carry the complete answers and instructions into the review agents. Inspect scoped labels Well explored, Active, Emerging and Uncertain. Every label explains its basis and search limitations. Wrap node labels, place status badges below them, and keep the orientation caption outside the SVG. Scroll the chart at narrow sizes instead of shrinking its text. Select a boundary, inspect its paper connections, formulate a candidate question and inspect a skeptical review. Publication count alone never establishes saturation.

Advanced steps: Papers, Question, Explore. Prepare up to 15 PDFs or use the prepared QM paper pack in Demo. For an existing project, current papers can be selected without losing notes. The paper map appears after papers are prepared. Enter an exact question beside the map. Investigate this question opens all 12 workspace tools. Subsequent exploration is unguided. Keep all 12 tools and eight lenses accessible, including through a mobile tool picker. My billboards returns to the same route draft.

## The shared QM example

The broad map includes states and wavefunctions, measurement, dynamics, simple quantum systems, entanglement, open systems and applications. The worked research thread follows decoherence into error mitigation. The prepared advanced question is: Under a fixed total sampling budget, when does combining readout mitigation and zero-noise extrapolation improve estimates as calibration drifts?

This is an illustrative candidate question. The demo does not certify novelty. Real curated paper metadata and teaching links are distinguished from illustrative measurements and scripted agent activity. Synthetic benchmark records never become extracted results attributed to real papers.

## Agent workflow

Coordinator -> discovery and access checks -> ranking and reading -> shared evidence graph -> learning, landscape or candidate-gap output -> counter-search and skeptical review -> optional experiment plan. Roles can share one model. Ranking and source validation use deterministic checks where possible.

Explicit triggers: starting discovery, preparing papers, investigating a question, checking a gap and requesting an experiment. Navigation reuses results. Agent progress explains current work and its output. Runs can be cancelled, resumed where supported, and inspected. Live failures remain visible failures and never become demo results.

Default roles are coordinator, scout, ranker, reader and learning guide, mapper, gap and landscape investigator, skeptical reviewer and experiment designer. The ranking specialist wraps the existing scoring service with a source-linked explanation rather than presenting a single score as scientific quality.

Bond is the preferred connected paper-discovery tool used by the Source Scout. Foundations, recent research and counter-searches use this boundary. Crossref enriches missing bibliographic metadata and is a fallback. Bond supplies available metadata and abstracts; access to full text is checked separately.

## Source policy

Learning begins with open books, notes, selected wikis and older work. The frontier uses field-relevant journals and conferences. Conference A*/A/B grades require a named ranking registry and year. Journal Q1/Q2 grades require ranking provenance. The QM profile is journal-led; a computing profile retains conference-first ordering. Preprints form a labeled prior-art lane. Software sources retain license and popularity information.

User-facing source states distinguish metadata only, abstract indexed, PDF text indexed, citation passage matched, inferred relationship and scripted illustration. Passage matching proves provenance; it does not establish entailment, study quality or novelty. Source access and license uncertainty remain explicit. The SJR dataset redistribution issue in the uploaded change log remains an outstanding distribution check.

## Graph and eight lenses

The field map shows concepts and prerequisites; selecting a concept unfolds its papers. The paper connection graph shows typed citation, method, finding, evaluation and implementation relationships. Group by topic or venue. Venue grouping has colored labeled regions. Supported and inferred relations remain distinguishable. Filters, source inspection, keyboard selection, zoom and pan preserve context.

All eight lenses remain: evidence coverage, method combinations, claim comparison, evaluation coverage, tradeoff frontier, research to implementation, limitation timeline and boundary map. Every view uses the selected project and scope. Comparable measurement cohorts require matching task, dataset/circuit family, platform, protocol, units and baseline. Illustrative data has its own labeled analysis context and is excluded from real evidence exports.

## Twelve tools and guidance

The full workspace retains Field map, Starting papers, Learning trail, Research scope, Literature, Paper connection graph, Eight gap lenses, Review notebook, Candidate gaps, First experiments, Agent activity and Master controls. Beginner and Intermediate expose smaller guided navigation plus contextual entry to connections and sources. Advanced exposes all tools after its two entry steps.

Candidate statuses distinguish prepared example, candidate, reviewed within searched scope, already addressed and insufficient evidence. Reports include supporting passages, closest prior work, counterevidence, scope, limitations and an optional first test. Broad beginner questions and intermediate landscape judgments use the same evidence system.

## Models and deployment

The proposed starter preset is Qwen3.5-9B via Ollama. It is a preset, not a promise that the model is installed or scientifically validated. Compatible rented APIs and operator-configured public/shared endpoints are supported through the backend. A zero-setup Live service needs a running hosted endpoint. The offline demo needs no model or key. API keys remain on the backend; browser persistence excludes access tokens and PDF contents.

SQLite and the existing durable worker queue serve the pilot. Shared deployments can use the existing PostgreSQL path and more workers. Identity, authorization and third-party service/data terms must be assessed before a production multi-group deployment.

## Fullscreen and accessibility

Research panels and billboards expand at the app root, outside transformed or clipped ancestors. Content, SVGs and scroll areas reflow with the viewport. Escape and the visible Exit fullscreen control restore the prior position and focus. Panel state survives supported interactions. Keyboard access, readable text, large targets, responsive layout and reduced-motion preferences apply across all paths.

## Delivery and verification

Deliver an editable user guide with the exact interaction flow, seven-shot four-minute storyboard and narration; a complete no-setup QM HTML demo; and a source package. Reconcile the uploaded branch's run-specific source isolation, typography-tolerant quote matching and stage focus with the current numeric/provenance checks. Preserve tested behavior through integration tests rather than replacing the backend wholesale.

Verify all three journeys, project continuity, 12 tools, eight populated demo lenses, honest data labels, backend run isolation, quote/numeric evidence gates, cancellation, exports and demo/live separation. Attempt real-browser checks for layout and fullscreen when a browser runtime is available; report any unavailable verification accurately. The app and guide must use the same labels and steps before delivery.
