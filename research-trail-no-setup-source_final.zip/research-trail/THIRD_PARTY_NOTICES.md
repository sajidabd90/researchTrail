# Attribution and source boundaries

The rebuilt workspace, SVG renderers, guide and coordinator integration use the accompanying MIT license. The original project includes Lucide/Feather notices, retained in `LICENSE-LUCIDE.txt`; the rebuilt UI uses code-native SVG and text symbols without an icon CDN.

`pypdf`, optional `psycopg`, PostgreSQL, Python, Docker images, inference servers and model weights retain their own licenses. Qwen3.5-9B is a configurable model preset; no weights or hosted credentials are bundled. Valency Bond and bibliographic services have their own access and service terms.

Curated records contain bibliographic metadata, original editorial summaries and external links. Four records contain short, attributed excerpts from their primary abstract pages, identified in `static/quantum-data.js`. These are background excerpts, not redistributed full papers. Course and repository links do not redistribute those resources. Synthetic benchmark records are explicitly fictional.

The included SJR index was supplied in the user's backend materials. It is data, not application code, and is not relicensed under MIT. Its redistribution terms need review before a public release. Conference grades require a separate dated registry; no conference ranking dataset is invented.

Uploaded PDFs and runtime databases are excluded from the source distribution. User-requested research exports can include indexed quotations and notes. They do not automatically export the original PDFs or browser access tokens.
