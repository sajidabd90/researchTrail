/* MIT. Curated QM metadata; prepared interpretations are labeled, never extracted findings. */
(function(root){'use strict';
const QUESTION='Under a fixed total sampling budget, when does combining readout mitigation and zero-noise extrapolation improve estimates as calibration drifts?';
const clone=x=>JSON.parse(JSON.stringify(x));
// Short excerpts checked against the linked primary abstract pages. These
// support background only; no complete paper was read for this demonstration.
const excerpts={
 q_temme:'Two schemes are presented that mitigate the effect of errors and decoherence in short depth quantum circuits.',
 q_li:'The impact of such errors is minimised by boosting them artificially and then extrapolating to the zero-error case.',
 q_review:'This review surveys the diverse methods that have been proposed for quantum error mitigation, assesses their in-principle efficacy',
 q_mitiq:'Mitiq is an extensible toolkit of different error mitigation methods, including zero-noise extrapolation, probabilistic error cancellation, and Clifford data regression.'
};
function corpus(){
 const refs=root.ResearchDemo.project('Quantum mechanics').sources.filter(s=>s.kind==='reference');
 const extra=[
  ['q_mit','MIT 8.04','Quantum Physics I · open course',2013,'foundation','MIT OpenCourseWare','https://ocw.mit.edu/courses/8-04-quantum-physics-i-spring-2013/','Wave mechanics, the Schrödinger equation and introductory quantum systems.'],
  ['q_zurek','Zurek · decoherence','Decoherence, einselection, and the quantum origins of the classical',2003,'journal','Reviews of Modern Physics','https://arxiv.org/abs/quant-ph/0105127','A foundation for studying how a system and its environment become correlated.'],
  ['q_shor','Shor · factoring','Algorithms for quantum computation: discrete logarithms and factoring',1994,'conference','FOCS 1994','https://doi.org/10.1109/SFCS.1994.365700','A historical conference contribution linking quantum computation to factoring and discrete logarithms.'],
  ['q_stim_repo','Stim implementation','Stim · stabilizer circuit simulator',null,'repository','Google Quantum AI / GitHub','https://github.com/quantumlib/Stim','Open implementation for stabilizer simulation. This is a software record, not a hardware deployment.']
 ].map(([id,name,title,year,source_type,venue,url,summary])=>({id,name,title,year,source_type,venue,url,summary,kind:'reference',eligible:false,foundational:source_type==='foundation',provenance:'curated_quantum_metadata',rank_status:'unverified',pages:[]}));
 return [...refs,...extra].map(s=>({...s,pages:excerpts[s.id]?[{page:0,text:excerpts[s.id],excerpt:true}]:[],
  provenance:excerpts[s.id]?'curated_short_abstract_excerpt':s.provenance,
  checked_at:excerpts[s.id]?'2026-10-22':undefined,
  access:'Linked resource; complete paper not indexed',ranking_note:'No conference tier or journal quartile asserted in Demo'}));
}
const concepts=[
 {id:'states',title:'States and wavefunctions',short:'States',symbol:'ψ',color:'#c4d8fa',x:300,y:116,simple:'A quantum state encodes what you can predict about a system.',technical:'State vectors, amplitudes, superposition and density operators.',prerequisites:['Complex numbers','Linear algebra'],source_ids:['q_mit','q_preskill'],children:['Superposition','State space','Density operators']},
 {id:'measurement',title:'Measurement and probability',short:'Measurement',symbol:'|ψ|²',color:'#ebc8d9',x:718,y:114,simple:'Measurement turns amplitudes into probabilities for possible outcomes.',technical:'Observables, the Born rule, projective measurement and generalized measurements.',prerequisites:['States and wavefunctions'],source_ids:['q_mit','q_preskill'],children:['Born rule','Observables','Uncertainty']},
 {id:'dynamics',title:'Quantum dynamics',short:'Dynamics',symbol:'iℏ',color:'#d8ccf2',x:876,y:310,simple:'The Hamiltonian describes how a closed quantum system evolves in time.',technical:'Schrödinger evolution, unitary operators and time dependence.',prerequisites:['States and wavefunctions','Differential equations'],source_ids:['q_mit','q_preskill'],children:['Schrödinger equation','Hamiltonians','Time evolution']},
 {id:'systems',title:'Simple quantum systems',short:'Simple systems',symbol:'Eₙ',color:'#ecd9ad',x:735,y:510,simple:'Start with a particle in a box, an oscillator or spin to make the equations concrete.',technical:'Spectra, bound states, tunneling, angular momentum and spin.',prerequisites:['Measurement and probability','Quantum dynamics'],source_ids:['q_mit'],children:['Particle in a box','Harmonic oscillator','Spin and tunneling']},
 {id:'applications',title:'Quantum applications',short:'Applications',symbol:'H⊗H',color:'#c1ded8',x:308,y:510,simple:'Use quantum behavior for information, sensing, simulation and computation.',technical:'Algorithms, controlled systems, near-term devices and fault tolerance.',prerequisites:['Entanglement and correlations','Quantum dynamics'],source_ids:['q_shor','q_nisq','q_stim','q_mitiq_repo'],children:['Quantum algorithms','Sensing','Simulation and codes']},
 {id:'open',title:'Open systems and decoherence',short:'Open systems',symbol:'ρ',color:'#f3c4ac',x:130,y:312,simple:'Real systems interact with their environment. Those interactions change the coherence we can observe.',technical:'Quantum channels, decoherence, dephasing, relaxation and the assumptions behind noise models.',prerequisites:['States and wavefunctions','Measurement and probability'],source_ids:['q_zurek','q_preskill','q_nisq','q_temme','q_li','q_review'],children:['Decoherence','Noise models','Error mitigation']},
 {id:'entanglement',title:'Entanglement and correlations',short:'Entanglement',symbol:'⊗',color:'#cddda9',x:505,y:308,simple:'The state of a composite system can contain correlations that separate states cannot describe.',technical:'Tensor products, reduced states, Bell correlations and information.',prerequisites:['States and wavefunctions','Measurement and probability'],source_ids:['q_preskill','q_mit','q_stim'],children:['Composite systems','Bell correlations','Quantum information']}
];
const prerequisites=[['states','measurement'],['states','dynamics'],['measurement','systems'],['dynamics','systems'],['states','entanglement'],['measurement','open'],['entanglement','applications'],['dynamics','applications'],['open','applications']];
const relationships=[
 ['q_mit','q_preskill','learning','Complementary learning resources: wave mechanics and quantum information.'],
 ['q_preskill','q_nisq','lineage','Connects general quantum-information concepts to near-term device questions. This is a thematic teaching link.'],
 ['q_zurek','q_review','lineage','Environmental noise provides background for understanding the assumptions of mitigation methods.'],
 ['q_temme','q_li','shared method','Both discuss extrapolation approaches to controlling the effect of imperfect operations.'],
 ['q_temme','q_review','shared method','The review surveys mitigation families including extrapolation.'],
 ['q_li','q_review','shared method','The review provides context for variational simulation and mitigation approaches.'],
 ['q_review','q_mitiq','implementation','Moves from a survey of mitigation methods to a software toolkit.'],
 ['q_temme','q_mitiq','implementation','A method-to-tool connection for zero-noise extrapolation.'],
 ['q_mitiq','q_mitiq_repo','implementation','The paper and linked toolkit describe the same named software project.'],
 ['q_stim','q_stim_repo','implementation','The simulator paper and its linked open implementation.'],
 ['q_nisq','q_mitiq','related finding','Both motivate working with noisy near-term computations; this is an inferred thematic connection.'],
 ['q_shor','q_preskill','lineage','Historical algorithmic motivation alongside broader quantum-computation foundations.'],
 ['q_stim','q_preskill','evaluation','Stabilizer methods connect to the notes on quantum error correction; this does not imply general-circuit simulation.']
].map(([a,b,type,rationale],i)=>({id:'qm-edge-'+i,a,b,type,rationale,status:'inferred',evidence:[],provenance:'Curated thematic inference; no citation passage checked'}));
const taxonomy=[
 {name:'Foundations',source_ids:['q_mit','q_preskill','q_zurek']},
 {name:'Near-term computation',source_ids:['q_nisq','q_shor']},
 {name:'Error mitigation',source_ids:['q_temme','q_li','q_review','q_mitiq']},
 {name:'Simulation and software',source_ids:['q_stim','q_mitiq_repo','q_stim_repo']}
];
const landscape=[
 {title:'Closed-system evolution',status:'Well explored',reason:'The standard unitary evolution of specified closed systems is established teaching background. This label is scoped to those models, not all quantum dynamics.',source_ids:['q_mit','q_preskill'],x:140,y:340},
 {title:'Decoherence models',status:'Well explored',reason:'A mature conceptual framework links environmental interactions to loss of observable coherence. Particular many-body and non-Markovian settings still require separate investigation.',source_ids:['q_zurek'],x:360,y:260},
 {title:'Error mitigation',status:'Active',reason:'Prepared direction: compare assumptions, statistical overhead and implementation across methods. The linked review is a starting point; this fixture is not a current systematic survey.',source_ids:['q_temme','q_li','q_review','q_mitiq'],x:565,y:190},
 {title:'Mitigation under calibration drift',status:'Emerging',reason:'Illustrative focus chosen to demonstrate a bounded search. The demo has not established the maturity or novelty of this real-world topic.',source_ids:['q_review','q_mitiq'],x:740,y:315},
 {title:'Transfer to a device family',status:'Uncertain',reason:'No device-specific study was read in this demo. A simulator result and a public repository are insufficient to establish hardware performance.',source_ids:['q_stim','q_mitiq_repo'],x:840,y:125}
];
const broadQuestions=[
 {title:'Where does classical behavior come from?',question:'How do interactions with the environment change which quantum effects remain observable?',why:'Connects states, measurement and decoherence.',source_ids:['q_zurek','q_preskill'],concept:'open'},
 {title:'What can we learn from entanglement?',question:'Which correlations are useful for information processing and which survive noise?',why:'Connects composite states to experimental and computational questions.',source_ids:['q_preskill','q_nisq'],concept:'entanglement'},
 {title:'How can noisy experiments stay informative?',question:'When does error mitigation improve an estimate enough to justify its extra sampling?',why:'Introduces bias, variance and finite resources before choosing a narrow question.',source_ids:['q_review','q_temme','q_mitiq'],concept:'open'},
 {title:'What can a simulation tell us?',question:'Which conclusions depend on the simulator’s assumptions and which need experiments?',why:'Connects simple systems, computational methods and evidence limits.',source_ids:['q_stim','q_nisq'],concept:'applications'}
];
const candidateQuestions=[
 {title:'Calibration drift × complete sampling budget',question:QUESTION,rationale:'A bounded candidate for testing the interaction of method composition, changing noise and sampling costs. The prepared map does not show that prior work leaves this unanswered.',source_ids:['q_review','q_temme','q_li','q_mitiq'],status:'Prepared example',scope:{system:'Small GHZ circuits',method:'Readout mitigation + zero-noise extrapolation',outcome:'Bias, variance and total estimator error',constraint:'Fixed total shots, including calibration'},evidence:[]},
 {title:'Noise-model transfer',question:'Which mitigation rankings survive when coherent errors replace a stationary stochastic noise model under a matched budget?',rationale:'Tests a change of assumptions while keeping the circuit family and budget fixed.',source_ids:['q_review','q_mitiq'],status:'Prepared example',evidence:[]},
 {title:'Recalibration cadence',question:'When does recalibrating more frequently improve total estimation error after calibration shots are included?',rationale:'A resource-accounting direction; closest prior work and hardware feasibility remain unchecked.',source_ids:['q_review','q_mitiq'],status:'Prepared example',evidence:[]}
];
function prepared(){
 const claims=[
  ['q_temme','The abstract presents mitigation schemes for errors and decoherence in short circuits.'],
  ['q_li','The abstract describes amplification of errors followed by extrapolation to a zero-error case.'],
  ['q_review','The review surveys mitigation methods and their in-principle efficacy.'],
  ['q_mitiq','The toolkit includes multiple named mitigation methods.']
 ].map(([source_id,text])=>({text,evidence:[{source_id,page:0,quote:excerpts[source_id],status:'curated_abstract_excerpt'}],status:'curated_background'}));
 const candidates=clone(candidateQuestions);
 candidates[0].evidence=[claims[0].evidence[0],claims[2].evidence[0]];
 return {sources:corpus(),concepts:clone(concepts),edges:clone(relationships),outputs:{'mapper:map':{taxonomy:clone(taxonomy),edges:clone(relationships)},'reader:curated-background':{verified_claims:claims},'gaps:gaps':{candidates}},landscape:clone(landscape),questions:clone(broadQuestions),candidates,learning:root.ResearchDemo.learning(root.ResearchDemo.project('Quantum mechanics'))};
}
function illustration(){const p=root.ResearchDemo.project('Quantum mechanics');return {sources:p.sources.filter(s=>s.kind==='synthetic'),outputs:p.outputs,context:'Illustrative benchmark · synthetic study records, never measurements from the curated papers'};}
const api={QUESTION,concepts,prerequisites,prepared,illustration,clone};root.QuantumTrail=api;if(typeof module!=='undefined')module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
