
/* ============================================================================
 * RESEARCH TRAIL — THREE ROADS / AGENT BACKEND / INSIGHTS PAGE
 *
 * This file is embedded in the delivered HTML. The frontend owns the path,
 * questions, selections, uploads, and final search brief. It does NOT own the
 * graph renderer or the live research agents.
 *
 * Ctrl+F landmarks:
 *   INTEGRATION-A = teammate implementing agents
 *   INTEGRATION-B = teammate implementing the separate Insights workspace
 *   STATE / VIEWS / EVENTS = the guided billboard experience
 *   WORLD = preserved first-person camera and scenery
 *
 * Demo mode is functional offline. No research has been run for this version.
 * Fictional readings have natural titles and summaries, with a single Demo label
 * in the header. They have no invented citations, authors, or outbound links.
 * No uploaded document is parsed and no bulk paper search runs in this mode.
 * ========================================================================== */
(() => {
  'use strict';
  const root = document.getElementById('research-trail-first-person');
  const screen = root.querySelector('#rt-screen');

  /* [INTEGRATION-A] AGENT BACKEND CONTRACT
   * Configure before startup via window.ResearchTrailConfig, or afterward with:
   *
   * ResearchTrail.configure({ mode: 'live', agents: {
   *   async discoverTopics(request, options) { ... },
   *   async personalizeTopics(request, options) { ... },
   *   async getLearningResources(request, options) { ... },
   *   async narrowTopic(request, options) { ... },
   *   async createResearchJob(request, options) { ... }
   * }});
   *
   * All methods return Promises. options contains:
   *   signal: AbortSignal; honor it during requests/upload/polling.
   *   onProgress(message): plain-text status for the current billboard.
   *   files: { profile: [{id,file:File}], papers: [{id,file:File}] }.
   * requests contain JSON metadata, NOT document bytes. Your adapter can upload
   * the File objects using FormData and return server asset IDs in its response.
   * Never put an API secret in this HTML; call your own authenticated backend.
   *
   * discoverTopics / personalizeTopics -> {
   *   topics: [{id,title,simple,technical,whyNow,papers:[{id,title,year,url,summary}]}],
   *   sourceNote: string, sourceMode: 'live'|'demo'
   * }
   * personalizeTopics additionally receives interests, workHistory, skills,
   * profile-document metadata, and the previous topic IDs. Analyze the documents
   * server-side; do not claim to have read them from their filenames.
   * It also receives personalizationRound, feedback, profileAnswers, and rejected
   * topic IDs. Return followUpQuestions to keep guiding the user after another
   * rejection. There is no maximum number of rounds or automatic selection.
   *
   * getLearningResources({topic,field,...},options) -> {
   *   introduction:string, goals:string[], papers:Resource[], books:Resource[],
   *   videos:Resource[], sourceNote:string
   * }
   * Resource = {id,title,url,description,level,placeholder?:boolean}.
   * Use verified resource metadata and URLs in live mode. Beginner stops HERE;
   * it does not call narrowTopic, createResearchJob, or open Insights.
   *
   * narrowTopic({phase:'questions', topic, ...}) -> {
   *   questions: [{id,label,help,type:'choice'|'text'|'select',
   *     options:[{value,label,description}],required:true}]
   * Options can also be plain strings. Requests include answers + questionIndex.
   * }
   * narrowTopic({phase:'suggestions',topic,answers,round,refinement,...}) -> {
   *   candidates: [{id,title,question,technical,simple,why,scope:{task,system,objective},keywords:[],papers:Resource[]}],
   *   followUpQuestions:Question[],
   *   sourceNote: string
   * }
   * If the result is still broad, another round includes the previous candidate
   * and the user's refinement. These are proposed scopes, NOT verified gaps.
   *
   * createResearchJob(brief,options) -> {jobId:string,status:string}
   * Persist the entire brief with that job. Start your large literature search
   * asynchronously. The Insights page owns progress, results, and visualizations.
   * Use brief.clientRequestId as an idempotency key: retries must not create
   * duplicate expensive searches. The frontend reuses an existing successful job
   * until the brief changes.
   */
  const config = Object.assign({
    mode: 'demo',
    yearRange: { from: 2025, to: 2026 },
    agents: null,
    insightsPageMount: null,
    insightsPageUnmount: null,
    insightsPageUrl: '',
    graphPageMount: null, // Older integration names remain valid aliases.
    graphPageUnmount: null,
    graphPageUrl: '',
    guideAssistant: null, // Optional: async (question, context, {signal}) => {answer}.
    demoDelayMs: 220
  }, window.ResearchTrailConfig || {});

  /* [STATE] THREE INDEPENDENT ITINERARIES, on three non-converging roads.
   * Beginner: field -> discovery/personalization loop -> learning pack -> END.
   * Intermediate: topic -> standalone subtopic choice -> narrowing/confirmation
   * -> standalone papers/instructions question -> optional additions -> workspace.
   * Advanced: papers/notes/instructions -> final search.
   * Both intermediate and advanced end with the fade to the separate Insights page.
   * The Topic route always asks whether to add context; the additions are optional.
   * Discovery has no such question. history records actual physical stops, while
   * subtopic and context-choice phases preserve their own Back behavior.
   */
  const stepNames = ['Choose your start', 'Choose your field', 'Explore the field', 'Narrow your topic', 'Papers & context', '', 'Your learning pack', 'Your research question'];
  const stepTypes = ['Starting point', 'Field', 'Discovery · 2025–2026', 'Research scope', 'Search context', '', 'Learning resources', 'A precise starting point'];
  const routeConfig = {
    discover: { entry: 1, stages: [0,1,2,6], label: 'Discovery route' },
    topic: { entry: 3, stages: [0,3,4], label: 'Topic route' },
    papers: { entry: 4, stages: [0,4,7], label: 'Papers route' }
  };
  const state = {
    step: 0, route: 'discover', history: [0], broad: '', field: '',
    topics: [], mapPhase: 'overview', sourceNote: '',
    personalizationRound: 0, feedback: '', rejectedTopicIds: [],
    profileQuestions: [], profileAnswers: {}, learningData: null,
    interests: [], otherInterests: '', workHistory: '', skills: '',
    topic: '', selectedTopic: null,
    narrowPhase: 'entry', questionIndex: 0, knownDirection: '', subtopicChoice: '', scopeTopic: '', questions: [], answers: {}, candidates: [],
    refinement: '', round: 0, chosenCandidate: null, specificTopic: '', narrowFollowUps: [],
    notes: '', instructions: '', exactQuestion:'', paperPreview:null, samplePack:'', previewTopic:'',
    busy: null, error: '', retryable: false, job: null, revision: 0, clientRequestId: '',
    contextSkipped: false, contextPhase: 'choice', contextChoice: '', graphOpen: false
  };
  const files = { profile: new Map(), papers: new Map() };
  const initialState=JSON.stringify(state), routeDrafts=new Map();
  let walking = false, journeyWorld = null, activeRequest = null, handoffInFlight = false;
  let requestSerial = 0, lastTask = null, lastViewKey = '';
  const fieldGroups = {
    Engineering: ['Computer engineering', 'Electrical engineering', 'Mechanical engineering', 'Biomedical engineering'],
    Computing: ['Computer science', 'Software engineering', 'Information systems'],
    'Physical sciences': ['Quantum mechanics', 'Physics', 'Chemistry'],
    Science: ['Biology', 'Earth science'],
    'Another field': []
  };

  /* [DEMO CONTENT — FICTIONAL READINGS, NATURAL PRODUCT COPY]
   * This is make-believe content for demonstrating the finished experience.
   * Paper/book/video titles below are fictional, with no invented authors, DOI,
   * dates, or source links. The visible header says Demo; individual rows read
   * like a real product instead of repeating implementation notes to the user.
   * placeholder:true remains an INTERNAL data flag so fictional readings never
   * enter the live research brief as verified references. Do not remove that flag.
   */
  function demoPaper(id, subject, title, summary) {
    return {id,title:title||subject+': Methods, tradeoffs, and a practical evaluation',year:null,url:'',placeholder:true,
      summary:summary||'Introduces the main approaches, compares their assumptions, and works through a small example to make the design choices concrete.'};
  }
  const exampleTopics = [
    {id:'edge',title:'Adaptive edge AI',simple:'Let a small device spend more effort on difficult inputs and less on easy ones. A camera might recognize a clear image quickly, then use a deeper model for a difficult scene.',technical:'Input-dependent execution changes model depth, active modules, or numerical precision under latency, energy, and memory constraints.',whyNow:'The interesting question is how to choose the right amount of computation without losing reliability when the inputs change.',papers:[demoPaper('edge-a','adaptive edge inference','Learning When to Think: Dynamic Inference on Small Devices','A gentle introduction to early exits and input-dependent model depth, with an image-classification example.'),demoPaper('edge-b','adaptive inference','Adaptive Vision Under a Changing Power Budget','Compares fixed and adaptive execution when a battery-powered camera has limited energy.')]},
    {id:'lowbit',title:'Low-bit models and efficient inference',simple:'Use fewer bits to store and compute with a model. The challenge is keeping useful accuracy while reducing memory and computation.',technical:'Quantization changes the numerical representation of weights and activations. Its system-level benefits depend on operator support, memory traffic, and the target hardware.',whyNow:'A smaller model is only useful if it also runs well on the device. This direction connects numerical choices to actual deployment costs.',papers:[demoPaper('lowbit-a','low-bit inference','Small Numbers, Useful Models: A Guide to Low-Bit Inference','Explains weights, activations, quantization error, and the difference between reducing model size and speeding up execution.'),demoPaper('lowbit-b','low-bit inference','Mixed Precision for Memory-Limited Edge Models','Explores assigning different numerical precision to different layers under a fixed memory budget.')]},
    {id:'systems',title:'Computer architecture and heterogeneous systems',simple:'Combine different computing units so each handles the work it does best. The difficult part is moving data and coordinating the pieces efficiently.',technical:'Study workload mapping, interconnects, memory hierarchies, and CPU–accelerator scheduling in heterogeneous systems.',whyNow:'Moving data between computing units can cancel the benefit of faster computation. Good research questions often begin with that mismatch.',papers:[demoPaper('systems-a','heterogeneous systems','Where Should the Work Run? A Guide to Heterogeneous Computing','Uses a small CPU–accelerator system to explain mapping, communication costs, and shared memory.'),demoPaper('systems-b','workload mapping','Workload Mapping with Memory Movement in Mind','Compares mapping strategies when memory traffic becomes the main bottleneck.')]},
    {id:'security',title:'Embedded security and trustworthy hardware',simple:'Help a device protect sensitive data and keep working when software, inputs, or physical conditions cannot be fully trusted.',technical:'Explore isolation, hardware trust boundaries, side-channel leakage, and the security/performance tradeoffs of embedded protection mechanisms.',whyNow:'Small devices have limited resources for protection. This creates useful questions about which defenses are effective and affordable.',papers:[demoPaper('security-a','embedded security','Trust at the Edge: An Introduction to Embedded Security','Introduces threat models and hardware/software trust boundaries through a connected-device example.'),demoPaper('security-b','hardware isolation','Lightweight Isolation for Resource-Constrained Controllers','Compares ways of protecting sensitive work while limiting memory and execution overhead.')]},
    {id:'robotics',title:'Intelligent embedded and robotic systems',simple:'Connect sensing and decisions to a machine that acts in the real world. A good decision also has to arrive in time to be useful.',technical:'Study perception, estimation, control, real-time scheduling, and constrained inference as parts of one embodied system.',whyNow:'Algorithms that work in isolation can behave differently inside a moving robot. Timing and coordination make this an interesting systems problem.',papers:[demoPaper('robotics-a','embedded robotics','From Sensor to Action: An Introduction to Embedded Robotics','Follows the path from a sensor measurement to a control action and explains the role of timing.'),demoPaper('robotics-b','robot perception','Perception and Control with a Shared Computing Budget','Explores how a mobile robot can divide limited processing time between seeing and acting.')]},
    {id:'design',title:'Digital design and reconfigurable computing',simple:'Build or reshape hardware around the computation a task needs. You can trade flexibility for better speed, energy use, or predictability.',technical:'Study programmable logic, dataflow architectures, hardware mapping, and runtime reconfiguration under resource constraints.',whyNow:'The mapping from an algorithm to a dataflow architecture often matters as much as the algorithm itself.',papers:[demoPaper('design-a','reconfigurable computing','Thinking in Dataflow: A First Guide to FPGA Acceleration','Explains pipelines, parallelism, and memory interfaces using a small streaming design.'),demoPaper('design-b','hardware mapping','Mapping Adaptive Workloads onto Reconfigurable Hardware','Compares fixed and reconfigurable implementations when the amount of work varies with the input.')]}
  ];

  /* [HELPERS] User text is always escaped; backend data is treated as text too.
   * Outbound paper links accept HTTP(S) only. The graph URL is trusted developer
   * configuration, never inferred from a paper or a user-entered instruction.
   */
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const clean = value => String(value ?? '').trim();
  function id() { return window.crypto?.randomUUID?.() || 'rt-' + Date.now() + '-' + Math.random().toString(36).slice(2); }
  function icons(){for(const el of root.querySelectorAll('[data-lucide]')){el.textContent=({compass:'◉',telescope:'⌕',files:'▤',route:'∿','message-circle':'?'}[el.dataset.lucide]||'◇');el.setAttribute('aria-hidden','true');}}
  function button(label, action, primary=false, attrs='') {
    return `<button type="button" class="rt-button cursor-interaction ${primary?'rt-primary':''}" data-action="${esc(action)}" ${attrs}>${label}</button>`;
  }
  function textField(label, name, value='', placeholder='', multiline=false, required=false) {
    const attrs=`data-bind="${esc(name)}" ${required?'required':''} placeholder="${esc(placeholder)}"`;
    return `<label class="rt-field">${esc(label)}${multiline?`<textarea ${attrs} rows="3">${esc(value)}</textarea>`:`<input ${attrs} value="${esc(value)}">`}</label>`;
  }
  function choice(value, kind, selected=false) {
    return `<button type="button" class="rt-chip cursor-interaction" data-${kind}="${esc(value)}" aria-pressed="${selected}">${esc(value)}</button>`;
  }
  function safeLink(value) { try {const u=new URL(value);return ['http:','https:'].includes(u.protocol)?u.href:'';} catch {return '';} }
  function modeNote() { return ''; } // The header carries the single unobtrusive Demo label.
  function routeStages() { return routeConfig[state.route].stages; }
  function changed() { state.revision++;state.job=null;state.clientRequestId='';state.error='';state.retryable=false; config.onDraftChange?.(snapshot()); }
  function fileMetadata(bucket) { return Array.from(files[bucket],([key,file])=>({id:key,name:file.name,size:file.size,type:file.type,lastModified:file.lastModified,role:bucket==='profile'?'background':'seed-paper'})); }
  function allFileObjects() { return Object.fromEntries(Object.entries(files).map(([bucket,map])=>[bucket,Array.from(map,([key,file])=>({id:key,file}))])); }
  // A skipped context draft remains editable, but is excluded from the final job.
  function researchFiles() {const selected=allFileObjects();if(state.route==='topic'&&state.contextChoice==='skip')selected.papers=[];return selected;}
  function uploads(bucket, label) {
    const accept='.pdf';
    return `<label class="rt-field">${esc(label)}<input type="file" data-upload="${bucket}" accept="${accept}" multiple></label><div class="rt-upload-list">${fileMetadata(bucket).map(f=>`<div class="rt-upload-row"><span>${esc(f.name)} <small class="rt-muted">${Math.max(1,Math.round(f.size/1024))} KB</small></span><button type="button" class="rt-textbutton cursor-interaction" data-remove-file="${esc(f.id)}" data-bucket="${bucket}" aria-label="Remove ${esc(f.name)}">Remove</button></div>`).join('')}</div>`;
  }

  /* [BRIEF] Versioned JSON handoff shared by both teammates.
   * Uploaded File bytes are deliberately separate. Backend asset IDs can be
   * added by the adapter. Do not put raw document contents in query strings.
   * No gap is declared here; gap analysis belongs to the graph/research pipeline.
   */
  function buildBrief() {
    const skipContext=state.route==='topic'&&state.contextChoice==='skip';
    return {
      schemaVersion:'research-trail.brief.v1',
      clientRequestId:state.clientRequestId || null,
      route:{discover:'beginner',topic:'intermediate',papers:'advanced'}[state.route],
      field:state.field || null,
      discoveryWindow:{...config.yearRange},
      broadTopic:state.topic || null,
      specificTopic:state.specificTopic || null,
      researchQuestion:(state.route==='papers'?state.exactQuestion:state.chosenCandidate?.question || state.specificTopic) || null,
      demoPack:state.samplePack || null,
      scopeAnswers:{...state.answers},
      interests:[...new Set([...state.interests,...(clean(state.otherInterests)?[clean(state.otherInterests)]:[])])],previousWork:state.workHistory,skills:state.skills,
      personalizationRound:state.personalizationRound,feedback:state.feedback,
      profileAnswers:{...state.profileAnswers},rejectedTopicIds:[...state.rejectedTopicIds],
      notes:skipContext?'':state.notes,instructions:skipContext?'':state.instructions,
      profileDocuments:fileMetadata('profile'),seedPapers:skipContext?[]:fileMetadata('papers'),
      discoveryPapers:(state.selectedTopic?.papers || []).filter(p=>!p.placeholder).map(p=>({...p})),
      narrowingRounds:state.round,
      contextWasSkipped:state.contextSkipped,
      searchIntent:{kind:state.route==='discover'?'beginner-learning-resources':'comprehensive-literature-search',deduplicate:true,retainSourceEvidence:true},
      createdAt:new Date().toISOString()
    };
  }

  /* [AGENT ADAPTER] One async boundary for every future agent call.
   * Requests can be aborted, failed calls can be retried, stale completions are
   * ignored, and live mode never silently falls back to fabricated demo results.
   */
  async function runAgent(operation, request, success, message) {
    if(state.busy) return;
    // Enforce ownership in the adapter too: beginner never launches final research.
    if(state.route==='discover'&&['narrowTopic','createResearchJob'].includes(operation))return;
    if(state.route!=='discover'&&['discoverTopics','personalizeTopics','getLearningResources'].includes(operation))return;
    const serial=++requestSerial, controller=new AbortController();
    activeRequest=controller;lastTask={operation,request,success,message};
    state.error='';state.retryable=false;state.busy={operation,message};render();
    try {
      const provider=config.mode==='demo'?demoAgents:(config.agents || window.ResearchTrailAgents);
      if(typeof provider?.[operation]!=='function') throw new Error('The research service is not connected for this step yet.');
      const result=await provider[operation](request,{
        signal:controller.signal,files:operation==='createResearchJob'?researchFiles():allFileObjects(),
        onProgress:text=>{if(serial===requestSerial&&state.busy){state.busy.message=clean(text);const el=root.querySelector('#rt-agent-progress');if(el)el.textContent=state.busy.message;}}
      });
      if(controller.signal.aborted||serial!==requestSerial)return;
      state.busy=null;activeRequest=null;
      await success(result);
    } catch(error) {
      if(serial!==requestSerial)return;
      state.busy=null;activeRequest=null;
      if(error?.name!=='AbortError'){state.error=error?.message || 'The research request could not finish. Please try again.';state.retryable=true;}
      render();
    }
  }
  function cancelRequest() { if(activeRequest)activeRequest.abort();requestSerial++;activeRequest=null;state.busy=null;state.retryable=false; }
  function normalizedTopics(result) {
    if(!result||!Array.isArray(result.topics))throw new Error('The research service returned an incomplete topic map.');
    return result.topics.slice(0,12).map((t,index)=>({
      ...t,id:clean(t.id)||'topic-'+index,title:clean(t.title),simple:clean(t.simple),technical:clean(t.technical),whyNow:clean(t.whyNow),
      papers:Array.isArray(t.papers)?t.papers.filter(p=>p&&clean(p.title)&&(safeLink(p.url)||((config.mode==='demo'||config.simulation)&&p.placeholder))).slice(0,5):[]
    })).filter(t=>t.title);
  }
  function discoveryRequest() { return {...buildBrief(),field:state.field,yearRange:{...config.yearRange}}; }
  function fetchMap(personalized=false) {
    state.mapPhase='overview';
    return runAgent(personalized?'personalizeTopics':'discoverTopics',{
      ...discoveryRequest(),previousTopicIds:state.topics.map(t=>t.id)
    },result=>{
      state.topics=normalizedTopics(result);state.sourceNote=clean(result.sourceNote);
      state.profileQuestions=Array.isArray(result.followUpQuestions)?result.followUpQuestions.slice(0,4):[];
      render();
    },config.mode==='demo'?'Exploring directions in your field…':'Mapping recent research and finding example papers…');
  }
  /* [BEGINNER ENDPOINT] Learning resources are the end of this road, not a
   * shortcut into intermediate narrowing. The user studies, then later chooses
   * the Intermediate road themselves. No research job or Insights handoff here.
   */
  function fetchLearningPack() {
    return runAgent('getLearningResources',{...buildBrief(),topic:state.topic},result=>{
      if(!result||!['papers','books','videos'].every(k=>Array.isArray(result[k])))throw new Error('The learning pack needs papers, books, and videos. Please try again.');
      state.learningData={lectureSearchUrl:clean(result.lectureSearchUrl),introduction:clean(result.introduction),goals:Array.isArray(result.goals)?result.goals.map(clean):[],sourceNote:clean(result.sourceNote)};
      for(const kind of ['papers','books','videos'])state.learningData[kind]=Array.isArray(result[kind])?result[kind].filter(r=>r&&clean(r.title)).slice(0,8):[];
      render();
    },config.mode==='demo'?'Putting together your reading path…':'Finding accessible papers, books, and videos for your topic…');
  }
  function normalizeQuestion(q,i) {
    return {...q,id:clean(q.id)||'q'+i,label:clean(q.label),help:clean(q.help),type:['choice','select'].includes(q.type)?q.type:'text',required:q.required!==false,
      options:Array.isArray(q.options)?q.options.map(o=>typeof o==='string'?option(o,o):option(clean(o.value||o.label),clean(o.label||o.value),clean(o.description))):[]};
  }
  async function prepareNarrowing() {
    state.narrowPhase='questions';
    return runAgent('narrowTopic',{...buildBrief(),phase:'questions',topic:state.topic,answers:{...state.answers},questionIndex:state.questionIndex},result=>{
      if(!Array.isArray(result?.questions)||!result.questions.length)throw new Error('The research service did not return any questions. Please try again.');
      state.questions=result.questions.slice(0,3).map(normalizeQuestion);
      state.questionIndex=Math.min(state.questionIndex,state.questions.length-1);
      render();
    },'Finding a useful next question…');
  }
  function narrowAgain() {
    state.round++;
    return runAgent('narrowTopic',{
      ...buildBrief(),phase:'suggestions',topic:state.topic,answers:{...state.answers},
      round:state.round,refinement:state.refinement,previousCandidate:state.chosenCandidate,
      previousCandidates:state.candidates,followUpAnswers:{...state.answers}
    },result=>{
      if(!Array.isArray(result?.candidates)||!result.candidates.length)throw new Error('No specific research directions were returned. Try changing the scope.');
      state.candidates=result.candidates.slice(0,4).map((c,i)=>({...c,id:clean(c.id)||'scope-'+i,title:clean(c.title),question:clean(c.question),technical:clean(c.technical),simple:clean(c.simple),why:clean(c.why),scope:c.scope&&typeof c.scope==='object'?c.scope:{},keywords:Array.isArray(c.keywords)?c.keywords.map(clean):[],papers:Array.isArray(c.papers)?c.papers:[]})).filter(c=>c.title&&c.question);
      state.narrowFollowUps=Array.isArray(result.followUpQuestions)?result.followUpQuestions.slice(0,4):[];
      if(!state.candidates.length)throw new Error('The suggested directions need a title and a specific research question.');
      state.narrowPhase='candidates';render();
    },'Connecting your scope to more specific research directions…');
  }

  /* [TRAIL-GUIDE] OPTIONAL SIDE CHAT, SEPARATE FROM RESEARCH INPUTS
   * This is a small website-style helper, opened from the chat icon. It explains
   * the current step and terms; messages never become search instructions, change
   * a choice, or launch research. This replaces the old per-billboard prompt strip.
   * Demo replies are local FAQ/example responses. Optional agent connection:
   * ResearchTrail.configure({guideAssistant: async (question,context,{signal}) =>
   *   ({answer:'Plain text reply'})});
   * Context includes the active route/step/topic/question, not document bytes or
   * profile history. The Insights page owns its own interface after the fade.
   */
  const guideState={open:false,draft:'',messages:[],busy:false,serial:0,controller:null};
  function guideContext() {
    return {route:routeConfig[state.route].label,step:stepNames[state.step],stepId:state.step,
      topic:state.specificTopic||state.topic||state.field||'',
      question:state.narrowPhase==='questions'?state.questions[state.questionIndex]?.label||'':'',
      phase:state.step===3?state.narrowPhase:state.step===2?state.mapPhase:state.step===4?state.contextPhase:'',
      answers:state.step===3?{...state.answers}:{}};
  }
  function renderGuide() {
    const widget=root.querySelector('#rt-guide-widget'),panel=root.querySelector('#rt-guide-panel'),launcher=root.querySelector('#rt-guide-launcher');
    if(!widget||!panel||!launcher)return;
    widget.hidden=state.graphOpen||handoffInFlight;
    panel.hidden=!guideState.open;
    launcher.setAttribute('aria-expanded',String(guideState.open));
    root.querySelector('#rt-guide-context').textContent=state.step===0?'Choosing a starting route':stepNames[state.step];
    const log=root.querySelector('#rt-guide-log');
    log.innerHTML=guideState.messages.length?guideState.messages.map(m=>`<div class="rt-guide-message rt-guide-${m.role}"><span class="rt-guide-speaker">${m.role==='user'?'You':'Trail guide'}</span><p>${esc(m.text)}</p></div>`).join(''):'<div class="rt-guide-message rt-guide-assistant"><span class="rt-guide-speaker">Trail guide</span><p>Need a term explained, help choosing an option, or a sense of what comes next? Ask me here.</p></div>';
    if(guideState.busy)log.innerHTML+='<p class="rt-micro rt-muted" role="status">Thinking…</p>';
    log.scrollTop=log.scrollHeight;
    root.querySelector('#rt-guide-quick').innerHTML=['What does this step do?','I’m not sure what to choose','What happens next?'].map(q=>`<button type="button" class="cursor-interaction" data-guide-question="${esc(q)}" ${guideState.busy?'disabled':''}>${esc(q)}</button>`).join('');
    root.querySelector('#rt-guide-send').disabled=guideState.busy;
    root.querySelector('#rt-guide-input').disabled=guideState.busy;
  }
  function toggleGuide(open) {
    guideState.open=open;renderGuide();
    if(open)root.querySelector('#rt-guide-input')?.focus?.();else root.querySelector('#rt-guide-launcher')?.focus?.();
  }
  function demoGuideReply(question,context) {
    const text=question.toLowerCase();
    if(/quantiz|low.bit|precision/.test(text))return 'Quantization uses fewer numerical bits to represent a model’s values. It can reduce storage and memory traffic, but you need to check how accuracy and actual device performance change. A useful research direction is deciding which parts of a model need more precision.';
    if(/early exit|dynamic depth/.test(text))return 'An early exit lets a model produce an answer before using all of its layers. Easy inputs can finish early; difficult ones continue deeper. The research question is when to stop, and how to balance saved computation against mistakes.';
    if(/edge ai/.test(text))return 'Edge AI means running useful AI computation close to the device or sensor, such as on a camera or embedded computer. Memory, energy, and response time often matter alongside accuracy.';
    if(/fpga/.test(text))return 'An FPGA is programmable digital hardware. You can shape pipelines and parallel computation around a task, then measure the speed, energy use, memory traffic, and hardware resources the design needs.';
    if(/gap|novel|original/.test(text))return 'A proposed research question is a starting point. Its novelty and the evidence for a gap need to be checked against the literature. The connected research workspace is where you will examine papers, limitations, and their relationships.';
    if(/upload|file|cv|transcript|paper/.test(text)&&!/next/.test(text))return state.route==='discover'?'If the first topics do not appeal to you, choose “Nothing here catches my attention.” You can share your interests and previous work there, with an optional CV, transcript, report, or paper. The demo keeps attachments in this browser session.':'You can add papers, notes, and instructions before starting the literature search. On the Topic route those additions are optional; on the Papers route they are your starting point. The demo keeps attachments in this browser session.';
    if(state.step===0)return 'Choose Discovery route if you want help finding a direction, Topic route if you have an area to explore, or Papers route if you want to build on work you already have. Each road has its own steps.';
    if(state.route==='discover'&&state.step===6)return 'Take time to read and watch the introductory resources. When you are ready, return to the trailhead and choose “I already have a topic” on the Topic route to develop a focused research question.';
    if(state.route==='discover'&&state.step===1)return 'Choose a broad field, then a discipline that feels close to your interests. For example: Engineering, then Computer engineering. You can also write a field that is not listed.';
    if(state.route==='discover')return 'Open a topic to read its core idea, a more technical explanation, and a few example papers. Choose one you would enjoy learning about. If none appeals to you, share your interests and previous work so the next suggestions have more context.';
    if(state.route==='topic'&&state.step===3&&state.narrowPhase==='entry')return 'Write the broad area that interests you. The next question lets you either enter a subtopic you already have or choose Explore for guided help finding one.';
    if(state.route==='topic'&&state.step===3&&state.narrowPhase==='subtopic')return 'Choose “I have a subtopic” to write a more specific idea or research question. If you would like help discovering one, choose Explore and we will work through a few concrete choices together.';
    if(state.route==='topic'&&state.step===3&&state.narrowPhase==='questions')return 'Choose the option that feels most interesting, even if you are new to the terminology. “I’m not sure yet” is a useful answer too: it keeps several directions open. Your choices help shape the subtopics suggested next.';
    if(state.route==='topic'&&state.step===3&&state.narrowPhase!=='confirm')return 'Read a suggested question and compare its technical and plain-language explanations. You can choose a direction, ask for different suggestions, or return to the guided questions. There is no limit on exploring.';
    if(state.route==='topic'&&state.step===3)return 'Continue to the next question to decide whether you would like to add papers or instructions. You can then enter the main research workspace to explore papers, their connections, and research insights.';
    if(state.route==='topic'&&state.step===4&&state.contextPhase==='choice')return 'Choose Yes if you want to add papers, notes, or instructions. Choose No if your research question is enough. The final action opens the main research workspace, where the literature, connections, and insights come together.';
    return 'Attach papers you want to build on, add notes about what interests you, and include any instructions that should guide the research. A research goal or useful notes can also be enough to start. Then choose “Enter research workspace.”';
  }
  async function askGuide(question) {
    const text=clean(question).slice(0,1200);if(!text||guideState.busy||state.graphOpen||handoffInFlight)return;
    const serial=++guideState.serial,controller=new AbortController(),context=guideContext();
    guideState.controller=controller;guideState.open=true;guideState.busy=true;guideState.draft='';
    root.querySelector('#rt-guide-input').value='';
    guideState.messages.push({role:'user',text});guideState.messages=guideState.messages.slice(-16);renderGuide();
    try {
      const result=typeof config.guideAssistant==='function'?await config.guideAssistant(text,context,{signal:controller.signal}):{answer:demoGuideReply(text,context)};
      if(serial!==guideState.serial||controller.signal.aborted)return;
      const answer=clean(typeof result==='string'?result:result?.answer);
      if(!answer)throw new Error('No answer returned');
      guideState.messages.push({role:'assistant',text:answer});
    }catch(error){if(serial===guideState.serial&&error?.name!=='AbortError')guideState.messages.push({role:'assistant',text:'I could not get an answer just now. Please try asking again.'});}
    finally{if(serial===guideState.serial){guideState.busy=false;guideState.controller=null;renderGuide();root.querySelector('#rt-guide-input')?.focus?.();}}
  }

  /* [VIEWS] The following functions produce ONLY billboard content.
   * The physical road, framing, colors, and first-person viewpoint are preserved.
   * There is no graph, gap-selection, or final-reference page inside this path.
   */
  function fieldView() {
    return `<h2>${state.broad?'Let’s choose a discipline.':'Which field would you like to explore?'}</h2><p class="rt-small rt-muted">We’ll map recent research after your field is specific enough.</p>
      ${state.broad?`<div class="rt-breadcrumb">${esc(state.broad)}</div><div class="rt-choices">${(fieldGroups[state.broad]||[]).map(f=>`<button class="rt-choice cursor-interaction" data-field="${esc(f)}">${esc(f)} <span class="rt-arrow">→</span></button>`).join('')}</div>`:`<div class="rt-choices">${Object.keys(fieldGroups).map(f=>`<button class="rt-choice cursor-interaction" data-broad="${esc(f)}">${esc(f)}<span class="rt-arrow">→</span></button>`).join('')}</div>`}
      <details class="rt-custom" ${state.broad==='Another field'?'open':''}><summary>Write your field or discipline</summary><form data-form="field">${textField('Your field','customField',state.field,'For example: quantum mechanics',false,true)}<div class="rt-actions"><button class="rt-button rt-primary cursor-interaction" type="submit">Map this field →</button></div></form></details>`;
  }
  /* [VIEW-DISCOVERY] Beginner teaches before asking the user to choose.
   * Placeholder papers have no anchors: an empty URL must never act like a citation.
   * The live adapter supplies sourced topics and resources using the same layout.
   */
  function paperLinks(papers=[]) {
    if(!papers.length)return '<p class="rt-micro rt-muted">No source-linked papers returned for this branch yet.</p>';
    return `<details class="rt-source-details"><summary>${papers.length} related paper${papers.length===1?'':'s'} ↗</summary>${papers.map(p=>{const url=p.placeholder?'':safeLink(p.url);return `<div class="rt-compact-paper">▤ ${url?`<a href="${esc(url)}" target="_blank" rel="noopener noreferrer">${esc(p.title)} ↗</a>`:esc(p.title)}${p.year?`<small> · ${esc(p.year)}</small>`:''}</div>`;}).join('')}</details>`;
  }
  // Intermediate always shows both explanations, in the requested reading order.
  function stackedSummary(technical,simple) {
    return `<div class="rt-explanation rt-plain"><p class="rt-small">${esc((simple||'The agent will explain this direction.').slice(0,220))}</p></div><details class="rt-source-details"><summary>Technical detail</summary><p class="rt-small rt-muted">${esc(technical||'Further detail will appear here.')}</p></details>`;
  }
  function mapView() {
    if(state.mapPhase==='own-topic')return `<h2>What would you like to learn about?</h2><p class="rt-small rt-muted">Choose your own direction. This road will give you an introductory learning pack for it.</p><form data-form="learning-topic">${textField('Topic to explore','topic',state.topic,'A direction that interests you',false,true)}<div class="rt-actions"><button class="rt-button rt-primary cursor-interaction" type="submit">Build my learning pack →</button>${button('Back to the field map','map-overview')}</div></form>${modeNote()}`;
    if(state.mapPhase==='personalize')return `<h2>${state.personalizationRound?'Let’s get closer to your interests.':'Let’s find what fits you.'}</h2><p class="rt-small rt-muted">We can keep exploring until you choose a topic. Your previous answers and attachments stay here.</p>
      <form data-form="personalize"><p class="rt-sectionlabel">A · Your interests</p><div class="rt-chiprow">${[...state.topics.slice(0,4).map(t=>t.title),'Experiments','Theory','Building systems','Real-world applications'].map(v=>choice(v,'interest',state.interests.includes(v))).join('')}</div>
      ${textField('Any more interests?','otherInterests',state.otherInterests,'What would you enjoy investigating?')}
      <p class="rt-sectionlabel">B · Previous work</p>${textField('Projects, jobs, research, or courses','workHistory',state.workHistory,'What have you built, studied, or investigated?',true)}
      ${textField('Skills you would like to use','skills',state.skills,'Programming, FPGA, experiments, analysis…')}
      ${textField('What did not appeal to you about the suggestions?','feedback',state.feedback,'Too theoretical? Too unfamiliar? Prefer another application?',true)}
      ${state.profileQuestions.map(q=>questionMarkup(q,state.profileAnswers,'profile-answer')).join('')}
      ${uploads('profile','CV, transcript, reports, or your previous papers · optional')}
      <p class="rt-note">${config.simulation?'Demo: profile documents stay unread. Only typed preferences shape these scripted suggestions.':config.mode==='demo'?'Your documents are attached for this session. In this demo, their contents stay unread.':'These documents will be sent to the research service when you request suggestions.'}</p>
      <div class="rt-actions"><button type="submit" class="rt-button rt-primary cursor-interaction">Suggest more directions →</button>${button('Back to the field map','map-overview')}</div></form>`;
    const current=state.topics.find(t=>t.id===visualTopic)||state.topics[0];
    const positions=state.topics.map((t,i)=>({t,x:380+Math.cos(i/Math.max(1,state.topics.length)*Math.PI*2-Math.PI/2)*245,y:210+Math.sin(i/Math.max(1,state.topics.length)*Math.PI*2-Math.PI/2)*142}));
    return `<span class="rt-eyebrow">YOUR MAP OF THE FIELD</span><h2>See how ${esc(state.field)} fits together.</h2><p class="rt-small rt-muted">Select a branch. Follow its ideas and source papers.</p><div class="rt-visual-domain"><div class="rt-domain-canvas">${window.TrailCanvas.fieldMap(state.topics,current?.id,{edges:config.simulation?window.QuantumTrail.prerequisites:[]}).replaceAll("data-concept","data-visual-topic")}</div>${current?`<aside class="rt-topic-preview">${topicArt(current.title,state.topics.indexOf(current))}<span class="rt-sectionlabel">SELECTED BRANCH</span><h3>${esc(current.title)}</h3><p class="rt-small">${esc(current.simple.slice(0,180))}</p><details><summary>A closer look</summary><p class="rt-small rt-muted">${esc(current.technical)}</p><p class="rt-small rt-muted">${esc(current.whyNow)}</p></details>${paperLinks(current.papers)}<div class="rt-actions">${button('Build my learning trail →','select-topic',true,`data-topic-id="${esc(current.id)}"`)}</div></aside>`:''}</div><div class="rt-topic-tiles">${state.topics.map((t,i)=>`<button type="button" class="rt-mini-topic" data-visual-topic="${esc(t.id)}">${topicArt(t.title,i)}<strong>${esc(t.title)}</strong></button>`).join('')}</div><div class="rt-actions">${button('Open my field map ↗','open-field-map',true)}${button('Find a better fit','personalize')}${button('I have another topic','own-topic')}</div><details class="rt-source-details"><summary>About this map & its sources</summary><p class="rt-small rt-muted">${esc(state.sourceNote)}</p></details>`;
  }
  // One renderer serves both question loops; their answer stores stay separate.
  function questionMarkup(q,answers=state.answers,binding='answer') {
    const val=answers[q.id]||'',options=(q.options||[]).map(o=>typeof o==='string'?option(o,o):o);
    if(['select','choice'].includes(q.type)&&options.length)return `<label class="rt-field">${esc(q.label)}<select data-${binding}="${esc(q.id)}" ${q.required?'required':''}><option value="">Choose one…</option>${options.map(o=>`<option ${o.value===val?'selected':''} value="${esc(o.value)}">${esc(o.label)}</option>`).join('')}</select></label>`;
    return `<label class="rt-field">${esc(q.label)}<input data-${binding}="${esc(q.id)}" value="${esc(val)}" placeholder="Your answer" ${q.required?'required':''}></label>`;
  }
  // Choice cards are the main communication method. Writing an alternative is optional.
  function guidedQuestion(q) {
    const value=state.answers[q.id]||'',isPreset=q.options.some(o=>o.value===value);
    if(q.type!=='choice')return questionMarkup(q);
    return `<div class="rt-guided-options" role="group" aria-label="${esc(q.label)}">${q.options.map(o=>`<button type="button" class="rt-guided-option cursor-interaction" data-scope-question="${esc(q.id)}" data-scope-value="${esc(o.value)}" aria-pressed="${o.value===value}"><span>${esc(o.label)}</span>${o.description?`<small>${esc(o.description)}</small>`:''}</button>`).join('')}</div><details class="rt-custom" ${value&&!isPreset?'open':''}><summary>I would describe it differently</summary><label class="rt-field">Your own answer · optional<input data-custom-answer="${esc(q.id)}" value="${esc(isPreset?'':value)}" placeholder="Another preference or an example that interests you"></label></details>`;
  }
  /* [VIEW-LEARNING] THE BEGINNER ENDPOINT.
   * This is intentionally a terminal billboard. Studying happens outside this app.
   * Returning to the trailhead is explicit; intermediate is never started for them.
   */
  function learningView() {
    const pack=state.learningData;
    if(!pack)return `<h2>Your learning trail for ${esc(state.topic)}.</h2><div class="rt-actions">${button('Find learning resources','refresh-learning',true)}${button('Open my field map ↗','open-field-map')}</div>`;
    const cards=(resources,kind)=>resources.map((r,i)=>{const url=r.placeholder?'':safeLink(r.url),thumb=safeLink(r.thumbnail);return `<article class="rt-learning-tile"><div class="rt-learning-art">${thumb?`<img src="${esc(thumb)}" alt="" loading="lazy" referrerpolicy="no-referrer">`:topicArt(r.title,i)}${kind==='videos'?'<span class="rt-play-icon">▶</span>':''}</div><div class="rt-learning-body"><span class="rt-sectionlabel">${esc(r.level||kind)}</span><h3>${url?`<a href="${esc(url)}" target="_blank" rel="noopener noreferrer">${esc(r.title)} ↗</a>`:esc(r.title)}</h3><details><summary>About this resource</summary><p class="rt-small rt-muted">${esc(r.description||'Open the source to explore this resource.')}</p></details></div></article>`;}).join('');
    return `<span class="rt-eyebrow">TAKE THE MAP. KEEP EXPLORING.</span><h2>Your first steps in ${esc(state.topic)}.</h2><div class="rt-goal-chips">${pack.goals.slice(0,4).map((g,i)=>`<span><b>${i+1}</b>${esc(g)}</span>`).join('')}</div><details class="rt-source-details"><summary>Start with the big picture</summary><p class="rt-small rt-muted">${esc(pack.introduction)}</p></details>${['papers','books','videos'].map(kind=>`<section class="rt-learning-group"><h3>${{papers:'Read the foundations',books:'Go back to the concepts',videos:'Watch & learn'}[kind]}</h3><div class="rt-learning-tiles">${cards(pack[kind],kind)||'<p class="rt-small rt-muted">No resources returned in this category yet.</p>'}</div></section>`).join('')}<div class="rt-actions">${button('Open my field map ↗','open-field-map',true)}${button('Choose another branch','back-map')}${button('Refresh resources','refresh-learning')}</div><p class="rt-micro rt-muted">${esc(pack.sourceNote)}</p>`;
  }
  /* [VIEW-NARROWING] Intermediate owns this entire repeated loop.
   * Its technical and plain-language summaries are adjacent, always visible.
   * Follow-up questions can change per agent round; no round limit is imposed.
   */
  // [WORKSPACE CTA] This action enters the main research experience: literature,
  // connections, and insights. It is broader than a paper-search utility.
  const WORKSPACE_CTA='Enter research workspace →';
  function narrowView() {
    if(state.narrowPhase==='entry')return `<h2>What topic are you bringing?</h2><p class="rt-small rt-muted">An area you’re curious about is enough. We can explore the possibilities together.</p><form data-form="topic">${textField('Your topic','topic',state.topic,'For example: open quantum systems',false,true)}<p class="rt-sectionlabel">Or try a direction</p><div class="rt-chiprow">${['Open systems and decoherence','Entanglement','Quantum simulation','Quantum measurement'].map(v=>choice(v,'topic-example',state.topic===v)).join('')}</div><div class="rt-actions"><button type="submit" class="rt-button rt-primary cursor-interaction">Continue →</button></div></form>`;
    /* [SUBTOPIC QUESTION] This is its own billboard view after broad-topic entry.
     * It is never hidden in the first form. A user either supplies a subtopic or
     * explicitly chooses Explore to start the existing adaptive interview.
     */
    if(state.narrowPhase==='subtopic')return `<span class="rt-eyebrow">${esc(state.topic)}</span><h2>Do you already have a subtopic in mind?</h2><p class="rt-small rt-muted">Bring a specific idea if you have one, or let’s explore possible directions within your topic.</p><form data-form="subtopic"><div class="rt-guided-options" role="group" aria-label="How would you like to choose a subtopic?"><button type="button" class="rt-guided-option cursor-interaction" data-subtopic-choice="write" aria-pressed="${state.subtopicChoice==='write'}"><span>I have a subtopic</span><small>I know a more specific direction or research question I want to investigate.</small></button><button type="button" class="rt-guided-option cursor-interaction" data-subtopic-choice="explore" aria-pressed="${state.subtopicChoice==='explore'}"><span>Explore</span><small>Help me discover possible subtopics through a few guided questions.</small></button></div>${state.subtopicChoice==='write'?textField('Your subtopic or research question','knownDirection',state.knownDirection,'Describe the specific idea you want to investigate',true,true):''}<div class="rt-actions"><button type="submit" class="rt-button rt-primary cursor-interaction" ${!state.subtopicChoice?'disabled':''}>${state.subtopicChoice==='explore'?'Explore subtopics →':'Continue →'}</button>${button('Edit my topic','change-topic')}</div></form>`;
    if(state.narrowPhase==='questions'){
      const q=state.questions[state.questionIndex];
      if(!q)return `<h2>Let’s find a direction within ${esc(state.topic)}.</h2><div class="rt-actions">${button('Explore the possibilities','prepare-narrow',true)}${button('Edit my topic','change-topic')}</div>`;
      return `<span class="rt-eyebrow">${esc(state.topic)} · question ${state.questionIndex+1} of ${state.questions.length}</span><h2>${esc(q.label)}</h2><p class="rt-small rt-muted">${esc(q.help||'Choose what feels interesting. You can also leave the direction open.')}</p><form data-form="narrow">${guidedQuestion(q)}<div class="rt-actions"><button type="submit" class="rt-button rt-primary cursor-interaction">${state.questionIndex===state.questions.length-1?'Show me some subtopics →':'Next question →'}</button>${state.questionIndex?button('Previous question','previous-question'):button('Back to subtopic choice','subtopic-question')}</div></form>`;
    }
    if(state.narrowPhase==='refine')return `<h2>What would make these directions fit better?</h2><p class="rt-small rt-muted">Pick a change to react to, or describe what you would prefer. We can keep exploring.</p><form data-form="refine"><div class="rt-chiprow">${['Try a different application','Make it more practical','Explore the technical side'].map(v=>choice(v,'refinement-choice',state.refinement===v)).join('')}</div>${textField('Or tell us what you would change · optional','refinement',state.refinement,'A different use, a smaller project, or something you want to understand',true)}${state.narrowFollowUps.map(q=>questionMarkup(q)).join('')}<div class="rt-actions"><button type="submit" class="rt-button rt-primary cursor-interaction">Suggest more directions →</button>${button('Explore through questions again','adjust-answers')}${button('Back to these suggestions','show-candidates')}</div></form>`;
    if(state.narrowPhase==='confirm')return `<h2>A focused question to build on.</h2><div class="rt-research-question"><h3>${esc(state.specificTopic)}</h3><p class="rt-small">${esc(state.chosenCandidate?.question||'')}</p></div>${stackedSummary(state.chosenCandidate?.technical,state.chosenCandidate?.simple)}<p class="rt-small rt-muted rt-spaced">Next, decide whether you’d like to add papers or instructions before entering your research workspace.</p><div class="rt-actions">${button('Continue →','ask-context',true)}${button('Keep refining','refine-scope')}${button('Edit my topic','change-topic')}</div><p class="rt-note">This is a proposed research direction. The literature search will help you assess the evidence and open questions.</p>`;
    return `<h2>Which of these would you like to explore?</h2><p class="rt-small rt-muted">${esc(state.topic)} · suggestions shaped by your choices</p>${state.candidates.map(c=>`<div class="rt-scope-card"><h3>${esc(c.title)}</h3><p class="rt-small rt-spaced">${esc(c.question)}</p>${stackedSummary(c.technical,c.simple)}<p class="rt-micro rt-muted rt-spaced">${esc(c.why)}</p><div class="rt-scope-meta">${Object.entries(c.scope).map(([k,v])=>`<span><strong>${esc(k)}</strong> ${esc(v)}</span>`).join('')}</div>${paperLinks(c.papers)}<div class="rt-actions">${button('Choose this direction','choose-scope',true,`data-candidate-id="${esc(c.id)}"`)}</div></div>`).join('')}<div class="rt-actions">${button('None of these fit yet','refine-scope')}${button('Change my choices','adjust-answers')}</div>`;
  }
  function contextView() {
    const advanced=state.route==='papers';
    if(advanced)return advancedUploadView();
    /* [OPTIONAL CONTEXT QUESTION] Every Topic-route user sees this full question.
     * "Add" opens the existing upload form. "Skip" uses only the selected topic.
     * The final button enters the main workspace directly; no Insights stage is
     * inserted. Files in an abandoned context draft are retained locally but are
     * excluded from both the backend request and page handoff when skipped.
     */
    if(!advanced&&state.contextPhase==='choice')return `<span class="rt-eyebrow">Before you begin</span><h2>Would you like to add your own papers or instructions?</h2><p class="rt-small rt-muted">This is optional. Your research question is enough to start, and extra context can help shape the work.</p><div class="rt-research-question"><h3>${esc(state.specificTopic)}</h3></div><form data-form="context-choice"><div class="rt-guided-options" role="group" aria-label="Would you like to add research context?"><button type="button" class="rt-guided-option cursor-interaction" data-context-choice="add" aria-pressed="${state.contextChoice==='add'}"><span>Yes, I have something to add</span><small>Upload papers and share notes or instructions that should guide the research.</small></button><button type="button" class="rt-guided-option cursor-interaction" data-context-choice="skip" aria-pressed="${state.contextChoice==='skip'}"><span>No, continue with my research question</span><small>Start from the direction we’ve chosen, without adding papers or instructions.</small></button></div><p class="rt-small rt-muted rt-spaced">Your workspace brings papers, their connections, and research insights together.</p><div class="rt-actions"><button type="submit" class="rt-button rt-primary cursor-interaction" ${state.contextChoice==='skip'?'data-final-entry':''} ${!state.contextChoice?'disabled':''}>${state.contextChoice==='skip'?esc(WORKSPACE_CTA):'Continue →'}</button>${button('Back to my research question','revisit-topic')}</div></form>`;
    return `<h2>${advanced?'Bring the work you want to build on.':'Add your papers, notes, or instructions.'}</h2><p class="rt-small rt-muted">${advanced?'Your papers, notes, and instructions will guide the literature search.':'Add any context you would like the research workspace to build on. Each addition is optional.'}</p><form data-form="context">
      ${advanced?textField('Topic or research goal · optional if supplied in your papers','specificTopic',state.specificTopic,'What would you like to investigate?'):`<div class="rt-research-question"><h3>${esc(state.specificTopic)}</h3></div>`}
      ${uploads('papers','Your papers or bibliography')}
      ${textField('Notes about these papers','notes',state.notes,'What interests you? Which parts should the search pay attention to?',true)}
      ${textField('Instructions for the search','instructions',state.instructions,'Include or exclude methods, systems, datasets, dates, or questions…',true)}
      <p class="rt-note">${config.simulation?'Demo: filenames stay local. PDF contents are not read.':config.mode==='demo'?'Files remain in this browser for this demo session.':'Your selected files will be passed to the research service when the search starts.'}</p><p class="rt-small rt-muted rt-spaced">Continue into your research workspace to explore the literature, its connections, and research insights.</p><div class="rt-actions"><button type="submit" class="rt-button rt-primary cursor-interaction" data-final-entry>${esc(WORKSPACE_CTA)}</button>${!advanced?button('Back to the context question','context-question'):''}</div></form>`;
  }

  function advancedUploadView(){
    return `<span class="rt-eyebrow">ADVANCED TRAIL · 1 / 2</span><h2>Start with the papers closest to your idea.</h2><p class="rt-small rt-muted">Bring up to 15 PDFs. Your map appears after this step.</p><div class="rt-upload-billboard"><form data-form="advanced-papers">${textField('Your research area','specificTopic',state.specificTopic,'e.g. quantum mechanics or quantum error mitigation')}${uploads('papers','Choose your starting papers · PDF')}${config.hasCurrentPapers?.()?button('Use my current project papers','current-project-papers'):''}<div class="rt-paper-stack" aria-hidden="true"><span>▤</span><span>▤</span><span>▤</span></div><p class="rt-small">${files.papers.size?`${files.papers.size} paper${files.papers.size===1?'':'s'} selected`:state.samplePack?'Curated demo pack selected':'A focused set of 10–15 papers works well. You can start with fewer.'}</p><p class="rt-note">${config.simulation?'Demo: PDF contents stay unread. The next map uses a prepared example corpus.':'Your PDFs will be uploaded and indexed before you describe your question.'}</p><div class="rt-actions"><button type="submit" class="rt-button rt-primary">${state.paperPreview?'Continue to my research question →':'Prepare papers & see my map →'}</button></div></form>${config.simulation?`<aside class="rt-demo-paper-packs"><span class="rt-eyebrow">NO PDFS NEEDED TO TRY IT</span><h3>Start with a prepared paper pack.</h3><button type="button" class="rt-demo-pack" data-demo-pack="quantum"><span class="rt-pack-icon">◌</span><strong>Quantum mechanics</strong><small>States → noise → error mitigation</small><span>Choose this pack →</span></button></aside>`:`<aside class="rt-upload-promise">${topicArt('Starting papers',2)}<h3>Your starting point, made visible.</h3><p class="rt-small rt-muted">First index the papers. Then put your exact question beside them. The agents will investigate relationships when you launch.</p></aside>`}</div>`;
  }
  async function prepareAdvancedPapers(){
    if(state.paperPreview){await go(7);return;}
    if(!files.papers.size&&!state.samplePack&&!config.hasCurrentPapers?.()){state.error='Choose at least one PDF, or use a prepared demo pack.';render();return;}
    await runAgent('preparePapers',buildBrief(),async result=>{
      if(!result?.sources?.length)throw Error('No papers could be prepared. Check the files and try again.');
      state.paperPreview=result;state.specificTopic=result.topic||state.specificTopic;state.field=result.field||state.field;state.previewTopic='';await go(7);
    },config.simulation?'Opening the prepared paper map…':'Uploading and indexing your starting papers…');
  }
  function paperPreviewView(){
    const p=state.paperPreview;if(!p)return '';
    const topics=(p.topics||[]).slice(0,6),current=topics.find(t=>t.id===state.previewTopic)||topics[0];
    const positions=topics.map((t,i)=>({t,x:320+Math.cos(i/Math.max(1,topics.length)*Math.PI*2-Math.PI/2)*192,y:205+Math.sin(i/Math.max(1,topics.length)*Math.PI*2-Math.PI/2)*130}));
    const papers=current?(current.source_ids||[]).map(id=>p.sources.find(s=>s.id===id)).filter(Boolean):p.sources;
    return `<aside class="rt-paper-map" aria-label="Field map from your starting papers"><span class="rt-eyebrow">${p.sourceMode==='demo'?'PREPARED DEMO FIELD MAP':'YOUR PAPERS → YOUR FIELD MAP'}</span><h3>${esc(p.topic||'Your starting papers')}</h3><div class="rt-preview-metrics"><span><b>${p.sources.length}</b> source records</span><span><b>${topics.length}</b> branches</span></div><svg class="rt-preview-svg" viewBox="0 0 640 410" role="img" aria-label="Interactive map of your prepared papers">${positions.map(({x,y})=>`<path d="M320 205L${x} ${y}" stroke="var(--rt-border)" stroke-width="2"/>`).join('')}<circle cx="320" cy="205" r="44" fill="var(--rt-soft)" stroke="var(--rt-border)"/><text x="320" y="201" text-anchor="middle" fill="var(--rt-ink)" font-size="17">Your papers</text><text x="320" y="222" text-anchor="middle" fill="var(--rt-muted)" font-size="12">${p.sources.length} starting points</text>${positions.map(({t,x,y},i)=>`<g data-preview-topic="${esc(t.id)}" role="button" tabindex="0" aria-label="Explore ${esc(t.title)}"><rect x="${x-101}" y="${y-31}" width="202" height="62" rx="28" fill="${['#e2edda','#eee6f3','#dfeef0'][i%3]}" stroke="${t.id===current?.id?'#739462':'#a5b79d'}" stroke-width="${t.id===current?.id?3:1}"/><text x="${x}" y="${y-1}" text-anchor="middle" fill="#314c3a" font-size="15">${esc(t.title.slice(0,25))}</text><text x="${x}" y="${y+17}" text-anchor="middle" fill="#5e7158" font-size="11">${(t.source_ids||[]).length} source links</text></g>`).join('')}</svg><div class="rt-preview-selection"><strong>${esc(current?.title||'Starting papers')}</strong>${papers.slice(0,3).map(s=>`<div class="rt-preview-paper">▤ ${safeLink(s.url)?`<a href="${esc(safeLink(s.url))}" target="_blank" rel="noopener noreferrer">${esc(s.title||s.name)} ↗</a>`:esc(s.title||s.name)}</div>`).join('')}</div><p class="rt-micro rt-muted">${esc(p.sourceNote)}</p></aside>`;
  }
  function advancedQuestionView(){
    return `<span class="rt-eyebrow">ADVANCED TRAIL · 2 / 2</span><h2>What exactly do you want to find out?</h2><p class="rt-small rt-muted">Use your paper map to put a clear boundary around the question.</p><div class="rt-question-layout"><form data-form="advanced-question" class="rt-question-form">${textField('Your exact research question','exactQuestion',state.exactQuestion,state.paperPreview?.suggestedQuestion||'Which method, in which setting, improves what outcome—and under which constraints?',true,true)}<div class="rt-question-prompts"><span>◈ Method or mechanism</span><span>◈ System or population</span><span>◈ Outcome & constraints</span></div>${config.simulation?`<div class="rt-actions">${button('Use the example question','example-exact-question')}</div>`:''}<details class="rt-source-details"><summary>Add notes and search boundaries</summary>${textField('What do these papers leave unresolved?','notes',state.notes,'Assumptions, disagreements, missing measurements…',true)}${textField('Scope and instructions','instructions',state.instructions,'Methods, systems, dates or questions to include or exclude…',true)}</details><p class="rt-small rt-muted">Next: explore all 12 pages, the paper connection graph and eight gap lenses.</p><div class="rt-actions"><button type="submit" class="rt-button rt-primary" data-final-entry>Investigate this question →</button>${button('Change my papers','edit-advanced-papers')}</div></form>${paperPreviewView()}</div>`;
  }
  root.addEventListener('keydown',event=>{if(['Enter',' '].includes(event.key)&&event.target.matches('[data-preview-topic]')){event.preventDefault();state.previewTopic=event.target.dataset.previewTopic;render();}});

  function busyView() { return `<h2>${state.busy.operation==='createResearchJob'?'Opening your research workspace.':'Let’s build the next part.'}</h2><p id="rt-agent-progress" class="rt-small rt-muted" role="status">${esc(state.busy.message)}</p><div class="rt-request-line" aria-hidden="true"></div><div class="rt-actions">${button('Cancel','cancel-request')}</div>${modeNote()}`; }

  /* [NAVIGATION] All changes of physical stop pass through go(). Form substeps
   * stay on the same billboard. History is actual, not just a sequence of indexes.
   */
  function render() {
    root.dataset.experience={discover:'beginner',topic:'intermediate',papers:'advanced'}[state.route];
    const initial=state.step===0,stages=routeStages(),index=stages.indexOf(state.step)+1;
    root.querySelector('#fp-trailhead').hidden=!initial;
    root.querySelector('#fp-active').hidden=initial;
    root.querySelector('#fp-sidecaption').hidden=initial;
    root.querySelector('#fp-stagename').textContent=stepNames[state.step];
    root.querySelector('#rt-boardlabel').textContent=String(index).padStart(2,'0')+' / '+stepNames[state.step];
    root.querySelector('#rt-boardtype').textContent=stepTypes[state.step];
    root.querySelector('#rt-progress').textContent=initial?'Three independent roads':`Stop ${index} of ${stages.length}`;
    root.querySelector('#rt-routecaption').textContent=initial?'Start with what you already have.':routeConfig[state.route].label;
    root.querySelector('#fp-walkstatus').textContent=initial?'Choose your own road':state.step===6?'Your learning pack is ready · continue into the field map':'One useful decision at each billboard';
    root.querySelector('#rt-back').disabled=initial||walking||handoffInFlight;
    root.querySelector('#rt-mode-badge').textContent=config.simulation?'Demo · simulated agents':config.mode==='demo'?'Demo':'Live research mode';
    const nav=root.querySelector('#rt-stage-nav');
    const shortNames={0:'Start',1:'Field',2:'Discover',3:'Narrow topic',4:state.route==='topic'?'Before you begin':'Upload papers',6:'Learning pack',7:'Research question'};
    // Only this road's stops appear. Global numeric IDs never imply shared roads.
    nav.innerHTML=initial?'<span class="rt-route-overview">Discovery route</span><span class="rt-route-overview">Topic route</span><span class="rt-route-overview">Papers route</span>':stages.map((step,i)=>{
      const disabled=walking||handoffInFlight||!!state.busy||!state.history.includes(step);
      return `<button type="button" class="cursor-interaction" data-step="${step}" ${disabled?'disabled':''} ${step===state.step?'aria-current="step"':''}><small>${String(i+1).padStart(2,'0')}</small>${shortNames[step]}</button>`;
    }).join('');
    const views=[()=>'',fieldView,mapView,narrowView,contextView,()=>'',learningView,advancedQuestionView];
    const error=state.error?`<div class="rt-error" role="alert">${esc(state.error)}${lastTask&&state.retryable?`<div class="rt-actions">${button('Try again','retry')}</div>`:''}</div>`:'';
    screen.innerHTML=state.busy?busyView():error+views[state.step]();
    const viewKey=[state.step,state.mapPhase,state.narrowPhase,state.questionIndex,state.subtopicChoice,state.contextPhase,state.contextChoice,state.busy?.operation||'',state.round,state.personalizationRound].join(':');
    if(viewKey!==lastViewKey)screen.scrollTop=0;lastViewKey=viewKey;
    renderGuide();
    root.dataset.panelTitle=initial?'Choose your way in':stepNames[state.step];
    config.onStateChange?.(snapshot());
    icons();journeyWorld?.resize();
  }
  function go(step, options={}) {
    if(walking||handoffInFlight||!routeStages().includes(step))return Promise.resolve(false);
    cancelRequest();state.error='';
    if(step===state.step){render();return Promise.resolve(true);}
    return new Promise(resolve=>{
      const arrive=()=>{
        state.step=step;
        if(options.back){const at=state.history.lastIndexOf(step);state.history=at>=0?state.history.slice(0,at+1):[0,step];}
        else if(state.history.at(-1)!==step)state.history.push(step);
        if(step===0)state.history=[0];
        walking=false;root.classList.remove('fp-walking');root.removeAttribute('aria-busy');
        root.querySelector('#fp-active').inert=false;root.querySelector('#fp-trailhead').inert=false;
        render();resolve(true);
      };
      if(!journeyWorld){arrive();return;}
      walking=true;root.classList.add('fp-walking');root.setAttribute('aria-busy','true');
      root.querySelector('#fp-active').inert=true;root.querySelector('#fp-trailhead').inert=true;
      root.querySelectorAll('[data-step]').forEach(b=>b.disabled=true);
      root.querySelector('#fp-walkstatus').textContent='Walking to '+stepNames[step].toLowerCase()+'…';
      journeyWorld.travel(step,arrive);
    });
  }
  function previous() {
    cancelRequest();
    if(state.step===1&&state.broad){state.broad='';render();return;}
    if(state.step===2&&state.mapPhase!=='overview'){state.mapPhase='overview';render();return;}
    if(state.step===3){
      if(state.narrowPhase==='confirm'||state.narrowPhase==='refine'){state.narrowPhase=state.candidates.length?'candidates':state.questions.length?'questions':'subtopic';render();return;}
      if(state.narrowPhase==='candidates'){state.narrowPhase='questions';render();return;}
      if(state.narrowPhase==='questions'&&state.route==='topic'){if(state.questionIndex>0)state.questionIndex--;else state.narrowPhase='subtopic';render();return;}
      if(state.narrowPhase==='subtopic'){state.narrowPhase='entry';render();return;}
    }
    if(state.step===4&&state.route==='topic'&&state.contextPhase==='form'){state.contextPhase='choice';render();return;}
    const last=state.history.at(-2)??0;void go(last,{back:true});
  }

  /* [INTEGRATION-B] INSIGHTS PAGE MERGE POINT
   * Option 1 (same HTML/app):
   * ResearchTrail.configure({
   *   insightsPageMount: async (container, handoff, context) => {
   *     // Replace this with your teammate's page component/mount function.
   *     // handoff = {brief,job}; context.files holds the selected File objects.
   *     // context.returnToTrail() restores the last billboard without losing data.
   *     return mountYourInsightsPage(container, handoff);
   *   },
   *   insightsPageUnmount: () => cleanupYourInsightsPage()
   * });
   * The exact DOM slot is <div id="graph-page-root"> after the trail shell.
   *
   * Option 2 (separate page): configure insightsPageUrl:'./insights.html'.
   * After the fade, navigation adds only ?jobId=... . Fetch the saved brief and
   * results from the backend using jobId; do not send private notes via the URL.
   *
   * A separate URL cannot retain browser File objects: the agent adapter must
   * finish uploading/persisting seed documents before it returns the jobId.
   * Embedded mounts can additionally receive the original File objects directly.
   * Both options dispatch 'researchtrail:handoff' with {brief,job}. The default
   * demo destination is the separate Insights surface, never a stage inside the path.
   * Legacy graphPageMount / graphPageUnmount / graphPageUrl remain supported.
   * Prefer the new insightsPage* names; the exact mount container remains unchanged.
   */
  function waitFade() { return window.matchMedia('(prefers-reduced-motion: reduce)').matches?Promise.resolve():new Promise(r=>setTimeout(r,380)); }
  async function returnToTrail() {
    try{await (config.insightsPageUnmount || config.graphPageUnmount)?.();}catch{/* Graph cleanup must not strand the user. */}
    root.querySelector('#rt-graph-page').hidden=true;
    root.querySelector('#rt-trail-shell').hidden=false;
    root.querySelector('#rt-trail-shell').classList.remove('rt-leaving');
    root.querySelector('#rt-graph-page').classList.remove('rt-entered');
    state.graphOpen=false;render();screen.querySelector('[data-final-entry]')?.focus?.();
  }
  async function openInsights(job) {
    if(!atSearchEndpoint()||handoffInFlight)return;
    handoffInFlight=true;renderGuide();
    const payload={brief:buildBrief(),job};
    const trail=root.querySelector('#rt-trail-shell'), page=root.querySelector('#rt-graph-page'), target=root.querySelector('#graph-page-root');
    trail.classList.add('rt-leaving');trail.inert=true;
    await waitFade();
    try {
      const pageUrl=config.insightsPageUrl || config.graphPageUrl;
      if(pageUrl){
        const destination=new URL(pageUrl,window.location.href);
        if(!['http:','https:','file:'].includes(destination.protocol))throw new Error('The Insights page address is invalid.');
        destination.searchParams.set('jobId',job.jobId);
        window.dispatchEvent(new CustomEvent('researchtrail:handoff',{detail:payload}));
        window.location.assign(destination.href);return;
      }
      trail.hidden=true;page.hidden=false;state.graphOpen=true;renderGuide();
      target.innerHTML=`<div class="rt-workspace-ready"><span class="rt-badge">Research workspace</span><h2>From a question to connected evidence.</h2><p>${esc(payload.brief.specificTopic||payload.brief.broadTopic||'Building on your papers')}</p><p class="rt-small rt-muted">Your research brief is ready. This workspace brings the related papers, their connections, and research insights together.</p><details><summary>Your research brief</summary><dl class="rt-brief"><div><dt>Notes</dt><dd>${esc(payload.brief.notes||'None added')}</dd></div><div><dt>Instructions</dt><dd>${esc(payload.brief.instructions||'Explore the related literature and retain source evidence.')}</dd></div><div><dt>Your papers</dt><dd>${payload.brief.seedPapers.map(p=>esc(p.name)).join(', ')||'None added'}</dd></div></dl></details></div>`;
      // Commit the visible starting style so the browser animates the page fade-in.
      void page.offsetWidth;
      page.classList.add('rt-entered');
      window.dispatchEvent(new CustomEvent('researchtrail:handoff',{detail:payload}));
      const mount=config.insightsPageMount || config.graphPageMount;
      if(typeof mount==='function'){
        target.replaceChildren();
        await mount(target,payload,{files:researchFiles(),returnToTrail});
      } else {
        root.querySelector('[data-action="return-trail"]')?.focus?.();
      }
    } catch(error) {
      await returnToTrail();state.retryable=false;state.error=error?.message||'Insights could not open. Your brief and files are still available.';render();
    } finally {trail.inert=false;handoffInFlight=false;if(!state.graphOpen)render();}
  }
  // [DIRECT-HANDOFF] The last real billboard starts the job and fades directly.
  // The Topic route first completes the dedicated context question. There is no
  // review billboard, Insights stop, or extra road segment after workspace entry.
  function atSearchEndpoint() {return state.route==='papers'&&state.step===7 || state.route==='topic'&&state.step===4&&(state.contextPhase==='choice'&&state.contextChoice==='skip'||state.contextPhase==='form'&&state.contextChoice==='add');}
  function launch() {
    if(!atSearchEndpoint()||handoffInFlight)return;
    if(state.route!=='papers'&&!clean(state.specificTopic)){state.error='Choose a specific topic before starting the final search.';render();return;}
    if(state.route==='papers'&&(!state.paperPreview||clean(state.exactQuestion).length<20)){state.error='Prepare your papers and write a specific research question (at least 20 characters).';render();return;}
    setAnswer(state,'contextSkipped',state.route==='topic'&&state.contextChoice==='skip');
    if(state.job){void openInsights(state.job);return;}
    state.clientRequestId=state.clientRequestId||id();
    void runAgent('createResearchJob',buildBrief(),async result=>{
      if(!clean(result?.jobId))throw new Error('The research service did not return a search job ID.');
      state.job={jobId:clean(result.jobId),status:clean(result.status)||'queued'};
      render();await openInsights(state.job);
    },config.mode==='demo'?'Preparing your research brief…':'Starting the comprehensive literature search…');
  }

  /* [DEMO BACKEND] Replace through INTEGRATION-A, never edit the rendering code
   * merely to add a real agent. A brief delay demonstrates the async states.
   * Personalization only ranks example topics by typed interests/work history;
   * it does not inspect documents. Scope suggestions are illustrative templates.
   */
  async function demoPause(options) {
    await new Promise((resolve,reject)=>{
      const timer=setTimeout(()=>{options.signal?.removeEventListener('abort',abort);resolve();},config.demoDelayMs);
      const abort=()=>{clearTimeout(timer);reject(new DOMException('Cancelled','AbortError'));};
      if(options.signal?.aborted){abort();return;}
      options.signal?.addEventListener('abort',abort,{once:true});
    });
  }
  /* [GUIDED-QUESTIONS] CONCRETE, ADAPTIVE DEMO INTERVIEW
   * These deterministic fixtures demonstrate how the agent should guide a user
   * who knows an area but does not yet know its subtopics. No research runs here.
   * The interview asks one choice-led question at a time. Question 2 depends on
   * Question 1; every question includes an honest "not sure" route. A specific
   * system, task, metric, or research question is never demanded in advance.
   * Live narrowTopic(phase:'questions') receives answers + questionIndex each time
   * and may replace these fixtures with context-aware agent-generated questions.
   */
  const option=(value,label,description='')=>({value,label,description});
  const unsure=()=>option('explore','I’m not sure yet','Show me a range of directions so I can compare them.');
  function scopeDomain(topic) {
    if(/robot|drone|autonomous|control system/i.test(topic))return 'robotics';
    if(/security|secure|trust|crypt|side.channel/i.test(topic))return 'security';
    if(/\bAI\b|intelligence|learning|inference|model|neural|transformer|vision|quantiz/i.test(topic))return 'ai';
    if(/architecture|hardware|processor|FPGA|digital design|RISC|memory system/i.test(topic))return 'hardware';
    return 'general';
  }
  function demoGuidedQuestions(topic,answers={}) {
    const domain=scopeDomain(topic),interest=answers.interest;
    let first,second;
    if(domain==='ai'){
      first={label:'Which part of '+topic+' makes you most curious?',help:'You do not need to choose a method yet. Start with the kind of problem you would enjoy exploring.',options:[option('adaptation','Helping a model adapt','Change how it behaves when inputs or conditions change.'),option('efficiency','Using less computation or memory','Keep useful results while making a model cheaper to run.'),option('hardware','Making it work on a real device','Connect the model to the hardware that runs it.'),option('application','Solving a practical problem','Start with an application and work backward to the method.'),unsure()]};
      if(interest==='adaptation')second={label:'What kind of change sounds interesting to handle?',help:'For example, a camera could see different lighting, or a device could have less battery power available.',options:[option('lighting','Changing scenes or lighting','Keep a camera model useful as its surroundings change.'),option('budget','A changing battery or computing budget','Let the device vary how much computation it uses.'),option('new-patterns','New examples the model has not seen','Explore how the system responds to unfamiliar inputs.'),unsure()]};
      else if(interest==='efficiency')second={label:'If you could remove one limitation, which would you choose?',help:'These lead to different research directions. Pick the tradeoff you would enjoy investigating.',options:[option('energy','A battery that runs out too quickly','Explore energy-aware inference and adaptive computation.'),option('memory','A model that does not fit in memory','Explore compression, quantization, or selective activation.'),option('latency','A result that arrives too late','Explore faster inference and predictable response times.'),unsure()]};
      else if(interest==='hardware')second={label:'Which kind of device would you enjoy working with?',help:'A preference is enough. You do not need to own the device or know its design yet.',options:[option('microcontroller','A tiny controller or sensor','Work with very limited memory and power.'),option('fpga','An FPGA or custom accelerator','Explore the connection between an algorithm and a hardware architecture.'),option('mobile','A phone or embedded computer','Balance model quality with practical deployment limits.'),unsure()]};
      else if(interest==='application')second={label:'Which application would make the work feel useful to you?',help:'Think about a system you would enjoy understanding or building.',options:[option('robot','A robot that sees and acts','Connect perception quality to decisions and timing.'),option('inspection','A camera that detects defects','Explore reliable inspection under changing conditions.'),option('wearable','A wearable or health sensor','Work with continuous sensing and a small energy budget.'),unsure()]};
      else second={label:'Which example would you most like to try first?',help:'Choose an example to react to. You can change direction after seeing the suggestions.',options:[option('camera','A camera that spends more effort on difficult images','A starting point for adaptive computation.'),option('small-model','A useful model that fits on a smaller device','A starting point for efficient inference.'),option('accelerator','A model and hardware designed together','A starting point for hardware/software co-design.'),unsure()]};
    }else if(domain==='security'){
      first={label:'Which side of security interests you most?',help:'Choose a problem you would enjoy investigating; a complete threat model can come later.',options:[option('isolation','Keeping sensitive work isolated','Protect data even if another part of the device is compromised.'),option('leakage','Finding information that leaks during computation','Explore timing, power, or shared-resource behavior.'),option('resilience','Keeping a device working when something goes wrong','Study faults, detection, and recovery.'),unsure()]};
      second=interest==='leakage'?{label:'What would you enjoy measuring?',help:'Each choice points to a different family of experiments.',options:[option('timing','Differences in execution time','Start with measurements you can collect in software.'),option('power','Changes in power consumption','Connect computation to a physical signal.'),option('shared','Interference between tasks','Explore how shared resources expose behavior.'),unsure()]}:{label:'Where would you like to explore this problem?',help:'Pick a setting that feels familiar or interesting.',options:[option('controller','A small embedded controller','Keep the design lightweight and measurable.'),option('connected','A connected sensor or device','Consider communication and untrusted inputs.'),option('processor','A processor or accelerator','Explore protection at a hardware/software boundary.'),unsure()]};
    }else if(domain==='robotics'){
      first={label:'Which part of a robot would you most like to improve?',help:'You can start from the robot’s behavior rather than choosing an algorithm.',options:[option('perception','How it understands its surroundings','Work with sensing, vision, and uncertainty.'),option('control','How it moves and responds','Work with feedback, timing, and stability.'),option('planning','How it chooses its next action','Work with decisions, constraints, and changing situations.'),unsure()]};
      second={label:'Which setting would you enjoy exploring?',help:'Simulation is a useful choice if hardware is not available yet.',options:[option('mobile','A mobile robot navigating indoors','Connect sensing and decisions as the robot moves.'),option('arm','A robot arm performing a small task','Explore precision and repeatable motion.'),option('simulation','A simulated robot or environment','Test ideas without needing a physical platform first.'),unsure()]};
    }else if(domain==='hardware'){
      first={label:'Which part of the computing system interests you most?',help:'Start with the part you want to understand better, even if you have not designed one before.',options:[option('memory','Moving and storing data','Explore memory traffic, locality, and bottlenecks.'),option('acceleration','Speeding up a particular computation','Explore pipelines, parallelism, and specialized hardware.'),option('adaptation','Changing the hardware or workload at runtime','Explore when flexibility is worth its cost.'),unsure()]};
      second={label:'Which way of exploring hardware appeals to you?',help:'This helps suggest a manageable first study.',options:[option('fpga','Implement a small FPGA design','Build a working datapath and measure it.'),option('simulation','Use an architecture simulator','Compare design choices in a controlled setting.'),option('measurement','Measure an existing system','Start with a real bottleneck and investigate why it occurs.'),unsure()]};
    }else{
      first={label:'What would you most like to understand about '+topic+'?',help:'A preference is enough. We will use it to propose more concrete subtopics.',options:[option('mechanism','Why a particular behavior happens','Focus on explanations, assumptions, or mechanisms.'),option('method','How an existing approach could improve','Focus on methods and their limitations.'),option('application','How it could help in a practical setting','Focus on a concrete use or case.'),unsure()]};
      second={label:'Which starting point feels most comfortable?',help:'Choose something you could imagine working with.',options:[option('data','Existing datasets or published studies','Begin by analyzing evidence that is already available.'),option('experiment','A small experiment or working example','Learn by testing a concrete idea.'),option('simulation','A model or simulation','Explore behavior in a controlled setting.'),unsure()]};
    }
    const third={label:'What kind of research work would you enjoy doing?',help:'This helps turn the direction into a project you can picture yourself doing.',options:[option('build','Build or implement something','Make a small working system and measure what changes.'),option('compare','Compare approaches through experiments','Test alternatives against a clear baseline.'),option('model','Develop or study a method','Focus on the algorithm, model, or underlying mechanism.'),unsure()]};
    return [first,second,third].map((q,i)=>({...q,id:['interest','angle','style'][i],type:'choice',required:true}));
  }
  function demoScopeCandidates(request) {
    const a=request.answers||{},domain=scopeDomain(request.topic),style=a.style||'explore';
    const make=(id,title,question,technical,simple)=>({id,title,question,technical,simple});
    let catalog;
    if(domain==='ai'){
      const adaptive=make('adaptive','Confidence-aware early exits for battery-powered vision','Can confidence-aware early exits reduce energy use while keeping image-classification accuracy close to a fixed-depth baseline?','Compare a fixed-depth vision model with confidence-triggered exits. Measure the energy–accuracy tradeoff and how the exit policy behaves on easy and difficult inputs.','Let the camera stop computing when it is confident, and check how much battery power it saves without making too many mistakes.');
      const quantized=make('quantized','Mixed-precision inference under a fixed memory budget','Which layers benefit most from higher precision when an edge model must fit within a fixed memory limit?','Compare uniform and layer-wise mixed precision at a matched model-storage budget. Evaluate accuracy, peak memory, and the overhead of supported numerical formats.','Give extra numerical detail to the parts of a model that need it most, while keeping the whole model small enough for the device.');
      const hardware=make('hardware','Input-dependent inference on a small FPGA accelerator','When does skipping computation on easy inputs outweigh the control and data-movement overhead of an adaptive FPGA design?','Compare a fixed execution datapath with a controlled adaptive variant at matched task quality. Measure throughput, energy, resource utilization, and the cost of switching execution paths.','Build hardware that does less work for easier inputs, then check whether deciding what to skip actually pays off.');
      const scene=make('scene','Scene-aware inference depth for changing lighting','Can a scene-aware depth policy maintain useful vision accuracy across lighting changes while reducing average computation?','Use a fixed-depth baseline and controlled lighting variations. Compare confidence-based and scene-aware policies using accuracy, average compute, and worst-case latency.','Let a camera work harder when a scene becomes difficult to see and use less effort when the view is clear.');
      const budget=make('budget','Adaptive model execution as a device’s energy budget changes','How can an inference policy change its computational effort when the available energy budget varies?','Study a budget-conditioned inference policy against fixed operating points. Evaluate task quality and budget violations across several reproducible power-budget schedules.','Teach a device to spend its limited energy where it matters, instead of always running the same amount of computation.');
      const robot=make('robot','Balancing perception effort and response time in a mobile robot','When should a robot spend more computation on perception, and when should it act sooner?','Compare fixed-rate and adaptive perception schedules in a controlled navigation task. Measure perception quality, reaction time, and task completion under a shared computing budget.','Help a robot choose between taking a closer look and responding quickly enough to keep moving safely.');
      const inspection=make('inspection','Selective high-detail inference for visual defect inspection','Can an inspection system reserve its expensive model for uncertain images while preserving defect-detection quality?','Compare single-model and cascaded inspection systems at matched detection quality. Measure computation, latency distribution, and errors on difficult examples.','Use a quick first check for clear cases and ask a stronger model to inspect the images that are harder to judge.');
      const wearable=make('wearable','Event-driven inference for a low-power wearable sensor','Can an event-triggered policy reduce unnecessary inference while preserving useful event detection?','Compare periodic and event-triggered model execution on a reproducible sensing task. Measure detection quality, missed events, and energy per operating period.','Let a wearable do more work when something meaningful changes and less work while the signal is quiet.');
      if(a.interest==='adaptation')catalog=a.angle==='budget'?[budget,adaptive,scene]:[scene,budget,adaptive];
      else if(a.interest==='hardware')catalog=a.angle==='microcontroller'?[make('tiny-model','Adaptive inference on a memory-limited microcontroller','Can a small adaptive inference pipeline improve useful task quality within a microcontroller’s memory and energy limits?','Compare fixed and adaptive execution at a matched memory budget on a small controller. Measure peak memory, energy per inference, task quality, and decision overhead.','Help a tiny controller spend its limited memory and energy on the inputs that need them most.'),quantized,adaptive]:a.angle==='mobile'?[make('mobile','Adaptive model execution on an embedded computer','Can adaptive execution improve the latency–quality tradeoff of an embedded vision model?','Compare fixed execution with input-dependent depth at matched task quality. Measure average and worst-case response time on an embedded computer.','Let a practical device vary its model’s effort, then see whether the resulting answers arrive sooner without losing useful quality.'),quantized,adaptive]:[hardware,quantized,adaptive];
      else if(a.interest==='efficiency')catalog=a.angle==='memory'?[quantized,adaptive,budget]:a.angle==='latency'?[make('latency','Confidence-aware early exits with a response-time limit','Can an early-exit policy reduce response time without exceeding a chosen error tolerance?','Compare fixed-depth and early-exit models at matched quality. Measure average and tail latency, and identify which inputs cause slow responses.','Let easier inputs finish early, then check whether both typical and slow responses improve.'),adaptive,quantized]:[adaptive,budget,quantized];
      else if(a.interest==='application')catalog=a.angle==='robot'?[robot,inspection,wearable]:a.angle==='wearable'?[wearable,robot,inspection]:[inspection,robot,wearable];
      else catalog=a.angle==='accelerator'?[hardware,adaptive,quantized]:a.angle==='small-model'?[quantized,adaptive,budget]:[adaptive,quantized,hardware];
    }else if(domain==='security'){
      const isolation=make('isolation','Lightweight isolation for a small embedded controller','How much protection can a lightweight isolation scheme provide within a controller’s memory and runtime limits?','Define a small attack model and compare an unprotected baseline with alternative isolation mechanisms. Measure exposed state, memory overhead, and execution cost.','Keep sensitive work apart from untrusted code, then check the protection gained and the resources it costs.');
      const leakage=make('leakage','Measuring and reducing timing leakage in embedded computation','Which implementation choices make a sensitive computation’s timing easier or harder to distinguish?','Use repeated controlled measurements to compare timing distributions before and after a mitigation. Separate measurement noise from input-dependent execution behavior.','Look for clues in how long a computation takes, then test changes that make those clues less useful.');
      const resilience=make('resilience','Fault detection with bounded overhead on a sensor device','Which lightweight checks detect useful classes of faults without dominating the device’s work?','Inject reproducible faults into a small workload. Compare detection coverage, false alarms, recovery time, and runtime overhead.','Give a small device affordable ways to notice when its work has gone wrong and measure which problems the checks can catch.');
      catalog=a.interest==='leakage'?[leakage,isolation,resilience]:a.interest==='resilience'?[resilience,isolation,leakage]:[isolation,leakage,resilience];
    }else if(domain==='robotics'){
      const perception=make('perception','Adaptive perception updates for indoor mobile navigation','When can a mobile robot reduce perception updates without losing useful navigation performance?','Compare fixed and adaptive update schedules in a controlled navigation setting. Measure task success, reaction time, and compute consumption.','Let a robot look more often when the surroundings are difficult and less often when the situation is predictable.');
      const control=make('control','Control performance under variable sensing and computation delay','How does changing the sensing-to-action delay affect tracking performance in a small robotic task?','Introduce controlled delays into a baseline controller. Compare tracking error, stability margins, and the effect of a simple delay-aware adjustment.','Test what happens when a robot’s information arrives late and investigate ways to help it respond more reliably.');
      const planning=make('planning','Replanning only when the environment meaningfully changes','Can event-triggered replanning maintain task success while reducing unnecessary planning work?','Compare periodic and event-triggered replanning under reproducible environment changes. Measure task completion, recovery time, and planning cost.','Help a robot decide when it actually needs a new plan instead of constantly rebuilding one.');
      catalog=a.interest==='control'?[control,perception,planning]:a.interest==='planning'?[planning,perception,control]:[perception,control,planning];
    }else if(domain==='hardware'){
      const memory=make('memory','Reducing memory traffic in a small streaming workload','Which data-layout and buffering choices reduce memory movement without excessive on-chip storage?','Choose one reproducible workload and compare baseline and buffered dataflows. Measure external memory traffic, throughput, and storage utilization.','Keep useful data close to where it is processed so the system spends less effort moving it around.');
      const accelerator=make('accelerator','Pipeline depth and resource tradeoffs in a small accelerator','When does a deeper pipeline improve useful throughput once memory and control overhead are included?','Implement or simulate several matched pipeline variants. Measure throughput, latency, resource utilization, and the point where memory becomes limiting.','Compare a few hardware pipelines and find out when adding more stages stops helping the complete system.');
      const adaptive=make('adaptive-hardware','Runtime adaptation in a variable-workload accelerator','When does runtime adaptation repay its reconfiguration and control costs?','Compare a static design with a bounded adaptive variant across reproducible workload changes. Measure transition costs and overall execution efficiency.','Make hardware change how it works as its workload changes, then measure whether the flexibility is worth the cost.');
      catalog=a.interest==='acceleration'?[accelerator,memory,adaptive]:a.interest==='adaptation'?[adaptive,accelerator,memory]:[memory,accelerator,adaptive];
    }else{
      const t=clean(request.topic);
      catalog=[make('comparison','Comparing two approaches to '+t+' in one controlled setting','Which assumptions explain the difference between two approaches to '+t+' under the same evaluation conditions?','Define one setting, one baseline, and a small set of evaluation criteria. Compare approaches while controlling the data and assumptions.','Choose two ways of tackling the same problem and investigate why one works better under a particular set of conditions.'),make('mechanism','Testing one important assumption in '+t,'How sensitive are conclusions about '+t+' to one commonly used assumption?','Select a testable assumption, vary it in a controlled model or experiment, and measure how the result changes.','Take one idea that an approach relies on and see what happens when it stops being true.'),make('application','A small practical case study of '+t,'What changes are needed to make an approach to '+t+' useful in one concrete case?','Choose a bounded application and document the requirements, baseline behavior, and one measurable modification.','Start with a small real example and work out what has to change for the approach to help.')];
      if(a.interest==='mechanism')catalog=[catalog[1],catalog[0],catalog[2]];
      if(a.interest==='application')catalog=[catalog[2],catalog[0],catalog[1]];
    }
    // Respect the second choice in the shown setting, not only in the request.
    if(domain==='security'&&a.interest==='leakage'&&a.angle==='power')catalog[0]=make('power-leakage','Measuring power leakage in a small embedded computation','Which computation patterns remain distinguishable in a device’s power measurements?','Collect repeated power traces under controlled conditions. Compare distinguishability before and after a lightweight mitigation, while measuring its runtime and energy overhead.','Look for clues in a device’s power use, then test ways to make those clues less revealing.');
    if(domain==='security'&&a.interest==='leakage'&&a.angle==='shared')catalog[0]=make('shared-leakage','Leakage through shared resources in embedded workloads','Which shared-resource interactions expose useful information about a sensitive workload?','Compare timing and interference traces with and without workload isolation under matched conditions. Measure distinguishability and isolation overhead.','Check whether one task can learn about another by observing how they compete for shared hardware.');
    if(domain==='robotics'&&a.angle==='arm')catalog=catalog.map(c=>({...c,title:c.title.replace(/indoor mobile navigation/g,'a small robot-arm task').replace(/mobile robot/g,'robot arm'),question:c.question.replace(/mobile robot/g,'robot arm').replace(/navigation performance/g,'task performance'),technical:c.technical.replace(/navigation setting/g,'robot-arm task')}));
    if(domain==='security'&&a.angle==='connected')catalog=catalog.map(c=>({...c,title:c.title.replace(/embedded controller/g,'connected sensor'),technical:c.technical+' Use a connected sensor as the bounded example.'}));
    if(domain==='security'&&a.angle==='processor')catalog=catalog.map(c=>({...c,title:c.title.replace(/embedded controller/g,'processor subsystem'),technical:c.technical+' Focus on the boundary between trusted and untrusted processor workloads.'}));
    const startingPoint=demoGuidedQuestions(request.topic,a)[1].options.find(o=>o.value===a.angle)?.label||a.angle||'Open to exploration';
    const refinement=clean(request.refinement),round=Math.max(1,request.round||1);
    if(round>1&&/different|application|explore another/i.test(refinement))catalog=[...catalog.slice(1),catalog[0]];
    const approach=style==='build'?'Start with a small working prototype and a reproducible baseline.':style==='compare'?'Start with controlled comparisons and clearly matched evaluation conditions.':style==='model'?'Start with the mechanism and assumptions, then test a small implementation.':'Try a small baseline first; you can choose an experimental style after exploring the papers.';
    return {sourceNote:'A few research directions based on your choices.',followUpQuestions:[],candidates:catalog.slice(0,3).map((c,i)=>({...c,id:c.id+'-'+round,
      title:c.title+(refinement&&!/^(Try a different application|Make it more practical|Explore the technical side)$/.test(refinement)?' · '+refinement:''),
      technical:c.technical+' '+approach+(a.angle&&a.angle!=='explore'?' Use '+startingPoint.toLowerCase()+' as a starting point.':'')+(refinement?' For this round, prioritize: '+refinement+'.':''),
      why:style==='explore'?'You left the approach open, so this is one concrete possibility to react to.':'This fits the kind of work you selected and gives the literature search a manageable boundary.',
      scope:{focus:c.title,startingPoint,approach:style==='build'?'Build and measure':style==='compare'?'Controlled comparison':style==='model'?'Method and mechanism':'Open to exploration'},
      keywords:[request.topic,c.id.replace(/-/g,' '),'evaluation'],papers:[demoPaper('scope-reading-'+i+'-'+round,c.title,c.title+': A Comparative Study','Introduces the problem, contrasts two approaches, and explains which assumptions matter when comparing the results.')]
    }))};
  }

  const demoAgents={
    async discoverTopics(request,options){
      await demoPause(options);
      const supported=/computer engineering|computer science|software engineering/i.test(request.field||'');
      return {topics:supported?exampleTopics:[],sourceMode:'demo',sourceNote:'A tour of the ideas, their tradeoffs, and a few papers to help you find your bearings.'};
    },
    async personalizeTopics(request,options){
      await demoPause(options);
      if(!/computer engineering|computer science|software engineering/i.test(request.field||''))return {topics:[],sourceMode:'demo',sourceNote:'Let’s connect '+request.field+' to the kinds of problems you enjoy.',followUpQuestions:[{id:'application',label:'Which application in your field would you like to explore?',type:'text',required:false}]};
      const text=[...(request.interests||[]),request.previousWork||'',request.skills||'',request.feedback||''].join(' ').toLowerCase();
      const order=/security|crypto|risc/.test(text)?['security','systems','design','lowbit','edge','robotics']:/hardware|fpga|systems/.test(text)?['design','systems','edge','security','robotics','lowbit']:/theory|algorithm/.test(text)?['lowbit','edge','systems','robotics','security','design']:['edge','robotics','lowbit','design','systems','security'];
      const round=Math.max(1,request.personalizationRound||1),offset=((round-1)*2)%order.length;
      // Each submission demonstrates another set; these are still local fixtures.
      // A real agent uses feedback, rejected IDs, background, and uploaded documents.
      const topics=Array.from({length:3},(_,i)=>{
        const item=exampleTopics.find(t=>t.id===order[(offset+i)%order.length]);
        return {...item,id:item.id+'-round-'+round,title:item.title,whyNow:'This direction connects to the interests and experience you shared. You could start by exploring a small practical example, then decide whether you enjoy the underlying questions.'};
      });
      return {topics,sourceMode:'demo',sourceNote:'A few directions shaped by your interests and the experience you shared.',followUpQuestions:[{id:'approach-'+round,label:round%2?'Would you rather build something, run experiments, or work on theory?':'Which application or real-world problem would you enjoy working on?',type:'text',required:false}]};
    },
    async getLearningResources(request,options){
      await demoPause(options);
      const topic=clean(request.topic),base=exampleTopics.find(t=>t.title===topic);
      const resource=(id,title,description,level='Introductory')=>({id,title,url:'',description,level,placeholder:true});
      return {introduction:'You do not need to master everything before choosing a question. Start with the big picture of '+topic+', then work through one small example and note what you would like to understand better.',
        goals:['Explain the main problem and the essential terms in your own words.','Recognize two common approaches and what each gains or gives up.','Write down one result you would like to reproduce and two questions you want to investigate.'],
        papers:(base?.papers||[demoPaper('intro-paper',topic,'Understanding '+topic+': A First Research Guide','A readable overview of the central ideas, assumptions, and common evaluation methods.')]).map((r,i)=>resource(r.id,r.title,r.summary,i===0?'Start here':'Read next')),
        books:[resource('intro-book','A Practical Introduction to '+topic,'Read the foundations chapter first, then use the worked examples to connect the terminology to a concrete system.')],
        videos:[resource('overview-video',topic+' Explained Through One Working Example','A visual introduction that follows a simple problem from its inputs to its final result.','Watch first'),resource('tutorial-video','Build, Measure, and Compare: Your First '+topic+' Experiment','A guided exercise in choosing a baseline, measuring it, and changing one thing at a time.','Try it yourself')],
        sourceNote:'Suggested order: watch the overview, read the introduction, then follow a worked example.'};
    },
    async narrowTopic(request,options){
      await demoPause(options);
      if(request.phase==='questions')return {questions:demoGuidedQuestions(request.topic,request.answers)};
      return demoScopeCandidates(request);
    },
    async createResearchJob(request,options){await demoPause(options);return {jobId:'demo-'+request.clientRequestId,status:'demo-preview'};}
  };

  /* [EVENTS] data attributes connect actual native controls to state changes.
   * Input text is captured without rerendering, so typing and selection survive.
   * File objects are retained in Maps even when a view rebuilds its file input.
   */
  function setGuidedAnswer(key,value) {
    if(state.answers[key]===value)return;
    const at=state.questions.findIndex(q=>q.id===key);
    if(at>=0)for(const later of state.questions.slice(at+1))delete state.answers[later.id];
    setAnswer(state.answers,key,value);
  }
  function setAnswer(target,key,value) {
    // No-op submission must not invalidate a successful, reusable research job.
    if(target[key]!==value){target[key]=value;changed();}
  }
  function capture(form) {
    form.querySelectorAll('[data-bind]').forEach(el=>{
      const key=el.dataset.bind;
      if(key==='customField')setAnswer(state,'field',clean(el.value));
      else if(Object.prototype.hasOwnProperty.call(state,key))setAnswer(state,key,el.value);
    });
    form.querySelectorAll('[data-answer]').forEach(el=>setAnswer(state.answers,el.dataset.answer,clean(el.value)));
    form.querySelectorAll('[data-custom-answer]').forEach(el=>{if(clean(el.value))setGuidedAnswer(el.dataset.customAnswer,clean(el.value));});
    form.querySelectorAll('[data-profile-answer]').forEach(el=>setAnswer(state.profileAnswers,el.dataset.profileAnswer,clean(el.value)));
  }
  root.addEventListener('input',event=>{
    if(state.graphOpen)return;
    const el=event.target;
    if(el.id==='rt-guide-input'){guideState.draft=el.value;return;}
    if(el.dataset.bind==='specificTopic'&&state.route==='papers'&&state.paperPreview){state.paperPreview=null;state.samplePack='';}
    if(el.dataset.bind&&Object.prototype.hasOwnProperty.call(state,el.dataset.bind)){setAnswer(state,el.dataset.bind,el.value);}
    if(el.dataset.answer){setAnswer(state.answers,el.dataset.answer,el.value);}
    if(el.dataset.customAnswer){setGuidedAnswer(el.dataset.customAnswer,el.value);}
    if(el.dataset.profileAnswer){setAnswer(state.profileAnswers,el.dataset.profileAnswer,el.value);}
  });
  root.addEventListener('change',event=>{
    if(state.graphOpen)return;
    const el=event.target;
    if(el.dataset.answer){setAnswer(state.answers,el.dataset.answer,el.value);}
    if(el.dataset.profileAnswer){setAnswer(state.profileAnswers,el.dataset.profileAnswer,el.value);}
    const bucket=el.dataset.upload;
    if(bucket&&files[bucket]){
      if(el.files.length+files[bucket].size>15||Array.from(el.files).some(f=>f.size>10*1024*1024||!f.name.toLowerCase().endsWith('.pdf'))){state.error='Choose up to 15 PDFs, at most 10 MiB each.';render();return;}
      for(const file of Array.from(el.files||[])){
        if(!Array.from(files[bucket].values()).some(f=>f.name===file.name&&f.size===file.size&&f.lastModified===file.lastModified))files[bucket].set(id(),file);
      }
      if(bucket==='papers'){state.paperPreview=null;state.samplePack='';}
      changed();render();
    }
  });
  root.addEventListener('submit',async event=>{
    if(state.graphOpen)return;
    const form=event.target;event.preventDefault();
    if(form.dataset.form==='guide'){void askGuide(root.querySelector('#rt-guide-input').value);return;}
    if(walking||state.busy||handoffInFlight)return;
    capture(form);
    if(form.dataset.form==='advanced-papers'&&state.route==='papers'){void prepareAdvancedPapers();return;}
    if(form.dataset.form==='advanced-question'&&state.route==='papers'){launch();return;}
    if(form.dataset.form==='field'&&state.route==='discover'){
      if(!clean(state.field)){state.error='Write a field to explore.';render();return;}
      resetDiscovery();await go(2);void fetchMap();
    }
    if(form.dataset.form==='personalize'&&state.route==='discover'){
      const missing=state.profileQuestions.find(q=>q.required&&!clean(state.profileAnswers[q.id]));
      if(missing){state.error='Please answer: '+missing.label;render();return;}
      state.personalizationRound++;state.rejectedTopicIds=[...new Set([...state.rejectedTopicIds,...state.topics.map(t=>t.id)])];
      void fetchMap(true);
    }
    if(form.dataset.form==='learning-topic'&&state.route==='discover'){
      if(!clean(state.topic)){state.error='Write a topic you would like to learn about.';render();return;}
      state.selectedTopic=null;state.learningData=null;await go(6);void fetchLearningPack();
    }
    if(form.dataset.form==='topic'&&state.route==='topic'){
      if(!clean(state.topic)){state.error='Write the topic you want to explore.';render();return;}
      const broadTopic=clean(state.topic);
      if(state.scopeTopic!==broadTopic){state.knownDirection='';state.subtopicChoice='';state.contextChoice='';state.contextPhase='choice';}
      state.scopeTopic=broadTopic;
      state.answers={};state.questions=[];state.candidates=[];state.chosenCandidate=null;state.selectedTopic=null;state.specificTopic='';state.round=0;state.questionIndex=0;state.refinement='';changed();
      state.narrowPhase='subtopic';render();
    }
    if(form.dataset.form==='subtopic'&&state.route==='topic'&&state.narrowPhase==='subtopic'){
      if(!['write','explore'].includes(state.subtopicChoice)){state.error='Choose whether to enter your own subtopic or explore possible directions.';render();return;}
      if(state.subtopicChoice==='write'){
        if(!clean(state.knownDirection)){state.error='Write the subtopic or research question you want to investigate.';render();return;}
        state.specificTopic=clean(state.knownDirection);
        state.chosenCandidate={id:'your-direction',title:state.specificTopic,question:state.specificTopic,technical:'Focus the literature search on your stated direction: '+state.specificTopic+'. Compare the assumptions, methods, evaluation conditions, and limitations of the relevant work.',simple:'Find papers closest to your idea, then use their results and limitations to decide where to focus next.',scope:{},keywords:[],papers:[]};
        state.narrowPhase='confirm';changed();render();
      }else{
        state.answers={};state.questions=[];state.candidates=[];state.chosenCandidate=null;state.specificTopic='';state.round=0;state.questionIndex=0;state.refinement='';changed();void prepareNarrowing();
      }
    }
    if(form.dataset.form==='narrow'&&state.route==='topic'){
      const q=state.questions[state.questionIndex];
      if(!q){void prepareNarrowing();return;}
      if(q.required&&!clean(state.answers[q.id])){state.error='Choose an option, including “I’m not sure yet,” or write your own answer.';render();return;}
      if(state.questionIndex<state.questions.length-1){state.questionIndex++;void prepareNarrowing();}
      else void narrowAgain();
    }
    if(form.dataset.form==='refine'&&state.route==='topic'){
      const missing=state.narrowFollowUps.find(q=>q.required&&!clean(state.answers[q.id]));
      if(missing){state.error='Please answer: '+missing.label;render();return;}
      if(!clean(state.refinement))state.refinement='Try a different application';
      void narrowAgain();
    }
    if(form.dataset.form==='context-choice'&&state.route==='topic'&&state.step===4){
      if(!['add','skip'].includes(state.contextChoice)){state.error='Choose whether you would like to add papers or instructions.';render();return;}
      if(state.contextChoice==='add'){state.contextPhase='form';render();}
      else launch();
    }
    if(form.dataset.form==='context'&&state.route!=='discover'){
      if(state.route==='papers'&&!files.papers.size&&!clean(state.specificTopic)&&!clean(state.notes)&&!clean(state.instructions)){state.error='Add at least a paper, a research goal, notes, or instructions.';render();return;}
      setAnswer(state,'contextSkipped',false);launch();
    }
  });
  root.addEventListener('click',async event=>{
    const b=event.target.closest('button');if(!b||!root.contains(b)||b.disabled)return;
    if(b.dataset.action==='guide-toggle'){toggleGuide(!guideState.open);return;}
    if(b.dataset.action==='guide-close'){toggleGuide(false);return;}
    if(b.dataset.guideQuestion){void askGuide(b.dataset.guideQuestion);return;}
    if(walking||handoffInFlight)return;
    if(b.dataset.action==='return-trail'){void returnToTrail();return;}
    if(state.graphOpen)return;
    if(b.dataset.action==='cancel-request'){cancelRequest();render();return;}
    if(state.busy)return;
    if(b.dataset.route){
      if(state.step!==0||!routeConfig[b.dataset.route])return;
      chooseRoute(b.dataset.route);
      await go(routeConfig[state.route].entry);return;
    }
    if(b.dataset.step!==undefined){const step=Number(b.dataset.step);if(state.history.includes(step))await go(step,{back:true});return;}
    if(b.dataset.broad){state.broad=b.dataset.broad;render();return;}
    if(b.dataset.field&&state.route==='discover'){state.field=b.dataset.field;resetDiscovery();changed();await go(2);void fetchMap();return;}
    if(b.dataset.interest){const x=b.dataset.interest;state.interests=state.interests.includes(x)?state.interests.filter(v=>v!==x):[...state.interests,x];changed();b.setAttribute('aria-pressed',state.interests.includes(x));return;}
    if(b.dataset.subtopicChoice&&state.route==='topic'&&state.narrowPhase==='subtopic'){state.subtopicChoice=b.dataset.subtopicChoice;state.error='';render();return;}
    if(b.dataset.contextChoice&&state.route==='topic'&&state.step===4){state.contextChoice=b.dataset.contextChoice;state.error='';render();return;}
    if(b.dataset.topicExample){state.topic=b.dataset.topicExample;state.knownDirection='';changed();render();return;}
    if(b.dataset.scopeQuestion){setGuidedAnswer(b.dataset.scopeQuestion,b.dataset.scopeValue);render();return;}
    if(b.dataset.refinementChoice){state.refinement=b.dataset.refinementChoice;changed();render();return;}
    if(b.dataset.demoPack&&state.route==='papers'&&config.simulation){if(state.samplePack!==b.dataset.demoPack)state.exactQuestion='';state.samplePack=b.dataset.demoPack;state.specificTopic=state.samplePack==='quantum'?'Quantum mechanics':'Efficient neural network hardware';state.field=state.samplePack==='quantum'?'Physical sciences / Physics':'Computer engineering';state.paperPreview=null;files.papers.clear();changed();void prepareAdvancedPapers();return;}
    if(b.dataset.previewTopic){state.previewTopic=b.dataset.previewTopic;render();return;}
    if(b.dataset.action==='edit-advanced-papers'){await go(4,{back:true});return;}
    if(b.dataset.action==='example-exact-question'){state.exactQuestion=state.paperPreview?.suggestedQuestion||'';changed();render();return;}
    if(b.dataset.action==='current-project-papers'){await prepareAdvancedPapers();return;}
    if(b.dataset.action==='start-quantum'){await window.ResearchTrail.startRoute('discover');return;}
    if(b.dataset.action==='resume-workspace'){config.openWorkspace?.();return;}
    if(b.dataset.removeFile){if(b.dataset.bucket==='papers'){state.paperPreview=null;state.samplePack='';}files[b.dataset.bucket]?.delete(b.dataset.removeFile);changed();render();return;}
    const action=b.dataset.action;
    if(action==='personalize'){state.mapPhase='personalize';render();}
    if(action==='map-overview'){state.mapPhase='overview';render();}
    if(action==='example-field'&&state.route==='discover'){state.field='Computer engineering';resetDiscovery();changed();void fetchMap();}
    if(action==='refresh-map')void fetchMap();
    if(action==='own-topic'&&state.route==='discover'){state.mapPhase='own-topic';render();}
    if(action==='select-topic'&&state.route==='discover'){
      const topic=state.topics.find(t=>t.id===b.dataset.topicId);if(!topic)return;
      state.selectedTopic=topic;state.topic=topic.title;state.learningData=null;changed();
      await go(6);void fetchLearningPack();
    }
    if(action==='refresh-learning'&&state.route==='discover')void fetchLearningPack();
    if(action==='back-map'&&state.route==='discover'){state.mapPhase='overview';await go(2,{back:true});}
    if(action==='trailhead')await go(0,{back:true});
    if(action==='prepare-narrow'&&state.route==='topic')void prepareNarrowing();
    if(action==='change-topic'){state.narrowPhase='entry';render();}
    if(action==='choose-scope'){
      const c=state.candidates.find(c=>c.id===b.dataset.candidateId);if(!c)return;
      state.chosenCandidate=c;state.specificTopic=c.title;state.narrowPhase='confirm';changed();render();
    }
    if(action==='refine-scope'){state.narrowPhase='refine';render();}
    if(action==='show-candidates'){state.narrowPhase=state.candidates.length?'candidates':'questions';render();}
    if(action==='adjust-answers'&&state.route==='topic'){state.questionIndex=0;void prepareNarrowing();}
    if(action==='previous-question'&&state.route==='topic'&&state.questionIndex>0){state.questionIndex--;render();}
    if((action==='ask-context'||action==='add-context')&&state.route==='topic'&&state.narrowPhase==='confirm'){state.contextPhase='choice';await go(4);}
    if(action==='context-question'&&state.route==='topic'){state.contextPhase='choice';render();}
    if(action==='subtopic-question'&&state.route==='topic'){state.narrowPhase='subtopic';render();}
    if(action==='revisit-topic'&&state.route==='topic'){state.narrowPhase='confirm';await go(3);}
    if(action==='launch')launch();
    if(action==='retry'&&state.retryable&&lastTask){const task=lastTask;void runAgent(task.operation,task.request,task.success,task.message);}
    if(action==='return-trail')void returnToTrail();
  });
  root.querySelector('#rt-back').addEventListener('click',previous);
  root.addEventListener('keydown',event=>{if(event.key==='Escape'&&guideState.open)toggleGuide(false);});

  /* [ROUTE DRAFTS] Roads have separate user data as well as separate geometry.
   * Choosing another road at the trailhead starts its own draft. Switching back
   * restores that road's answers and actual File objects for this open session.
   * No storage upload, document parsing, or background search happens here.
   */
  function resetDiscovery() {
    state.topics=[];state.selectedTopic=null;state.topic='';state.specificTopic='';
    state.mapPhase='overview';state.sourceNote='';state.personalizationRound=0;
    state.rejectedTopicIds=[];state.profileQuestions=[];state.profileAnswers={};state.learningData=null;
  }
  function chooseRoute(route,options={}) {
    cancelRequest();
    if(route!==state.route){
      routeDrafts.set(state.route,{state:JSON.stringify({...state,busy:null,error:'',retryable:false,graphOpen:false}),profile:new Map(files.profile),papers:new Map(files.papers)});
      const draft=routeDrafts.get(route);
      Object.assign(state,JSON.parse(draft?.state||initialState));
      files.profile=new Map(draft?.profile||[]);files.papers=new Map(draft?.papers||[]);
    }
    state.route=route;config.onRoute?.(route);if(!options.resume){state.history=[0];state.broad='';if(route==='topic')state.narrowPhase='entry';}state.error='';state.retryable=false;lastTask=null;
  }

  function snapshot(){const safe=value=>JSON.parse(JSON.stringify(value,(key,v)=>key==='pages'||key==='busy'||key==='job'?undefined:v));return {current:safe({...state,busy:null,job:null,graphOpen:false}),drafts:[...routeDrafts].map(([route,draft])=>[route,safe(JSON.parse(draft.state))])};}
  /* [PUBLIC API] Small, documented integration surface, independent of views.
   * getBrief() is serializable. getFiles() contains File objects and is not JSON.
   * Changing configure() never starts a search automatically.
   */
  window.ResearchTrail={
    configure(options={}){
      if(options.mode&&!['demo','live'].includes(options.mode))throw new Error('Use mode demo or live.');
      if(options.mode&&options.mode!==config.mode){
        cancelRequest();changed();state.topics=[];state.candidates=[];state.questions=[];state.learningData=null;state.sourceNote='';routeDrafts.clear();lastTask=null;
      }
      Object.assign(config,options);render();
    },
    getBrief:buildBrief,getFiles:allFileObjects,returnToTrail,
    async startRoute(route,options={}){if(!routeConfig[route])return;await returnToTrail();chooseRoute(route,options);if(options.topic&&!state.topic)state.topic=options.topic;if(options.field&&!state.field)state.field=options.field;if(options.notes&&!state.notes)state.notes=options.notes;if(options.instructions&&!state.instructions)state.instructions=options.instructions;if(route==='papers'&&options.question&&!state.exactQuestion)state.exactQuestion=options.question;await go(options.resume&&state.step>0?state.step:routeConfig[route].entry);},
    getSnapshot:snapshot,
    getStatus:()=>({step:state.step,route:state.route,busy:!!state.busy,walking,error:state.error,questionIndex:state.questionIndex,questionCount:state.questions.length,narrowPhase:state.narrowPhase,contextPhase:state.contextPhase}),
    async showTrailhead(){cancelRequest();await returnToTrail();await go(0);},
    restore(value){if(!value)return;cancelRequest();routeDrafts.clear();for(const [route,draft]of value.drafts||[])routeDrafts.set(route,{state:JSON.stringify(draft),profile:new Map(),papers:new Map()});Object.assign(state,JSON.parse(initialState),value.current||{}, {busy:null,error:'',retryable:false,graphOpen:false});files.profile.clear();files.papers.clear();render();},
    async reset(){cancelRequest();routeDrafts.clear();files.profile.clear();files.papers.clear();Object.assign(state,JSON.parse(initialState));await returnToTrail();render();},
    integrationVersion:'research-trail.integration.v4'
  };

  /* [WORLD] FIRST-PERSON ROADS — GEOMETRY AND RENDERER
 * Each route has its own coordinates and physical stops. There is no shared
 * centerline after the trailhead. Global state.step IDs label content only;
 * routeStops maps them to a distance on the chosen road.
 */
const routeStops={
  discover:{0:0,1:46,2:86,6:128},
  topic:{0:0,3:48,4:92},
  papers:{0:0,4:50,7:104}
};
// The offset increases monotonically after the fork at z=8. Outer roads never
// rejoin the center road. The shared gentle bend changes all three equally.
function roadSeparation(z){const d=Math.max(0,z-8);return 9*(1-Math.exp(-d/16))+.16*d;}
function routeCenter(route,z){const d=Math.max(0,z-8),bend=1.1*Math.sin(d/30)*(1-Math.exp(-d/14));return bend+({discover:-1,topic:0,papers:1}[route]||0)*roadSeparation(z);}

function createWorld(){
const scene=root.querySelector('#fp-pov'),canvas=root.querySelector('#fp-landscape');
if(!canvas?.getContext)return null;
let ctx;try{ctx=canvas.getContext('2d')}catch{return null}if(!ctx)return null;

const cam={z:0,x:0,y:1.68,yaw:0};
let w=1024,h=710,f=840,horizon=298,dpr=1,palette={};
const reduced=window.matchMedia('(prefers-reduced-motion: reduce)');
const theme=window.matchMedia('(prefers-color-scheme: dark)');

/*
 * [WORLD-02] RESOLVE THE CURRENT APPEARANCE
 * Canvas cannot directly use unresolved light-dark() variables. Resolve them through a hidden element once per resize/theme update.
 */
function colors(){const probe=document.createElement('span');probe.style.position='absolute';probe.style.visibility='hidden';root.appendChild(probe);for(const n of ['fp-sky','fp-horizon','fp-ground','fp-ground-alt','fp-hill','fp-hill-far','fp-path','fp-path-edge','fp-line','fp-trunk','fp-leaf','fp-leaf-dark','fp-post','fp-shadow','fp-sign','fp-sign-edge','fp-sign-ink']){probe.style.color='var(--'+n+')';palette[n]=getComputedStyle(probe).color;}probe.remove();}

/*
 * [WORLD-03] FOG COLOR HELPER
 * Turns a resolved RGB color into an RGBA color for distance fog.
 */
function alpha(color,a){const m=color.match(/[\d.]+/g)||[0,0,0];return 'rgba('+m.slice(0,3).join(',')+','+a+')';}

/*
 * [WORLD-04–06] SELECTED INDEPENDENT ROAD
 * routeCenter() above owns the non-converging geometry. The camera, road strips,
 * entry signs, roadside markers, and future billboards all use the same function.
 * This keeps each billboard physically attached to its own road throughout travel.
 */
function routeX(z){return routeCenter(state.route,z);}

/*
 * [WORLD-07] FOLLOW THE ROAD AT EYE LEVEL
 * Places the camera on routeX(cam.z) and estimates yaw from the local path slope. There is no overhead observer camera.
 */
function camera(){cam.x=routeX(cam.z);cam.yaw=Math.atan2(routeX(cam.z+.12)-routeX(cam.z-.12),.24);}

/*
 * [WORLD-08] WORLD-TO-SCREEN PROJECTION
 * Coordinates: x points right, y points upward, z points forward along the world.
 * Subtract camera position, rotate x/z by camera yaw, and reject points behind/too near
 * the eye. Perspective then divides by forward depth:
 *   screenX = canvasCenterX + cameraSpaceX * focalLength / depth
 *   screenY = horizon + (eyeHeight - worldY) * focalLength / depth
 * That depth division makes nearby ground wide and distant paths meet at the horizon.
 */
function project(x,y,z){const dx=x-cam.x,dz=z-cam.z,cs=Math.cos(cam.yaw),sn=Math.sin(cam.yaw);const xx=dx*cs-dz*sn,zz=dx*sn+dz*cs;if(zz<.35)return null;return {x:w*.5+xx*f/zz,y:horizon+(cam.y-y)*f/zz,depth:zz};}

/*
 * [WORLD-09] PROJECT AND FILL A WORLD POLYGON
 * Projects each corner into the camera view and fills the resulting screen polygon. Road and scenery meshes use this helper.
 */
function poly(points,color){const p=points.map(v=>project(v[0],v[1],v[2]));if(p.some(v=>!v))return;ctx.fillStyle=color;ctx.beginPath();p.forEach((v,i)=>{if(i)ctx.lineTo(v.x,v.y);else ctx.moveTo(v.x,v.y);});ctx.closePath();ctx.fill();}

/*
 * [WORLD-10] DECORATIVE ROADSIDES
 * Draws a simple trunk, layered canopy, and shadow at a world position. Trees provide scale and parallax during travel.
 */
function drawTree(z,side,seed){const x=routeCenter(['discover','topic','papers'][seed%3],z)+side*(7.6+(seed%5)*1.7),height=3.6+(seed%4)*.45;if(['discover','topic','papers'].some(route=>Math.abs(x-routeCenter(route,z))<3.3))return;const base=project(x,0,z),top=project(x,height,z);if(!base||!top||base.x < -180||base.x>w+180)return;const width=(base.y-top.y)*.28;if(width<2)return;ctx.fillStyle=palette['fp-shadow'];ctx.beginPath();ctx.ellipse(base.x+width*.4,base.y,width*1.4,width*.22,0,0,Math.PI*2);ctx.fill();poly([[x-.13,0,z],[x+.13,0,z],[x+.13,height*.62,z],[x-.13,height*.62,z]],palette['fp-trunk']);for(let j=0;j<3;j++){const yy=height*(.26+j*.2),half=height*(.29-j*.055);poly([[x-half,yy,z],[x+half,yy,z],[x,height*(.64+j*.18),z]],palette[j%2?'fp-leaf-dark':'fp-leaf']);}}

/*
 * [WORLD-11] PATH EDGE MARKERS
 * Small roadside posts make forward motion and perspective easier to perceive.
 */
function marker(z,side,route){const x=routeCenter(route,z)+side*1.65;poly([[x-.045,0,z],[x+.045,0,z],[x+.045,.65,z],[x-.045,.65,z]],palette['fp-post']);poly([[x-.1,.55,z],[x+.1,.55,z],[x+.1,.72,z],[x-.1,.72,z]],palette['fp-line']);}

/*
 * [WORLD-12] UPCOMING STAGE SIGNS
 * Draws an unreadable-at-distance sign as scenery, then adds a stage number or label
 * only when large enough. The active interactive sign is HTML, not this canvas mesh.
 */
function distantBillboard(route,i){const z=routeStops[route][i]+7,x=routeCenter(route,z)+4.7,width=4.8;const tl=project(x-width/2,4.4,z),tr=project(x+width/2,4.4,z),bl=project(x-width/2,1.8,z),br=project(x+width/2,1.8,z);if(!tl||!tr||!bl||!br)return;const pw=Math.abs(tr.x-tl.x);if(pw<14)return;for(const off of [-1.6,1.6])poly([[x+off-.09,0,z],[x+off+.09,0,z],[x+off+.09,1.85,z],[x+off-.09,1.85,z]],palette['fp-post']);poly([[x-width/2,1.8,z],[x+width/2,1.8,z],[x+width/2,4.4,z],[x-width/2,4.4,z]],palette['fp-sign-edge']);poly([[x-width/2+.14,1.96,z-.01],[x+width/2-.14,1.96,z-.01],[x+width/2-.14,4.24,z-.01],[x-width/2+.14,4.24,z-.01]],palette['fp-sign']);if(pw>=36){const center=project(x,3.05,z-.04);ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle=palette['fp-sign-ink'];ctx.font='500 '+Math.max(11,Math.min(16,pw/10))+'px system-ui';ctx.fillText(pw>105?['Start','Field','Discover','Narrow topic','Upload papers','','Learning pack','Research question'][i]:String(routeConfig[route].stages.indexOf(i)+1).padStart(2,'0'),center.x,center.y,pw-10);}}

/*
 * [WORLD-13] ALIGN THE THREE HTML ENTRY SIGNS WITH THE ROAD
 * On desktop, project independent road positions and position the HTML buttons above them. On narrow screens, CSS stacks the choices for readable input.
 */
function layoutSigns(){if(w<720||state.step!==0)return;const signZ=23;root.querySelectorAll('.fp-pathsign').forEach((sign,i)=>{const ground=project(routeCenter(['discover','topic','papers'][i],signZ),0,signZ);if(!ground)return;sign.style.left=ground.x+'px';sign.style.top=Math.max(114,ground.y-34-sign.offsetHeight)+'px';});}

/*
 * [WORLD-14] PAINT ONE FRAME
 * Draw sky/hills, ground bands, path strips, and dashed centerlines.
 * Sort road polygons and scenery by depth so farther objects paint first.
 * Draw upcoming signs only if relevant to the current route; add horizon fog.
 * Finally align the desktop trailhead signs with their projected road positions.
 * Frames are drawn for resize/theme changes and travel, not by an endless idle loop.
 */
function draw(){if(!ctx)return;camera();ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);const sky=ctx.createLinearGradient(0,0,0,horizon+60);sky.addColorStop(0,palette['fp-sky']);sky.addColorStop(1,palette['fp-horizon']);ctx.fillStyle=sky;ctx.fillRect(0,0,w,h);for(let k=0;k<2;k++){ctx.fillStyle=palette[k?'fp-hill':'fp-hill-far'];ctx.beginPath();ctx.moveTo(-100,horizon+5);for(let j=-1;j<=12;j++){const x=j*w/10,yy=horizon-20-(k?20:30)*(1+Math.sin(j*1.27+k*2+cam.yaw*.8));ctx.lineTo(x,yy);}ctx.lineTo(w+100,horizon+45);ctx.lineTo(-100,horizon+45);ctx.closePath();ctx.fill();}ctx.fillStyle=palette['fp-ground'];ctx.fillRect(0,horizon+5,w,h-horizon);
const commands=[];
for(let z=Math.floor((cam.z+1)/9)*9;z<cam.z+260;z+=18){commands.push({z:z+9,layer:-1,points:[[-90,0,z],[90,0,z],[90,0,z+9],[-90,0,z+9]],color:palette['fp-ground-alt']});}

/*
 * [WORLD-15] BUILD A ROAD SURFACE FROM STRIPS
 * Nested inside draw(): samples a centerline into quads for the road edge, road fill, and alternating center dashes. Draw commands are depth-sorted afterward.
 */
function road(a,b,center,width){a=Math.max(a,cam.z+.6);b=Math.min(b,cam.z+260);for(let z=a;z<b;z+=1.15){const zz=Math.min(z+1.19,b),x=center(z),xx=center(zz);const strip=(half,yy,color,layer)=>commands.push({z:(z+zz)/2,layer,points:[[x-half,yy,z],[x+half,yy,z],[xx+half,yy,zz],[xx-half,yy,zz]],color});strip(width/2+.1,.012,palette['fp-path-edge'],0);strip(width/2,.014,palette['fp-path'],1);if(Math.floor(z/2.2)%2===0)strip(.035,.018,palette['fp-line'],2);}}
road(-20,8,()=>0,3.2);for(const route of ['discover','topic','papers'])road(8,460,z=>routeCenter(route,z),2.8);
commands.sort((a,b)=>b.z-a.z||a.layer-b.layer).forEach(c=>poly(c.points,c.color));
const objects=[];
for(let j=0;j<58;j++){const z=15+j*7.1;if(z>cam.z+.8&&z<cam.z+230)objects.push({z,draw:()=>drawTree(z,j%2?-1:1,j)});}
for(let z=25;z<cam.z+160;z+=9){if(z>cam.z+1)for(const route of ['discover','topic','papers'])for(const side of [-1,1])objects.push({z,draw:()=>marker(z,side,route)});}
// At the trailhead, show one upcoming sign on each road. Once walking, show only
// the chosen road's relevant remaining stops; content substeps share a billboard.
const visibleRoutes=state.step===0&&!walking?['discover','topic','papers']:[state.route];
for(const route of visibleRoutes){
  const stages=routeConfig[route].stages;
  const upcoming=state.step===0&&!walking?[stages[1]]:stages.filter(i=>routeStops[route][i]>cam.z+.1);
  for(const i of upcoming)if(routeStops[route][i]+7>cam.z+1)objects.push({z:routeStops[route][i]+7,draw:()=>distantBillboard(route,i)});
}
objects.sort((a,b)=>b.z-a.z).forEach(o=>o.draw());
const fog=ctx.createLinearGradient(0,horizon-9,0,horizon+83);fog.addColorStop(0,alpha(palette['fp-horizon'],.7));fog.addColorStop(1,alpha(palette['fp-horizon'],0));ctx.fillStyle=fog;ctx.fillRect(0,horizon-9,w,92);layoutSigns();}

/*
 * [WORLD-16] RESPONSIVE CANVAS SIZE AND SHARPNESS
 * Measures the scene, sets focal length/horizon, caps pixel ratio at 2, resolves colors, and repaints. Billboard forms resize independently of the scenery.
 */
function resize(){w=Math.max(280,scene.clientWidth);h=Math.max(710,scene.clientHeight);f=w*.86;horizon=h*.42;dpr=Math.min(window.devicePixelRatio||1,2);canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);colors();draw();}

/*
 * [WORLD-17] GUIDED WALKING ANIMATION
 * Animates cam.z toward routeStops[state.route][step] using smoothstep easing p*p*(3-2*p).
 * Camera position/yaw are recomputed along the selected path each frame.
 * Respects reduced-motion preference by moving instantly and calling done().
 * The completion callback belongs to go(); travel() does not generate research content.
 */
function travel(step,done){const start=cam.z,target=routeStops[state.route][step];if(reduced.matches){cam.z=target;draw();done();return;}const duration=Math.min(1550,650+Math.abs(target-start)*10);const began=performance.now();
/*
 * [WORLD-18] ONE ANIMATION TICK
 * Clamp progress to 0..1, ease the forward position, draw, and schedule another frame only while movement remains.
 */
function frame(now){const p=Math.min(1,(now-began)/duration),e=p*p*(3-2*p);cam.z=start+(target-start)*e;draw();if(p<1)requestAnimationFrame(frame);else done();}requestAnimationFrame(frame);}
if(typeof ResizeObserver!=='undefined')new ResizeObserver(resize).observe(scene);else window.addEventListener('resize',resize);
theme.addEventListener('change',resize);
if(typeof MutationObserver!=='undefined')new MutationObserver(resize).observe(document.documentElement,{attributes:true,attributeFilter:['class','style','data-theme']});
resize();return {resize,draw,travel};
}



  let visualTopic='';
  function topicArt(label,index=0){const color=['#8ba77b','#b7a0c8','#cfad74','#83aeb9'][index%4];return `<svg viewBox="0 0 240 90" aria-hidden="true"><rect width="240" height="90" fill="${color}" opacity=".15"/>${[0,1,2,3,4,5].map(i=>{const a=i*Math.PI/3,x=120+Math.cos(a)*55,y=45+Math.sin(a)*29;return `<path d="M120 45L${x} ${y}" stroke="${color}"/><circle cx="${x}" cy="${y}" r="4" fill="${color}"/>`;}).join('')}<rect x="103" y="28" width="34" height="34" rx="8" fill="var(--rt-bg)" stroke="${color}"/><path d="M111 39h18m-18 7h12m-12 7h16" stroke="${color}" stroke-width="2"/></svg>`;}
  root.addEventListener('click',event=>{const branch=event.target.closest('[data-visual-topic]');if(branch){visualTopic=branch.dataset.visualTopic;render();}if(event.target.closest('[data-action="open-field-map"]'))config.openFieldMap?.(buildBrief());});
  root.addEventListener('keydown',event=>{if(['Enter',' '].includes(event.key)&&event.target.matches('[data-visual-topic]')){event.preventDefault();visualTopic=event.target.dataset.visualTopic;render();}});

  /* [STARTUP] Draw the first-person scene, then display the three entry signs. */
  journeyWorld=createWorld();
  if(config.initialSnapshot)window.ResearchTrail.restore(config.initialSnapshot);else render();
})();

