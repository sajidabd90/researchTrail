/* MIT. Preserve the supplied trail UI while sharing one evidence workspace. */
(()=>{'use strict';
const A=window.ResearchTrailWorkspace,Q=window.QuantumTrail;
const modes={discover:'beginner',topic:'intermediate',papers:'advanced'};
const aborted=signal=>{if(signal?.aborted)throw new DOMException('Request cancelled','AbortError')};
const topics=()=>A.state.concepts.map(t=>({...t,whyNow:'Follow the foundation into a scoped question. The prepared example does not establish novelty.',papers:(t.source_ids||[]).map(id=>A.state.sources.find(s=>s.id===id)).filter(Boolean).map(s=>({id:s.id,title:s.title||s.name,url:s.url,year:s.year,summary:s.summary,placeholder:false}))}));
function acceptBrief(brief={}){const s=A.state;s.mode=brief.route in {beginner:1,intermediate:1,advanced:1}?brief.route:s.mode;s.focus=brief.specificTopic||brief.broadTopic||s.focus;s.question=brief.researchQuestion||s.question;if(brief.notes&&brief.notes!==s.notes)s.notes=s.notes&& !s.notes.includes(brief.notes)?s.notes+'\n\n'+brief.notes:brief.notes;if(brief.instructions)s.instructions=brief.instructions;s.trailBrief={...brief};A.persist()}
async function task(operation,request={},options={}){
 const signal=options.signal;aborted(signal);const execution=A.state.execution,ws=A.state.workspace;let ownedRun;
 const cancel=()=>{if(A.state.workspace!==ws)return;if(execution==='demo')A.cancelDemo();else if(ownedRun||A.state.runId)void A.api('/api/runs/'+(ownedRun||A.state.runId)+'/cancel',{}).catch(()=>{})};
 signal?.addEventListener('abort',cancel,{once:true});
 try{
  options.onProgress?.(execution==='demo'?'Replaying the prepared quantum mechanics example…':'Your agents are collecting and checking source information…');
  const paperFiles=(options.files?.papers||[]).map(f=>f.file||f),profile=(options.files?.profile||[]).map(f=>f.file||f);
  if(operation==='preparePapers'){
   if(execution==='demo'){A.state.filenames=[...new Set([...A.state.filenames,...paperFiles.map(f=>f.name)])];if(!A.state.sources.length)A.loadPrepared();await A.runDemo('prepare')}
   else{if(paperFiles.length)await A.uploadFiles(paperFiles);if(!A.state.sources.length)throw Error('Choose starting PDFs or use current project papers.');}
   aborted(signal);A.state.prepared=true;A.persist();A.derive();const d=A.getData();return {topic:'Quantum mechanics',field:'Physical sciences / Physics',sources:A.state.sources.filter(s=>s.document_role!=='background'),topics:execution==='demo'?topics():d.taxonomy.map((t,i)=>({id:'starting-'+i,title:t.name,source_ids:t.ids})),suggestedQuestion:execution==='demo'?Q.QUESTION:'',sourceMode:execution,sourceNote:execution==='demo'?'Prepared source metadata and short abstract excerpts. Selected PDFs stay unread.':'Starting source records are prepared. Semantic connections are investigated after you state the question.'};
  }
  if(operation==='createResearchJob'){
   acceptBrief(request);if(execution==='demo'){if(!A.state.sources.length)A.loadPrepared();A.state.filenames=[...new Set([...A.state.filenames,...paperFiles.map(f=>f.name)])];await A.runDemo('investigate')}
   else{if(paperFiles.length)await A.uploadFiles(paperFiles);if(A.state.mode==='intermediate')await A.runGuide('landscape',request);aborted(signal);const run=await A.startLiveReview();ownedRun=run.id;}
   aborted(signal);if(A.state.mode==='advanced'){A.state.prepared=true;A.state.advancedOpen=true;A.state.steps.advanced=2}A.persist();return {jobId:A.state.runId,status:A.state.run?.status||'queued'};
  }
  if(execution==='live'){
   if(profile.length&&operation==='personalizeTopics')await A.uploadFiles(profile,'background');
   const result=await A.runGuide(operation,{...request,topic:request.topic||request.broadTopic||A.state.topic});aborted(signal);return result;
  }
  if(!A.state.sources.length)A.loadPrepared();await A.runDemo(operation==='getLearningResources'?'learn':operation==='narrowTopic'?'questions':'discover');aborted(signal);
  if(['discoverTopics','personalizeTopics'].includes(operation))return {topics:topics(),edges:A.getData().edges,sourceMode:'demo',sourceNote:'Curated QM directions, real source links and a prepared agent workflow. This is not a Live search.',followUpQuestions:[]};
  if(operation==='getLearningResources')return Q.prepared().learning;
  if(operation==='narrowTopic'&&request.phase==='questions')return {questions:guidedQuestions(request.answers||{})};
  if(operation==='narrowTopic')return {candidates:Q.prepared().candidates.map((c,i)=>({id:'qm-direction-'+i,title:c.title,question:c.question,simple:c.rationale,technical:'Match the quantum system, noise assumptions, estimator and complete resource budget before comparing the methods.',why:'Prepared scope suggestion. Closest prior art and readable counterevidence still need review.',scope:c.scope||{system:'Small quantum circuits',outcome:'Estimator error',constraint:'Matched resource accounting'},source_ids:c.source_ids,papers:c.source_ids.map(id=>A.state.sources.find(s=>s.id===id)).filter(Boolean).map(s=>({id:s.id,title:s.title,url:s.url,summary:s.summary}))})),followUpQuestions:[],sourceNote:'Three prepared directions shaped by the quantum mechanics research thread.'};
  return {answer:'Choose a path that matches your starting point. Each billboard makes one decision. Your field map, papers and notes carry into the research workspace.'};
 }finally{signal?.removeEventListener('abort',cancel)}
}
function guidedQuestions(answers){const option=(value,label,description)=>({value,label,description}),unsure=option('unsure','I’m not sure yet','Keep several directions open.');return [
 {id:'interest',label:'Which part of quantum mechanics makes you most curious?',help:'Start with an idea, rather than needing a fully formed research problem.',type:'choice',required:true,options:[option('noise','Noise and decoherence','Understand what changes when a quantum system meets its environment.'),option('entanglement','Entanglement and information','Explore correlations and how they can be used.'),option('simulation','Quantum simulation','Compare quantum models and their assumptions.'),unsure]},
 {id:'setting',label:answers.interest==='noise'?'Where would you like to explore the effect of noise?':'Which setting would you enjoy exploring first?',help:'You can start with an available simulation; owning a device is not required.',type:'choice',required:true,options:[option('simulation','A small reproducible simulation','Control the assumptions and compare against a known reference.'),option('published','Published experiments and methods','Inspect what was measured and which conditions were omitted.'),option('implementation','An open implementation','Follow the method from a paper into its software.'),unsure]},
 {id:'approach',label:'What kind of research work would you like to do?',help:'Your preference helps turn the direction into a project you can picture.',type:'choice',required:true,options:[option('compare','Compare methods fairly','Match the circuit family, noise model and total sampling budget.'),option('build','Build a small experiment','Start from a baseline and change one factor at a time.'),option('theory','Understand a mechanism','Examine assumptions, explanations and limits.'),unsure]}
 ];}
function openWorkspace(view){A.state.routeReady[A.state.mode]=true;A.state.trailOpen=false;A.state.started=true;if(A.state.execution==='demo'&&!A.state.sources.length)A.loadPrepared();if(A.state.mode==='advanced'){if(!A.state.prepared||!A.state.advancedOpen){A.state.trailOpen=true;A.render();void window.ResearchTrail.startRoute('papers',{resume:true,question:A.state.question});return}A.state.steps.advanced=2;A.navigate(view||'atlas',false)}else if(A.state.mode==='intermediate'){A.state.steps.intermediate=1;A.navigate(view||'overview',false)}else{A.state.steps.beginner=view==='discover'?0:2;A.navigate(view||'overview',false)}A.persist()}
function snapshotChanged(snapshot){A.state.trailDraft=snapshot;A.persist();const root=document.getElementById('research-trail-first-person');const resume=root.querySelector('[data-action="resume-workspace"]');if(resume)resume.hidden=!A.state.started;if(document.getElementById('fullscreen-dialog')?.open&&root.parentNode===document.getElementById('fullscreen-body'))document.getElementById('fullscreen-title').textContent=root.dataset.panelTitle||'Research billboard'}
window.ResearchTrailConfig={mode:'live',simulation:A.state.execution==='demo',yearRange:{from:2023,to:2026},initialSnapshot:A.state.trailDraft,agents:Object.fromEntries(['discoverTopics','personalizeTopics','getLearningResources','narrowTopic','preparePapers','createResearchJob'].map(operation=>[operation,(request,options)=>task(operation,request,options)])),
 onRoute(route){A.state.mode=modes[route];A.state.trailOpen=true;A.persist();A.render()},onStateChange:snapshotChanged,onDraftChange:snapshotChanged,
 hasCurrentPapers:()=>A.state.sources.some(s=>s.document_role!=='background'),
 openFieldMap(brief){acceptBrief({...brief,researchQuestion:null});openWorkspace('overview')},openWorkspace:()=>openWorkspace(),
 insightsPageMount:async(container,payload)=>{acceptBrief(payload.brief);openWorkspace(A.state.mode==='advanced'?'atlas':'overview')},
 guideAssistant:async(question,context,options)=>A.state.execution==='live'?task('guideAssistant',{...context,question},options):{answer:'You are on '+(context.step||'the starting billboard')+'. Choose what fits your background. Beginner builds a field guide, Intermediate uses three questions to focus an area, and Advanced prepares papers and opens every research view. Demo PDF contents stay unread.'}
};
window.TrailMerge={task,guidedQuestions,acceptBrief,openWorkspace,sync(draft){window.ResearchTrail.configure({simulation:A.state.execution==='demo'});if(draft)window.ResearchTrail.restore(draft);else void window.ResearchTrail.reset()},reset(){void window.ResearchTrail?.reset()}};
})();
