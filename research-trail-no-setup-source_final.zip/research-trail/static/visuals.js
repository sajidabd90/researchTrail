/* MIT. Pure projections: every live chart is derived from the current project. */
(function(root){
'use strict';
const unique=a=>[...new Set(a.filter(Boolean))];
const outputsOf=o=>Object.values(o||{}).filter(x=>x&&typeof x==='object');
function derive(sources,outputs,guideTopics=[]){
 const byId=new Map(sources.map(s=>[s.id,s])),out=outputsOf(outputs);
 let taxonomy=out.flatMap(o=>o.taxonomy||[]).filter(t=>t.name).map(t=>({name:t.name,ids:(t.source_ids||[]).filter(id=>byId.has(id))}));
 if(!taxonomy.length)guideTopics.forEach(t=>taxonomy.push({name:t.title,ids:(t.source_ids||t.papers?.map(p=>p.id)||[]).filter(id=>byId.has(id))}));
 if(!taxonomy.length)unique(sources.map(s=>s.source_type||'Unclassified')).forEach(name=>taxonomy.push({name,ids:sources.filter(s=>(s.source_type||'Unclassified')===name).map(s=>s.id)}));
 const branches=new Map();for(const t of taxonomy){if(!branches.has(t.name))branches.set(t.name,[]);branches.set(t.name,unique([...branches.get(t.name),...t.ids]))}taxonomy=[...branches].map(([name,ids])=>({name,ids}));
 const edges=out.flatMap(o=>o.edges||[]).filter(e=>byId.has(e.a)&&byId.has(e.b)&&e.a!==e.b);
 const observations=out.flatMap(o=>o.observations||[]).filter(o=>byId.has(o.source_id)&&Number.isFinite(o.value)&&o.evidence?.length);
 const seen=new Set();const obs=observations.filter(o=>{const key=JSON.stringify([o.source_id,o.metric,o.value,o.unit,o.task,o.dataset,o.platform,o.protocol]);if(seen.has(key))return false;seen.add(key);return true});
 const claims=out.flatMap(o=>(o.verified_claims||[]).map(c=>({...c,supported:true})).concat((o.unverified_claims||[]).map(c=>({...c,supported:false}))));
 const limitations=out.flatMap(o=>o.limitations||[]).filter(l=>byId.has(l.source_id)&&l.evidence?.length);
 const candidates=out.flatMap(o=>o.candidates||[]).filter(c=>c.question).filter((c,i,a)=>a.findIndex(x=>x.question===c.question)===i);
 const paperTags=new Map(sources.map(s=>[s.id,unique([...taxonomy.filter(t=>t.ids.includes(s.id)).map(t=>t.name),...obs.filter(o=>o.source_id===s.id).flatMap(o=>o.method_tags||[])])]));
 return{sources,byId,taxonomy,edges,obs,claims,limitations,candidates,paperTags};
}
function coverage(d){
 const columns=['Foundations','Conferences','Journals','Implementations'];
 const category=s=>s.foundational||['textbook','foundation'].includes(s.source_type)?0:s.source_type==='conference'?1:s.source_type==='journal'?2:s.source_type==='repository'?3:-1;
 return{columns,rows:d.taxonomy.map(t=>({name:t.name,cells:columns.map((_,i)=>{const ids=t.ids.filter(id=>category(d.byId.get(id))===i);return{ids,count:ids.length,withPassages:ids.filter(id=>d.byId.get(id).pages?.length).length}})}))};
}
function combinations(d){
 const sets=new Map();for(const [id,tags]of d.paperTags){if(!tags.length)continue;const key=tags.slice().sort().join(' · ');if(!sets.has(key))sets.set(key,{tags:tags.slice().sort(),ids:[]});sets.get(key).ids.push(id)}
 return [...sets.values()].sort((a,b)=>b.ids.length-a.ids.length).slice(0,12);
}
function evaluations(d){
 const columns=unique(d.obs.map(o=>[o.metric,o.unit].filter(Boolean).join(' · '))).slice(0,8),rows=[];
 const contexts=unique(d.obs.map(o=>[o.task||'Task unspecified',o.dataset||'Dataset unspecified',o.platform||'Platform unspecified'].join(' / '))).slice(0,14);
 for(const name of contexts)rows.push({name,cells:columns.map(metric=>{const records=d.obs.filter(o=>[o.task||'Task unspecified',o.dataset||'Dataset unspecified',o.platform||'Platform unspecified'].join(' / ')===name&&[o.metric,o.unit].filter(Boolean).join(' · ')===metric);return{count:records.length,ids:unique(records.map(o=>o.source_id)),records}})});
 return{columns,rows};
}
function tradeoffs(d){
 // A cohort requires all comparison-context fields. Unknown protocols never merge.
 const cohorts=new Map();for(const o of d.obs){if(![o.task,o.dataset,o.platform,o.protocol,o.unit].every(Boolean))continue;const key=JSON.stringify([o.task,o.dataset,o.platform,o.protocol,o.baseline||'']);if(!cohorts.has(key))cohorts.set(key,[]);cohorts.get(key).push(o)}
 const result=[];
 for(const[key,records]of cohorts){const metrics=unique(records.map(o=>o.metric+' ['+o.unit+']'));if(metrics.length<2)continue;const x=metrics[0],y=metrics[1],points=[];
 for(const id of unique(records.map(o=>o.source_id))){const a=records.find(o=>o.source_id===id&&o.metric+' ['+o.unit+']'===x),b=records.find(o=>o.source_id===id&&o.metric+' ['+o.unit+']'===y);if(a&&b)points.push({id,x:a.value,y:b.value,a,b})}
 if(points.length){const dx=records.find(o=>o.metric+' ['+o.unit+']'===x)?.direction,dy=records.find(o=>o.metric+' ['+o.unit+']'===y)?.direction;const directional=['min','max'].includes(dx)&&['min','max'].includes(dy);for(const p of points)p.frontier=directional&&!points.some(q=>q!==p&&(dx==='min'?q.x<=p.x:q.x>=p.x)&&(dy==='min'?q.y<=p.y:q.y>=p.y)&&(q.x!==p.x||q.y!==p.y));result.push({key:JSON.parse(key),x,y,points,directional})}}
 return result.sort((a,b)=>b.points.length-a.points.length);
}
function deployments(d){
 const links=new Map();for(const o of d.obs){if(!o.platform)continue;for(const method of o.method_tags||[]){const k=method+'|'+o.platform;if(!links.has(k))links.set(k,{from:method,to:o.platform,ids:[]});links.get(k).ids.push(o.source_id)}}
 return [...links.values()].map(l=>({...l,ids:unique(l.ids)})).sort((a,b)=>b.ids.length-a.ids.length).slice(0,18);
}
function boundaries(d){
 const rows=unique(d.obs.flatMap(o=>o.method_tags||[])).slice(0,10),columns=unique(d.obs.map(o=>o.platform)).slice(0,8);
 return{columns,rows:rows.map(name=>({name,cells:columns.map(platform=>{const ids=unique(d.obs.filter(o=>o.platform===platform&&(o.method_tags||[]).includes(name)).map(o=>o.source_id));return{ids,count:ids.length}})}))};
}
function layout(d,groupBy='topic'){
 const groups=groupBy==='venue'?unique(d.sources.map(s=>s.venue||'Venue unknown')).slice(0,12):d.taxonomy.map(t=>t.name).slice(0,12);
 const nodes=d.sources.map((s,i)=>{const gi=groupBy==='venue'?Math.max(0,groups.indexOf(s.venue||'Venue unknown')):Math.max(0,groups.findIndex(name=>d.taxonomy.find(t=>t.name===name)?.ids.includes(s.id)));return{...s,group:gi}});
 const centers=groups.map((name,i)=>({name,x:500+Math.cos(i/Math.max(groups.length,1)*Math.PI*2-Math.PI/2)*290,y:310+Math.sin(i/Math.max(groups.length,1)*Math.PI*2-Math.PI/2)*175}));
 if(groups.length===1){centers[0].x=500;centers[0].y=310}
 const positions=new Map();for(let gi=0;gi<Math.max(1,groups.length);gi++){const members=nodes.filter(n=>n.group===gi);members.forEach((n,j)=>{const a=j*2.399963,rad=members.length===1?0:22+Math.sqrt(j)*21,c=centers[gi]||{x:500,y:310};positions.set(n.id,{x:c.x+Math.cos(a)*rad,y:c.y+Math.sin(a)*rad})})}
 return{groups:centers,nodes:nodes.map(n=>({...n,...positions.get(n.id)})),edges:d.edges};
}
const api={unique,derive,coverage,combinations,evaluations,tradeoffs,deployments,boundaries,layout};root.ResearchVisuals=api;if(typeof module!=='undefined')module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
