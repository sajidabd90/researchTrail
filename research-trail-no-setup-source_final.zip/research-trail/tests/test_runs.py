import tempfile
import unittest
from pathlib import Path

from backend.core import Runner, Store
from test_core import FakeModels, config


class TopicScout:
    """Returns papers whose ids and text depend on the topic, like a real search."""
    def __init__(self):
        self.calls = []

    def _paper(self, topic, i, stype):
        slug = topic.split()[0].lower()
        return {'id': f'{slug}_{i}', 'title': f'{topic} paper {i}', 'source_type': stype, 'kind': 'retrieved',
                'year': 2024, 'venue': 'Joule', 'eligible': True, 'pages': [{'page': 0, 'text': f'Abstract about {topic} number {i}.'}]}

    def foundations(self, topic, policy, registry):
        return [self._paper(topic, 0, 'foundation')]

    def papers(self, topic, phase, venues, policy, registry, split=True):
        return [self._paper(topic, 1, 'journal')] if phase == 'journal' else []

    def repositories(self, *args):
        return []


class RunScopeTests(unittest.TestCase):
    def run_topic(self, store, topic):
        models = FakeModels()
        r = store.create_run('ws1', config(topic=topic, policy={'require_ranked': False}))
        Runner(store, models, TopicScout()).process(store.claim('w'))
        store.resume('ws1', r['id'], [], {'policy': {'require_ranked': False}})
        Runner(store, models, TopicScout()).process(store.claim('w'))
        self.assertEqual(store.run('ws1', r['id'])['status'], 'complete')
        return r['id'], models

    def test_new_topic_does_not_see_previous_topic_papers(self):
        with tempfile.TemporaryDirectory() as d:
            store = Store(str(Path(d) / 'db.sqlite'))
            store.seed('ws1', hardware=True)  # demo seeds must never reach the agents
            self.run_topic(store, 'Perovskite stability')
            run2, models = self.run_topic(store, 'Market forecasting')
            seen = {s['id'] for _, _, ctx in models.calls for s in ctx.get('sources', [])}
            self.assertTrue(seen)
            self.assertTrue(all(i.startswith('market_') for i in seen), seen)
            # The UI shows the latest run's papers only.
            self.assertEqual({s['id'] for s in store.run_sources('ws1', run2)}, {'market_0', 'market_1'})
            # A paper found by both runs belongs to both.
            store.put_source('ws1', {'id': 'perovskite_0', 'title': 'x'}, run2)
            self.assertIn('perovskite_0', {s['id'] for s in store.run_sources('ws1', run2)})


if __name__ == '__main__':
    unittest.main()


class QuoteMatchingTests(unittest.TestCase):
    PAGE = ('Machine-learning (ML) applied to longitudinal EHRs achieved 92% accuracy. Women who are informed '
            'that they are at increased breast cancer risk were significantly more likely to join.')

    def test_typography_differences_still_match(self):
        from backend.core import quote_found
        self.assertTrue(quote_found('Machine‑learning (ML) applied to longitudinal EHRs achieved 92 % accuracy', self.PAGE))
        self.assertTrue(quote_found('“Women who are informed that they are at increased breast cancer risk”', self.PAGE))
        self.assertTrue(quote_found('Machine-learning (ML) applied ... were significantly more likely to join.', self.PAGE))

    def test_changed_wording_or_numbers_are_rejected(self):
        from backend.core import quote_found
        self.assertFalse(quote_found('achieved 95% accuracy on longitudinal EHRs', self.PAGE))
        self.assertFalse(quote_found('ML ... join', self.PAGE))  # fragments too short to be evidence
