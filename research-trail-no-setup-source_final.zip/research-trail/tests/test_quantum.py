"""Integration boundaries for the QM profile and source-backed guide judgments."""
import json
import tempfile
import threading
import unittest
from pathlib import Path
from backend.core import Runner, Store, validate_evidence, quote_found
from test_core import FakeModels, FakeScout, config


def record(sid='qm', kind='journal'):
    return {'id':sid,'title':'Quantum channel calibration','name':sid,'source_type':kind,'kind':'retrieved',
            'venue':'Test Journal','year':2025,'eligible':True,'pages':[{'page':0,'text':'Calibration drift changes the error estimate under the stated evaluation protocol.'}]}


class QuantumWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.store=Store(str(Path(self.temp.name)/'qm.sqlite'))
    def tearDown(self):self.temp.cleanup()

    def test_journal_led_frontier_and_visible_ranking(self):
        scout=FakeScout();models=FakeModels()
        run=self.store.create_run('workspace1',config(publication_profile='journal_led',venues_confirmed=True))
        Runner(self.store,models,scout).process(run)
        result=self.store.run('workspace1',run['id'])
        self.assertEqual(result['status'],'complete')
        self.assertEqual(scout.calls[:4],['foundations','journal','conference','repositories'])
        self.assertTrue(any(e['role']=='ranker' for e in result['events']))

    def test_advanced_countersearch_keeps_the_users_question_and_older_prior_art(self):
        class Scout(FakeScout):
            def papers(self,topic,phase,venues,policy,registry,split=True):
                self.calls.append((topic,split,policy.get('recent_from')))
                return []
        scout=Scout();question='Does drift change estimator error at a fixed total sampling budget?'
        run=self.store.create_run('workspace1',config(focus_question=question,venues_confirmed=True,policy={'include_repositories':False}))
        Runner(self.store,FakeModels(),scout).process(run)
        self.assertEqual(scout.calls[-1],(question,False,1900))

    def test_explicit_seed_reuse_does_not_reuse_an_unselected_topic(self):
        self.store.put_source('workspace1',record('selected'))
        self.store.put_source('workspace1',record('unrelated'))
        run=self.store.create_run('workspace1',config(seed_source_ids=['selected'],venues_confirmed=True))
        models=FakeModels();Runner(self.store,models,FakeScout()).process(run)
        seen={s['id'] for _,_,ctx in models.calls for s in ctx['sources']}
        self.assertEqual(seen,{'selected'})

    def test_billboard_answers_and_instructions_reach_review_agents(self):
        brief={'scopeAnswers':{'interest':'noise','setting':'simulation','approach':'compare'},
               'instructions':'Include the complete calibration sampling budget.'}
        models=FakeModels()
        run=self.store.create_run('workspace1',config(brief=brief,venues_confirmed=True))
        Runner(self.store,models,FakeScout()).process(run)
        self.assertTrue(models.calls)
        for _,_,ctx in models.calls:
            self.assertIn('noise',ctx['research_brief']['scopeAnswers'])
            self.assertIn('calibration',ctx['research_brief']['instructions'])

    def test_scope_interview_keeps_exactly_three_questions(self):
        class Models(FakeModels):
            def call(self,*args):return {'questions':[{'id':str(i),'label':'Choose a direction'} for i in range(5)]}
        run=self.store.create_run('workspace1',config(guide_operation='narrowTopic',brief={'phase':'questions'}))
        Runner(self.store,Models(),FakeScout()).process(run)
        result=self.store.run('workspace1',run['id'])
        self.assertEqual(result['status'],'complete')
        self.assertEqual(len(result['result']['guide']['questions']),3)

    def test_scope_interview_with_fewer_than_three_questions_fails_visibly(self):
        class Models(FakeModels):
            def call(self,*args):return {'questions':[{'id':'only-one','label':'Choose'}]}
        run=self.store.create_run('workspace1',config(guide_operation='narrowTopic',brief={'phase':'questions'}))
        Runner(self.store,Models(),FakeScout()).process(run)
        result=self.store.run('workspace1',run['id'])
        self.assertEqual(result['status'],'failed')
        self.assertIn('Three scope questions',result['events'][-1]['message'])

    def test_parallel_source_reuse_preserves_all_run_memberships(self):
        threads=[threading.Thread(target=self.store.put_source,args=('workspace1',record(),f'run_{i}')) for i in range(8)]
        for t in threads:t.start()
        for t in threads:t.join()
        self.assertEqual(set(self.store.sources('workspace1')[0]['runs']),{f'run_{i}' for i in range(8)})

    def test_landscape_without_passages_is_uncertain_and_sources_are_filtered(self):
        class Scout(FakeScout):
            def foundations(self,*args):return [record()]
        class Models(FakeModels):
            def call(self,*args):
                return {'landscape':[{'title':'Drift','status':'Well explored','reason':'A proposed interpretation.',
                                     'source_ids':['qm','invented'],'evidence':[]}]}
        run=self.store.create_run('workspace1',config(guide_operation='landscape',brief={'field':'Quantum mechanics'}))
        Runner(self.store,Models(),Scout()).process(run)
        result=self.store.run('workspace1',run['id'])['result']['guide']['landscape'][0]
        self.assertEqual(result['status'],'Uncertain');self.assertEqual(result['source_ids'],['qm'])

    def test_open_questions_keep_only_retrieved_source_identifiers(self):
        class Scout(FakeScout):
            def foundations(self,*args):return [record()]
        class Models(FakeModels):
            def call(self,*args):
                return {'questions':[{'title':'Noise','question':'What changes as the environment changes?',
                                     'why':'A broad learning direction.','source_ids':['qm','fabricated']}]}
        run=self.store.create_run('workspace1',config(guide_operation='openQuestions',brief={'field':'Quantum mechanics'}))
        Runner(self.store,Models(),Scout()).process(run)
        q=self.store.run('workspace1',run['id'])['result']['guide']['questions'][0]
        self.assertEqual(q['source_ids'],['qm'])

    def test_quote_fragments_remain_ordered_and_numeric_changes_fail(self):
        text='The measured error is 2.4 percent. Calibration uses additional samples. The protocol keeps the complete shot budget fixed.'
        self.assertTrue(quote_found('The measured error is 2.4 percent [...] The protocol keeps the complete shot budget fixed.',text))
        self.assertFalse(quote_found('The protocol keeps the complete shot budget fixed ... The measured error is 2.4 percent',text))
        self.assertFalse(quote_found('The measured error is 1.4 percent',text))
        s=record();s['pages']=[{'page':2,'text':text}]
        good,bad=validate_evidence([{'source_id':'qm','page':1,'quote':text}],[s]);self.assertFalse(good);self.assertTrue(bad)

if __name__=='__main__':unittest.main()
