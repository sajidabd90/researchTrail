/* Small deterministic DOM harness. This does not measure browser layout. */
const decode=s=>String(s).replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&');
class Element{
 constructor(tag){this.tagName=tag;this.attrs={};this.children=[];this.parent=null;this.style={};this.listeners={};this._text='';this._value=undefined;this.checked=false;this.hidden=false;this.open=false;this.dataset=new Proxy({},{set:(o,k,v)=>{o[k]=String(v);this.attrs['data-'+k.replace(/[A-Z]/g,c=>'-'+c.toLowerCase())]=String(v);return true}})}
 setAttribute(k,v){v=String(v);this.attrs[k]=v;if(k==='id')this.id=v;if(k==='checked')this.checked=true;if(k==='disabled')this.disabled=true;if(k==='hidden')this.hidden=true;if(k==='value')this.value=v;if(k.startsWith('data-'))this.dataset[k.slice(5).replace(/-([a-z])/g,(_,x)=>x.toUpperCase())]=v}
 getAttribute(k){return this.attrs[k]}removeAttribute(k){delete this.attrs[k];if(k==='hidden')this.hidden=false}
 get parentNode(){return this.parent}get isConnected(){let root=this;while(root.parent)root=root.parent;return root.tagName==='document'}
 get className(){return this.attrs.class||''}set className(v){this.attrs.class=String(v)}
 set innerHTML(s){this.children.forEach(c=>c.parent=null);this.children=[];this._text='';parse(s,this)}get innerHTML(){return this._text+this.children.map(c=>c.outerHTML).join('')}
 get outerHTML(){return '<'+this.tagName+' '+Object.entries(this.attrs).map(([k,v])=>k+'="'+v+'"').join(' ')+'>'+this.innerHTML+'</'+this.tagName+'>'}
 get textContent(){return this._text+this.children.map(c=>c.textContent).join('')}set textContent(s){this.children.forEach(c=>c.parent=null);this.children=[];this._text=String(s)}
 get value(){if(this._value!==undefined)return this._value;if(this.tagName==='select'){const options=this.querySelectorAll('option');return(options.find(o=>Object.hasOwn(o.attrs,'selected'))||options[0])?.attrs.value||''}return this.tagName==='textarea'?this.textContent:''}set value(v){this._value=String(v)}
 append(...els){els.forEach(e=>{e.remove();e.parent=this;this.children.push(e)})}appendChild(e){this.append(e);return e}insertBefore(e,before){e.remove();e.parent=this;const idx=this.children.indexOf(before);this.children.splice(idx<0?this.children.length:idx,0,e)}
 remove(){if(this.parent){this.parent.children=this.parent.children.filter(x=>x!==this);this.parent=null}}
 replaceWith(el){const parent=this.parent;if(!parent)return;const at=parent.children.indexOf(this);el.remove();parent.children.splice(at,1,el);el.parent=parent;this.parent=null}
 replaceChildren(...elements){this.children.forEach(c=>c.parent=null);this.children=[];this._text='';this.append(...elements)}
 addEventListener(e,f){(this.listeners[e]??=[]).push(f)}
 get document(){let root=this;while(root.parent)root=root.parent;return root.ownerDocument}
 async dispatch(type,details={}){const ev={target:this,button:0,preventDefault(){this.defaultPrevented=true},stopPropagation(){this.propagationStopped=true},...details};const doc=this.document;let node=this;while(node){for(const f of node.listeners[type]||[])await f(ev);if(ev.propagationStopped)return ev;node=node.parent}for(const f of doc?.handlers[type]||[])await f(ev);return ev}
 click(){return this.dispatch('click')}
 showModal(){if(this.open)throw Error('Already open');this.open=true}close(){this.open=false}
 querySelector(s){return this.querySelectorAll(s)[0]||null}querySelectorAll(s){const out=[];const visit=e=>{for(const c of e.children){if(matches(c,s))out.push(c);visit(c)}};visit(this);return out}
 closest(selector){let el=this;while(el){if(matches(el,selector))return el;el=el.parent}return null}
 matches(selector){return matches(this,selector)}contains(el){return el===this||this.children.some(c=>c.contains(el))}
 focus(){this.focused=true;if(this.document)this.document.activeElement=this}
 getBoundingClientRect(){return{width:1000,height:620,left:0,top:0}}setPointerCapture(){}
 get viewBox(){const v=(this.attrs.viewBox||'0 0 1000 620').split(' ').map(Number);return{baseVal:{x:v[0],y:v[1],width:v[2],height:v[3]}}}
}
function matches(el,s){if(s.includes(','))return s.split(',').some(part=>matches(el,part.trim()));if(s.startsWith('#'))return el.id===s.slice(1);const classes=[...s.matchAll(/\.([\w-]+)/g)].map(m=>m[1]);if(classes.some(c=>!(el.attrs.class||'').split(' ').includes(c)))return false;const tag=s.match(/^[\w-]+/)?.[0];if(tag&&el.tagName!==tag)return false;const attrs=[...s.matchAll(/\[([\w-]+)(?:="([^"]*)")?\]/g)];return !!(tag||classes.length||attrs.length)&&attrs.every(([,k,v])=>Object.hasOwn(el.attrs,k)&&(v===undefined||el.attrs[k]===v))}
function parse(s,container){const stack=[container];for(const t of s.match(/<[^>]+>|[^<]+/g)||[]){if(t.startsWith('</')){if(stack.length>1)stack.pop();continue}if(t.startsWith('<')){if(t.startsWith('<!'))continue;const tag=t.match(/^<([\w-]+)/)?.[1];if(!tag)continue;const e=new Element(tag);for(const a of t.slice(tag.length+1).matchAll(/([\w-]+)(?:="([^"]*)")?/g))e.setAttribute(a[1],a[2]===undefined?'':decode(a[2]));stack.at(-1).append(e);if(!['input','br','hr','meta','link','img'].includes(tag)&&!t.endsWith('/>'))stack.push(e)}else stack.at(-1)._text+=decode(t)}}
Object.defineProperty(Element.prototype,'classList',{get(){const el=this;return {add(...xs){el.attrs.class=[...new Set([...(el.attrs.class||'').split(' '),...xs])].join(' ')},remove(...xs){el.attrs.class=(el.attrs.class||'').split(' ').filter(x=>!xs.includes(x)).join(' ')},toggle(x,on){const has=(el.attrs.class||'').split(' ').includes(x),next=on===undefined?!has:on;next?this.add(x):this.remove(x);return next},contains(x){return(el.attrs.class||'').split(' ').includes(x)}}}});
module.exports={Element,parse,matches};
