import base64
import json
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

from backend.core import Store
from backend.server import make_handler
from test_core import config, pdf_fixture


class HTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.store = Store(str(Path(cls.temp.name) / 'http.sqlite'))
        cls.server = ThreadingHTTPServer(('127.0.0.1', 0), make_handler(cls.store, 'test-token'))
        cls.url = 'http://127.0.0.1:' + str(cls.server.server_port)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=2)
        cls.temp.cleanup()

    def request(self, path, body=None, auth=True, workspace='httpworkspace'):
        headers = {'Content-Type': 'application/json', 'X-Workspace-ID': workspace}
        if auth:
            headers['Authorization'] = 'Bearer test-token'
        req = urllib.request.Request(self.url + path, data=json.dumps(body).encode() if body is not None else None, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=50) as r:
                return r.status, r.read().decode()
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode()

    def test_auth_health_and_static_boundary(self):
        self.assertEqual(self.request('/api/health', auth=False)[0], 401)
        self.assertTrue(json.loads(self.request('/api/health')[1])['ok'])
        code, html = self.request('/')
        self.assertEqual(code, 200)
        self.assertIn('__TRAIL_BOOTSTRAP__', html)
        self.assertNotIn('const EMBEDS=__EMBEDS__', html)
        self.assertEqual(self.request('/backend/core.py')[0], 404)
        self.assertEqual(self.request('/data/trail.sqlite')[0], 404)

    def test_real_pdf_ingestion_and_namespaced_lookup(self):
        code, raw = self.request('/api/upload', {'files': [{'name': 'starting-paper.pdf', 'data': base64.b64encode(pdf_fixture()).decode()}]})
        self.assertEqual(code, 200)
        result = json.loads(raw)['results'][0]
        self.assertTrue(result['ok'], result)
        self.assertEqual(result['source']['page_count'], 1)
        self.assertIn('indexing overhead', result['source']['pages'][0]['text'])
        self.assertTrue(json.loads(self.request('/api/sources')[1])['sources'])
        self.assertEqual(json.loads(self.request('/api/sources', workspace='otherworkspace')[1])['sources'], [])

    def test_job_creation_scope_and_terminal_cancel(self):
        code, raw = self.request('/api/runs', {'config': config()})
        self.assertEqual(code, 201)
        r = json.loads(raw)
        self.assertEqual(r['status'], 'queued')
        self.assertEqual(self.request('/api/runs/' + r['id'], workspace='otherworkspace')[0], 400)
        self.assertEqual(self.request('/api/runs/' + r['id'] + '/resume', {'venues': ['ISCA']})[0], 400)
        self.assertEqual(self.request('/api/runs/' + r['id'] + '/cancel', {})[0], 200)
        self.assertEqual(json.loads(self.request('/api/runs/' + r['id'])[1])['status'], 'cancelled')

    def test_sources_can_be_scoped_to_an_owned_run(self):
        run = self.store.create_run('runhttpworkspace', config())
        for sid in ('current', 'unrelated'):
            self.store.put_source('runhttpworkspace', {'id':sid,'name':sid,'source_type':'journal'}, run['id'] if sid=='current' else 'another_run')
        code,raw=self.request('/api/sources?run_id='+run['id'], workspace='runhttpworkspace')
        self.assertEqual(code,200)
        self.assertEqual([s['id'] for s in json.loads(raw)['sources']],['current'])
        self.assertEqual(self.request('/api/sources?run_id='+run['id'],workspace='otherworkspace')[0],400)

    def test_live_initialization_has_no_example_sources(self):
        code,raw=self.request('/api/init',{},workspace='cleanworkspace')
        self.assertEqual(code,200)
        self.assertEqual(json.loads(raw)['sources'],[])

    def test_guide_endpoint_is_durable_and_idempotent(self):
        body={'operation':'narrowTopic','brief':{'topic':'Materials','phase':'questions'},'config':config(),'clientRequestId':'guide_http_test'}
        code,raw=self.request('/api/guide',body)
        self.assertEqual(code,201);run=json.loads(raw)
        self.assertEqual(run['config']['guide_operation'],'narrowTopic')
        self.assertEqual(run['config']['topic'],'Materials')
        self.assertEqual(json.loads(self.request('/api/guide',body)[1])['id'],run['id'])
        self.assertEqual(self.request('/api/guide',{**body,'operation':'invented'})[0],400)
        self.assertEqual(self.request('/api/guide',{**body,'brief':[]})[0],400)


if __name__ == '__main__':
    unittest.main()
