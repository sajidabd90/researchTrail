import tempfile
import unittest
from datetime import date
from pathlib import Path

from backend.core import Store, eligibility
from backend.ranker import INDEX_PATH, score, sjr

TODAY = date(2026, 10, 22)


@unittest.skipUnless(INDEX_PATH.exists(), 'SJR index not built')
class RankerTests(unittest.TestCase):
    def test_journal_lookup_full_names_abbreviations_and_issn(self):
        self.assertEqual(sjr().lookup('Adv. Energy Mater.')['title'], 'Advanced Energy Materials')
        self.assertEqual(sjr().lookup('J. Am. Chem. Soc.')['title'], 'Journal of the American Chemical Society')
        self.assertEqual(sjr().lookup('', ['1614-6840'])['title'], 'Advanced Energy Materials')
        self.assertIsNone(sjr().lookup('Some Random Workshop on Things'))

    def test_scores_rank_impactful_q1_papers_above_unknown_ones(self):
        strong = score({'source_type': 'journal', 'venue': 'Nature Energy', 'year': 2022, 'citations': 900, 'retrieval_relevance': 0.9}, TODAY)
        weak = score({'source_type': 'journal', 'venue': 'Unknown Bulletin', 'year': 2022, 'citations': 3, 'retrieval_relevance': 0.2}, TODAY)
        self.assertGreater(strong['rank_score'], weak['rank_score'])
        self.assertIn('Q1 journal (SJR 2025)', strong['rank_reasons'])
        self.assertTrue(strong['summary'].startswith('Rank '))
        self.assertEqual(weak['rank_status'], 'unverified')  # unknown venues are never given a tier

    def test_recent_papers_not_penalized_for_few_total_citations(self):
        new = score({'source_type': 'journal', 'venue': 'Joule', 'year': 2026, 'citations': 40}, TODAY)
        old = score({'source_type': 'journal', 'venue': 'Joule', 'year': 2016, 'citations': 200}, TODAY)
        self.assertGreater(new['citations_per_year'], old['citations_per_year'])
        self.assertGreater(new['rank_score'], old['rank_score'])

    def test_repositories_ranked_by_stars(self):
        big = score({'source_type': 'repository', 'stars': 8000}, TODAY)
        small = score({'source_type': 'repository', 'stars': 200}, TODAY)
        self.assertGreater(big['rank_score'], small['rank_score'])

    def test_sjr_quartile_drives_journal_eligibility_without_manual_registry(self):
        policy = {'require_ranked': True, 'journal_quartiles': ['Q1', 'Q2']}
        self.assertEqual(eligibility({'source_type': 'journal', 'venue': 'Solar RRL', 'year': 2024}, policy, []), (True, 'registry_supplied'))
        self.assertEqual(eligibility({'source_type': 'journal', 'venue': 'Unknown Bulletin', 'year': 2024}, policy, []), (False, 'unverified'))

    def test_store_returns_sources_sorted_by_rank(self):
        with tempfile.TemporaryDirectory() as d:
            store = Store(str(Path(d) / 'db.sqlite'))
            store.put_source('ws1', {'id': 'a', 'source_type': 'journal', 'venue': 'Unknown Bulletin', 'year': 2020, 'citations': 1})
            store.put_source('ws1', {'id': 'b', 'source_type': 'journal', 'venue': 'Nature Energy', 'year': 2020, 'citations': 2000})
            self.assertEqual([s['id'] for s in store.sources('ws1')], ['b', 'a'])


if __name__ == '__main__':
    unittest.main()
