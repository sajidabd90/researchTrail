import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from backend.core import Store, Runner, Scout, validate_config, validate_output, bound_context, compact
from backend.guide import media_resources
from test_core import FakeModels, FakeScout, config


def source(sid, kind='conference', value=12):
    return {'id':sid,'title':sid+' study','name':sid,'source_type':kind,'year':2025,'eligible':True,'kind':'retrieved',
            'url':'https://example.edu/'+sid,'venue':'Test Conference','pages':[{'page':0,'text':f'The measured energy is {value} mJ on dataset D using platform P and protocol R.'}]}


class VisualWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.store=Store(str(Path(self.temp.name)/'test.sqlite'))
    def tearDown(self):self.temp.cleanup()

    def test_idempotency_survives_store_reopen_and_rejects_changed_brief(self):
        cfg=config(client_request_id='same-click')
        a=self.store.create_run('workspace1',cfg)
        reopened=Store(self.store.url)
        b=reopened.create_run('workspace1',dict(reversed(list(cfg.items()))))
        self.assertEqual(a['id'],b['id'])
        self.assertNotEqual(a['id'],reopened.create_run('workspace2',cfg)['id'])
        with self.assertRaises(ValueError):self.store.create_run('workspace1',{**cfg,'topic':'Different topic'})

    def test_reader_phases_isolate_recent_evidence_but_keep_seed_papers(self):
        for sid,kind in [('old','foundation'),('conf','conference'),('journal','journal'),('upload','uploaded_paper')]:
            s=source(sid,kind)
            if sid=='old':s['foundational']=True
            if sid=='upload':s['kind']='upload'
            self.store.put_source('workspace1',s)
        models=FakeModels();r=self.store.create_run('workspace1',config(expand_search=False,venues_confirmed=True))
        Runner(self.store,models,FakeScout()).process(r)
        calls=[(task,{s['id'] for s in context['sources']}) for role,task,context in models.calls if role=='reader']
        self.assertEqual(calls[0][1],{'old','upload'})
        self.assertEqual(calls[1][1],{'conf','upload'})
        self.assertEqual(calls[2][1],{'journal','upload'})

    def test_summary_cannot_reintroduce_rejected_numeric_claim(self):
        result=validate_output({'summary':'Energy improved by 99%.','claims':[{'text':'Energy improved by 99%.','evidence':[]}]},[])
        self.assertEqual(result['summary'],'')
        self.assertIn('99%',result['summary_draft'])
        self.assertEqual(len(result['unverified_claims']),1)

    def test_measurements_require_matching_number_and_same_source(self):
        s=source('a');proof={'source_id':'a','page':0,'quote':s['pages'][0]['text']}
        observation={'source_id':'a','metric':'energy','value':12,'unit':'mJ','method_tags':['quantization'],'evidence':[proof]}
        good=validate_output({'observations':[observation]},[s])
        self.assertEqual(len(good['observations']),1)
        self.assertEqual(validate_output({'observations':[{**observation,'value':99}]},[s])['observations'],[])
        self.assertEqual(validate_output({'observations':[{**observation,'source_id':'b'}]},[s,source('b')])['observations'],[])
        self.assertEqual(validate_output({'observations':[{**observation,'value':float('nan')}]},[s])['observations'],[])

    def test_large_guide_brief_stays_inside_entire_context_budget(self):
        context={'research_brief':{'topic':'Hardware','question':'Explain the next step','notes':'x'*30000,'answers':{'a':'y'*20000}},'sources':[],'excerpts':[]}
        self.assertLessEqual(len(compact(bound_context(context,4000))),4000)

    def test_live_guide_returns_only_retrieved_paper_urls(self):
        class GuideModels(FakeModels):
            def call(self,role,settings,task,context):
                return {'topics':[{'id':'q','title':'Quantization','simple':'Low precision','source_ids':['a','invented'],
                                   'papers':[{'title':'Invented','url':'https://invented.invalid'}]}]}
        class GuideScout(FakeScout):
            def foundations(self,*args):return [source('a','foundation')]
        r=self.store.create_run('workspace1',config(guide_operation='discoverTopics',brief={'field':'Hardware'}))
        Runner(self.store,GuideModels(),GuideScout()).process(r)
        result=self.store.run('workspace1',r['id'])
        self.assertEqual(result['status'],'complete')
        papers=result['result']['guide']['topics'][0]['papers']
        self.assertEqual([p['url'] for p in papers],['https://example.edu/a'])

    def test_live_guide_failure_never_becomes_demo_output(self):
        r=self.store.create_run('workspace1',config(guide_operation='narrowTopic',brief={'phase':'questions'}))
        Runner(self.store,FakeModels(fail='coordinator'),FakeScout()).process(r)
        result=self.store.run('workspace1',r['id'])
        self.assertEqual(result['status'],'failed');self.assertNotIn('guide',result['result'])

    def test_video_resources_use_search_metadata_and_do_not_leak_key_on_error(self):
        def transport(url):
            return {'results':[{'url':'https://video.example.edu/lecture','title':'A lecture','thumbnail':'https://video.example.edu/cover.jpg'}]}
        with patch.dict(os.environ,{'TRAIL_SEARCH_URL':'http://search.local'},clear=True):
            resources,note=media_resources('hardware',transport)
            self.assertEqual(resources[0]['url'],'https://video.example.edu/lecture');self.assertEqual(note,'')
        def broken(url):raise RuntimeError(url)
        with patch.dict(os.environ,{'YOUTUBE_API_KEY':'private-value'},clear=True):
            resources,note=media_resources('hardware',broken)
            self.assertEqual(resources,[]);self.assertNotIn('private-value',note)

    def test_bond_phase_without_conference_results_falls_back_to_crossref(self):
        calls=[]
        def transport(url,**kwargs):
            calls.append(url)
            return {'message':{'items':[{'DOI':'10.000/test','title':['A real conference record'],'container-title':['Test Conference'],'type':'proceedings-article','published':{'date-parts':[[2025]]}}]}}
        scout=Scout(transport);scout._bond_search=lambda topic:[source('j','journal')|{'venue':'Journal of Tests'}]
        found=scout.papers('hardware','conference',[],{'require_ranked':False},[])
        self.assertEqual(len(calls),1);self.assertEqual(found[0]['source_type'],'conference')

    def test_books_are_retrieved_even_when_bond_has_old_papers(self):
        calls=[]
        def transport(url,**kwargs):
            calls.append(url)
            return {'message':{'items':[{'DOI':'10.000/book','title':['Foundations'],'type':'book','published':{'date-parts':[[2010]]}}]}}
        scout=Scout(transport);scout._bond_search=lambda topic:[source('old','journal')|{'year':2010}]
        found=scout.foundations('hardware',{'require_ranked':False},[])
        self.assertTrue(any('type%3Abook' in url for url in calls))
        self.assertEqual(found[0]['source_type'],'textbook')

    def test_background_documents_cannot_support_scientific_claims(self):
        from backend.core import validate_evidence, evidence_context
        profile=source('cv');profile['kind']='upload';profile['document_role']='background'
        proof={'source_id':'cv','page':0,'quote':profile['pages'][0]['text']}
        self.assertEqual(validate_evidence([proof],[profile])[0],[])
        self.assertEqual(evidence_context([profile],'energy',4000)['excerpts'],[])

if __name__=='__main__':unittest.main()
