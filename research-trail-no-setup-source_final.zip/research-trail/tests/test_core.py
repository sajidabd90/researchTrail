import io
import json
import tempfile
import threading
import unittest
from pathlib import Path

from backend.core import ModelClient, Runner, Scout, Store, bound_context, compact, eligibility, evidence_context, read_pdf_bytes, validate_config, validate_evidence, validate_output, venue_matches


def pdf_fixture(text='Quantization reduces weight precision while indexing overhead remains relevant.'):
    stream = f'BT /F1 12 Tf 30 150 Td ({text}) Tj ET'.encode()
    objects = [b'<< /Type /Catalog /Pages 2 0 R >>', b'<< /Type /Pages /Kids [3 0 R] /Count 1 >>', b'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 300 200] /Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>', b'<< /Length ' + str(len(stream)).encode() + b' >>\nstream\n' + stream + b'\nendstream', b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>']
    result, offsets = b'%PDF-1.4\n', [0]
    for i, obj in enumerate(objects, 1):
        offsets.append(len(result))
        result += str(i).encode() + b' 0 obj\n' + obj + b'\nendobj\n'
    xref = len(result)
    result += b'xref\n0 6\n0000000000 65535 f \n' + b''.join(f'{o:010d} 00000 n \n'.encode() for o in offsets[1:])
    return result + f'trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF'.encode()


def config(**changes):
    base = {'topic': 'Efficient neural network hardware', 'route': 'papers', 'roles': {'coordinator': {'provider': 'ollama', 'base_url': 'http://127.0.0.1:11434', 'model': 'test-model'}}, 'expand_search': True, 'include_experiments': True, 'policy': {'require_ranked': True}, 'venues_confirmed': False}
    return validate_config({**base, **changes})


class FakeModels:
    def __init__(self, fail=None):
        self.calls, self.fail = [], fail

    def call(self, role, settings, task, context):
        self.calls.append((role, task, context))
        if role == self.fail:
            raise RuntimeError('Inference endpoint unavailable')
        return {'summary': role + ' draft', 'notes': [], 'claims': [], 'edges': [], 'candidates': [{'question': 'Does joint compression lower complete energy cost?', 'rationale': 'Test a narrow condition.', 'evidence': []}] if role == 'gaps' else [], 'venues': ['ISCA', 'MLSys'] if role == 'scout' else [], 'experiments': []}


class FakeScout:
    def __init__(self):
        self.calls = []

    def foundations(self, topic, policy, registry):
        self.calls.append('foundations')
        return []

    def papers(self, topic, phase, venues, policy, registry, split=True):
        self.calls.append(phase)
        return []

    def repositories(self, *args):
        self.calls.append('repositories')
        return []


class CoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = Store(str(Path(self.temp.name) / 'test.sqlite'))

    def tearDown(self):
        self.temp.cleanup()

    def test_pdf_extraction_pages_dedup_and_rejection(self):
        data = pdf_fixture()
        s = read_pdf_bytes('study.pdf', data)
        self.assertEqual(s['page_count'], 1)
        self.assertIn('Quantization reduces', s['pages'][0]['text'])
        self.assertEqual(s['id'], read_pdf_bytes('renamed.pdf', data)['id'])
        with self.assertRaises(ValueError):
            read_pdf_bytes('not.pdf', b'not a pdf')
        with self.assertRaises(ValueError):
            read_pdf_bytes('huge.pdf', b'%PDF-' + b'x' * (10 * 1024 * 1024))
        from pypdf import PdfReader, PdfWriter
        w = PdfWriter()
        w.add_page(PdfReader(io.BytesIO(data)).pages[0])
        w.encrypt('secret')
        buffer = io.BytesIO()
        w.write(buffer)
        with self.assertRaises(ValueError):
            read_pdf_bytes('locked.pdf', buffer.getvalue())

    def test_provenance_gate_rejects_wrong_pages_and_invented_quotes(self):
        s = read_pdf_bytes('study.pdf', pdf_fixture())
        quote = s['pages'][0]['text'].strip()
        good = {'source_id': s['id'], 'page': 1, 'quote': quote}
        verified, rejected = validate_evidence([good, {**good, 'page': 9}, {**good, 'quote': 'A fabricated result about hardware speedups.'}], [s])
        self.assertEqual(len(verified), 1)
        self.assertEqual(len(rejected), 2)
        out = validate_output({'claims': [{'text': 'Grounded draft.', 'evidence': [good]}, {'text': 'Unsupported.', 'evidence': []}], 'edges': [{'a': s['id'], 'b': 'invented', 'type': 'lineage'}], 'candidates': [{'question': 'New?', 'status': 'novel'}]}, [s])
        self.assertEqual(len(out['verified_claims']), 1)
        self.assertEqual(len(out['unverified_claims']), 1)
        self.assertEqual(out['edges'], [])
        self.assertEqual(out['candidates'][0]['status'], 'unvalidated_question')

    def test_retrieval_is_bounded_and_excludes_quarantine(self):
        a = read_pdf_bytes('study.pdf', pdf_fixture())
        b = {**a, 'id': 'metadata', 'kind': 'retrieved', 'eligible': False}
        context = evidence_context([a, b], 'quantization indexing', 4000)
        self.assertEqual({e['source_id'] for e in context['excerpts']}, {a['id']})
        self.assertLessEqual(sum(len(e['text']) for e in context['excerpts']), 4000)
        context['prior_summaries'] = {str(i): 'old summaries ' * 1000 for i in range(10)}
        context['sources'] *= 40
        self.assertLessEqual(len(compact(bound_context(context, 4000))), 4000)

    def test_venue_rank_is_year_specific_and_not_invented(self):
        source = {'source_type': 'conference', 'venue': 'Example conference', 'year': 2025}
        self.assertEqual(eligibility(source, {'require_ranked': True}, []), (False, 'unverified'))
        registry = [{'venue': source['venue'], 'year': 2025, 'tier': 'A', 'source_url': 'https://example.org/registry'}]
        self.assertEqual(eligibility(source, {'conference_tiers': ['A']}, registry), (True, 'registry_supplied'))
        self.assertFalse(eligibility({**source, 'year': 2024}, {'require_ranked': True}, registry)[0])
        self.assertFalse(eligibility(source, {'conference_tiers': ['A*']}, registry)[0])
        self.assertTrue(venue_matches('Proceedings of the International Symposium on Computer Architecture', ['ISCA']))
        self.assertFalse(venue_matches('Unrelated conference', ['ISCA']))

    def test_foundations_pause_and_mandatory_conference_journal_order(self):
        models, scout = FakeModels(), FakeScout()
        r = self.store.create_run('workspace1', config())
        Runner(self.store, models, scout).process(self.store.claim('worker1'))
        paused = self.store.run('workspace1', r['id'])
        self.assertEqual(paused['status'], 'awaiting_venues')
        self.assertEqual(scout.calls, ['foundations'])
        self.assertEqual([x[0] for x in models.calls], ['coordinator', 'reader', 'scout'])
        self.store.resume('workspace1', r['id'], ['ISCA'], {'policy': {'require_ranked': False}})
        Runner(self.store, models, scout).process(self.store.claim('worker2'))
        done = self.store.run('workspace1', r['id'])
        self.assertEqual(done['status'], 'complete')
        self.assertEqual(scout.calls[:4], ['foundations', 'conference', 'journal', 'repositories'])
        self.assertTrue(next(x for x in models.calls if x[0] == 'skeptic')[2]['candidate_questions'])
        self.assertFalse(done['config']['policy']['require_ranked'])
        self.assertTrue(all(e['mode'] == 'live' for e in done['events']))

    def test_model_failure_never_becomes_replay(self):
        r = self.store.create_run('workspace1', config())
        Runner(self.store, FakeModels(fail='reader'), FakeScout()).process(self.store.claim('worker'))
        failed = self.store.run('workspace1', r['id'])
        self.assertEqual(failed['status'], 'failed')
        self.assertIn('Inference endpoint unavailable', failed['events'][-1]['message'])

    def test_user_corpus_mode_makes_no_public_retrieval_calls(self):
        models, scout = FakeModels(), FakeScout()
        r = self.store.create_run('workspace1', config(expand_search=False, venues_confirmed=True, include_experiments=False))
        Runner(self.store, models, scout).process(self.store.claim('worker'))
        self.assertEqual(self.store.run('workspace1', r['id'])['status'], 'complete')
        self.assertEqual(scout.calls, [])
        self.assertNotIn('experiment', [c[0] for c in models.calls])

    def test_custom_specialist_and_config_validation(self):
        c = config(custom_agents=[{'id': 'auditor', 'purpose': 'Audit complete energy measurement.'}], venues_confirmed=True, expand_search=False)
        models = FakeModels()
        self.store.create_run('workspace1', c)
        Runner(self.store, models, FakeScout()).process(self.store.claim('worker'))
        calls = [r[0] for r in models.calls]
        self.assertLess(calls.index('mapper'), calls.index('auditor'))
        self.assertLess(calls.index('auditor'), calls.index('gaps'))
        with self.assertRaises(ValueError):
            config(custom_agents=[{'id': 'coordinator', 'purpose': 'duplicate'}])
        with self.assertRaises(ValueError):
            config(roles={'coordinator': {'provider': 'ollama', 'base_url': 'file:///etc', 'model': 'x'}})

    def test_queue_claims_once_and_workspaces_are_namespaced(self):
        for _ in range(8):
            self.store.create_run('workspace1', config())
        claimed, lock = [], threading.Lock()
        def worker(n):
            task = self.store.claim(str(n))
            if task:
                with lock:
                    claimed.append(task['id'])
        threads = [threading.Thread(target=worker, args=(i,)) for i in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        self.assertEqual(len(set(claimed)), 8)
        with self.assertRaises(KeyError):
            self.store.run('different_project', claimed[0])

    def test_queued_cancel_is_terminal(self):
        r = self.store.create_run('workspace1', config())
        self.store.cancel('workspace1', r['id'])
        self.assertEqual(self.store.run('workspace1', r['id'])['status'], 'cancelled')
        self.assertIsNone(self.store.claim('worker'))

    def test_model_adapters_and_schema_failure(self):
        seen = []
        def transport(url, data, **kwargs):
            seen.append((url, data))
            content = json.dumps({'summary': 'Adapter response', 'claims': []})
            return {'message': {'content': content}} if '/api/chat' in url else {'choices': [{'message': {'content': content}}]}
        client = ModelClient(transport)
        cfg = config()['roles']['coordinator']
        self.assertEqual(client.call('coordinator', cfg, 'task', {})['summary'], 'Adapter response')
        client.call('reader', {**cfg, 'provider': 'chat', 'base_url': 'https://example.org/v1'}, 'task', {})
        self.assertEqual(seen[0][0], 'http://127.0.0.1:11434/api/chat')
        self.assertEqual(seen[1][0], 'https://example.org/v1/chat/completions')
        self.assertEqual(seen[0][1]['format'], 'json')
        with self.assertRaises(ValueError):
            ModelClient(lambda *a, **k: {'message': {'content': '[]'}}).call('reader', cfg, 'task', {})

    def test_repository_watchers_are_not_stars(self):
        def transport(url, **kwargs):
            if '/search/' in url:
                return {'items': [{'full_name': 'org/repo'}]}
            return {'id': 1, 'full_name': 'org/repo', 'html_url': 'https://github.com/org/repo', 'stargazers_count': 1000, 'watchers_count': 1000, 'subscribers_count': 12, 'license': {'spdx_id': 'MIT'}}
        result = Scout(transport).repositories('hardware')
        self.assertEqual(result[0]['stars'], 1000)
        self.assertEqual(result[0]['watchers'], 12)
        self.assertEqual(Scout(transport).repositories('hardware', min_watchers=20), [])


if __name__ == '__main__':
    unittest.main()
