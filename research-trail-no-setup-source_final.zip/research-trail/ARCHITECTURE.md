# Architecture

## Shared project and presentation

One project owns scope, selected concept, papers, source states, typed connections, questions, notes and runs. Beginner and Intermediate provide guided subsets; Advanced visits Papers and Question before exposing all 12 tools. Changing level preserves the project. Onboarding and research live in the same document.

| Module | Responsibility |
| --- | --- |
| `trail-markup.html`, `trail-base.css`, `trail-flow.js` | Supplied three-road landing and billboard forms, route drafts and three-question interview |
| `trail-adapter.js`, `trail-merge.css` | Direct handoff to shared project, Demo/Live agent calls and integrated layout |
| `workspace.js` | Journey state, agent triggers, authenticated API, persistence, exports and source inspection |
| `canvas.js` | Accessible SVG concept/paper maps and interactive lens views |
| `visuals.js` | Pure corpus projections, method intersections and comparable metric cohorts |
| `quantum-data.js` | Curated metadata, short primary abstract excerpts and labeled prepared interpretations |
| `demo-provider.js` | Synthetic benchmark fixture, isolated from the real paper corpus |
| `docs/user-guide.json` | Shared user guide, storyboard and narration |
| `build.py` | Self-contained offline HTML bundle |

Panels move into a root modal dialog for fullscreen. The original billboard uses the entire trail root as its portal node, preserving delegated handlers while the content changes. The Intermediate axis caption is a separate HTML element below the SVG. First entry to a level restores its billboards; completed levels use the shared workspace. There is no embedded onboarding iframe or transformed ancestor governing fullscreen dimensions. Renders restore an expanded panel by identity; Escape restores its location and focus. Dense diagrams scroll on small screens.

## Explicit execution contexts

Demo and Live are separate project snapshots. Demo runs deterministic, cancellable playback and makes no model, retrieval or PDF-reading request. Real source records, short curated excerpts and synthetic measurements have distinct provenance states. Only the isolated benchmark can supply toy observations. Synthetic records are excluded from research exports.

Connect Live clears prepared outputs before loading sources. Failures remain failures. Provider credentials are backend environment variables; the workspace token is in browser memory only. Live source text stays on the service. The server UI can restore jobs after reconnecting; standalone demonstration files force Demo on load.

## Agent and source boundaries

The coordinator, scout, reader, mapper, gap investigator, skeptic and experiment designer use independently configurable Ollama/chat adapters. Deterministic ranking supplies a visible role with score factors. Up to three custom specialists run after mapping. Model-authored commands are never executed.

The controller enforces foundations before frontier retrieval. A publication profile selects journal-led order for QM or conference-first order for computing. A full review pauses for venue selection. It then ranks and reads phase-specific evidence, maps the corpus, proposes candidates, counter-searches, challenges the question and optionally proposes an experiment. Navigation does not create jobs. The original Explore interview requests exactly three scope questions, while later suggestions consume their answers. Final review configuration carries the accepted research brief, notes and instructions into bounded specialist context.

Bond belongs to the scout’s retrieval boundary, using the existing adapter and cache. Crossref supplies missing metadata and fallback retrieval. Repository discovery preserves license, stars and real subscribers. Retrieved abstracts do not imply full-text reading. Access, ranking and relevance remain separate concepts.

## Durable jobs and corpus isolation

`POST /api/guide` and `POST /api/runs` use the same durable worker queue. Workspace-scoped request keys prevent duplicate job creation. Cancellation acts between tasks; a request already in flight may finish. Stale recovery is explicit and may repeat a partially completed stage.

A source carries run memberships. A run sees its discoveries, explicit `seed_source_ids` and project uploads. It does not inherit unrelated prior searches. Source reuse retains earlier foundation classification and richer indexed content. SQLite source updates lock transactionally to preserve concurrent run memberships. The existing PostgreSQL queue path uses worker claim locking; PostgreSQL operation was not exercised here.

`GET /api/sources?run_id=...` first validates that the run belongs to the workspace. It returns that run’s corpus. Workspaces are namespace boundaries, not a production identity system.

## Evidence contracts

Abstract excerpts use page 0; uploaded PDF pages start at 1. Background documents are excluded from scientific evidence. Quotations must match eligible indexed text with typography normalization and ordered, adequately long ellipsis fragments. Numerical observations must include the same number in a matching passage from the same source.

Summaries cannot reintroduce rejected claims. Inferred edges remain distinguishable. Live landscape classifications without matched evidence become Uncertain. Candidate statuses remain unvalidated: matching provenance does not establish entailment, completeness or novelty. Closest work, counterevidence and the human interpretation remain visible.

Tradeoff cohorts require known matching task, dataset, platform, protocol and baseline. Metric units remain separate. A frontier is drawn only with explicit optimization directions. Counts and empty cells describe this corpus, not the whole field.

## Validation

45 Python tests and five Node suites cover the primary contracts and complete three-level click flow. Local HTTP, PDF extraction, SQLite and controlled provider/retrieval fixtures were exercised. Browser rendering was blocked by a missing Chromium binary. External providers, a real QM agent review, Docker and PostgreSQL were not verified.
