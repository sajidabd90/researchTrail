"""Minimal Valency Bond (MCP over streamable HTTP) client, standard library only.

Configure with environment variables:
  BOND_URL    MCP endpoint (default https://mcp.valency.io/)
  BOND_TOKEN  bearer token from https://app.valency.io/settings
  BOND_SEARCH_TOOL  optional: exact search tool name (auto-detected otherwise)

Inspect what Bond offers:  python -m backend.bond "perovskite solar cell stability"
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import sys
import urllib.request


class BondError(RuntimeError):
    pass


def configured():
    return bool(os.environ.get('BOND_TOKEN'))


class BondClient:
    def __init__(self, url=None, token=None, timeout=60):
        self.url = url or os.environ.get('BOND_URL') or 'https://mcp.valency.io/'
        self.protocol = '2025-11-25'
        self.token = token or os.environ.get('BOND_TOKEN', '')
        self.timeout = timeout
        self.session = None
        self.next_id = 1
        self._tools = None
        if not self.url or not self.token:
            raise BondError('Set BOND_TOKEN (from https://app.valency.io/settings)')

    # --- JSON-RPC transport -------------------------------------------------
    def _post(self, message):
        headers = {
            'Authorization': 'Bearer ' + self.token,
            'Content-Type': 'application/json',
            'Accept': 'application/json, text/event-stream',
            'MCP-Protocol-Version': self.protocol,
        }
        if self.session:
            headers['Mcp-Session-Id'] = self.session
        req = urllib.request.Request(self.url, data=json.dumps(message).encode(), headers=headers, method='POST')
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                self.session = r.headers.get('Mcp-Session-Id') or self.session
                body = r.read().decode('utf-8', 'replace')
                ctype = r.headers.get('Content-Type', '')
        except urllib.error.HTTPError as e:
            raise BondError(f'Bond HTTP {e.code}: {e.read()[:300]!r}') from None
        if 'id' not in message:
            return None  # notification
        if 'text/event-stream' in ctype:
            # Take the JSON-RPC response that matches our request id from the SSE stream.
            for block in body.split('\n\n'):
                data = '\n'.join(l[5:].lstrip() for l in block.splitlines() if l.startswith('data:'))
                if data:
                    msg = json.loads(data)
                    if msg.get('id') == message['id']:
                        return self._result(msg)
            raise BondError('No response in Bond event stream')
        return self._result(json.loads(body))

    @staticmethod
    def _result(msg):
        if 'error' in msg:
            raise BondError(f"Bond error: {msg['error']}")
        return msg.get('result', {})

    def _rpc(self, method, params=None):
        msg = {'jsonrpc': '2.0', 'id': self.next_id, 'method': method, 'params': params or {}}
        self.next_id += 1
        return self._post(msg)

    def connect(self):
        if self.session is None:
            init = self._rpc('initialize', {'protocolVersion': self.protocol, 'capabilities': {},
                                            'clientInfo': {'name': 'research-trail', 'version': '0.1'}})
            self.protocol = init.get('protocolVersion') or self.protocol  # use the negotiated version
            self._post({'jsonrpc': '2.0', 'method': 'notifications/initialized'})
        return self

    # --- tools --------------------------------------------------------------
    def tools(self):
        if self._tools is None:
            self.connect()
            self._tools = self._rpc('tools/list').get('tools', [])
        return self._tools

    def call(self, name, arguments):
        self.connect()
        result = self._rpc('tools/call', {'name': name, 'arguments': arguments})
        if result.get('isError'):
            raise BondError(f'Bond tool {name} failed: {str(result.get("content"))[:300]}')
        if result.get('structuredContent') is not None:
            return result['structuredContent']
        texts = [c.get('text', '') for c in result.get('content', []) if c.get('type') == 'text']
        joined = '\n'.join(texts)
        try:
            return json.loads(joined)
        except ValueError:
            return joined

    def search_tool(self):
        tools = self.tools()
        wanted = os.environ.get('BOND_SEARCH_TOOL')
        if wanted:
            for t in tools:
                if t['name'] == wanted:
                    return t
            raise BondError(f'BOND_SEARCH_TOOL {wanted} not found')
        def score(t):
            n = t['name'].lower()
            return ('search' in n) * 4 + ('semantic' in n) * 3 + ('paper' in n or 'work' in n) * 2 - ('author' in n) * 5 - ('trend' in n) * 5
        best = max(tools, key=score, default=None)
        if not best or score(best) <= 0:
            raise BondError('Could not find a Bond search tool; set BOND_SEARCH_TOOL')
        return best

    def search(self, query, limit=15, year_from=None, year_until=None):
        tool = self.search_tool()
        props = (tool.get('inputSchema') or {}).get('properties', {})
        args = {}
        qkey = next((k for k in ('query', 'q', 'text', 'search', 'question', 'prompt') if k in props), None)
        args[qkey or 'query'] = query
        for k in ('limit', 'max_results', 'top_k', 'n', 'count', 'size', 'page_size', 'k'):
            if k in props:
                args[k] = limit
                break
        # Valency uses start_date / end_date; also ask for abstracts and citation counts.
        if year_from and 'start_date' in props:
            args['start_date'] = f'{year_from}-01-01'
        if year_until and 'end_date' in props:
            args['end_date'] = f'{year_until}-12-31'
        for flag in ('include_abstract', 'enrich_citations'):
            if flag in props:
                args[flag] = True
        for k in props:
            kl = k.lower()
            if year_from and 'year' in kl and any(w in kl for w in ('from', 'start', 'min', 'after')):
                args[k] = year_from
            if year_until and 'year' in kl and any(w in kl for w in ('to', 'until', 'end', 'max', 'before')):
                args[k] = year_until
        self.last_raw = self.call(tool['name'], args)
        records = find_records(self.last_raw)
        papers, scores = [], []
        for pos, r in enumerate(records):
            p = normalize(r)
            # Prefer Bond's own relevance score (scaled to the best result); else the result position.
            sc = _first(r, 'final_score', 'relevance_score', 'semantic_score', 'score', 'relevance', 'similarity')
            try:
                sc = float(sc)
            except (TypeError, ValueError):
                sc = None
            p['retrieval_relevance'] = 1 - pos / max(1, len(records))
            scores.append(sc)
            if p['title']:
                papers.append((p, sc))
        best = max((sc for sc in scores if sc is not None and sc > 0), default=None)
        if best:
            for p, sc in papers:
                if sc is not None:
                    p['retrieval_relevance'] = max(0.0, min(1.0, sc / best))
        papers = [p for p, _ in papers]
        # Filter years client-side too, in case the tool has no year arguments.
        if year_from:
            papers = [p for p in papers if not p['year'] or p['year'] >= year_from]
        if year_until:
            papers = [p for p in papers if not p['year'] or p['year'] <= year_until]
        return papers[:limit]


# --- result normalization ----------------------------------------------------
def find_records(value):
    """Return the largest list of dicts that look like papers anywhere in the result."""
    best = []
    def walk(v):
        nonlocal best
        if isinstance(v, list):
            dicts = [x for x in v if isinstance(x, dict)]
            if dicts and any(any(k in d for k in ('title', 'name', 'headline')) for d in dicts) and len(dicts) > len(best):
                best = dicts
            for x in v:
                walk(x)
        elif isinstance(v, dict):
            for x in v.values():
                walk(x)
    walk(value)
    return best


def _first(d, *keys):
    for k in keys:
        v = d.get(k)
        if isinstance(v, list):
            v = v[0] if v else None
        if isinstance(v, dict):
            v = v.get('name') or v.get('title') or v.get('@value') or v.get('value')
        if v not in (None, ''):
            return v
    return None


def normalize(r):
    title = str(_first(r, 'title', 'name', 'headline') or '').strip()
    abstract = str(_first(r, 'abstract', 'description', 'summary', 'tldr', 'snippet', 'text') or '')
    abstract = re.sub('<[^>]+>', ' ', abstract)[:30000]
    doi = str(_first(r, 'doi', 'DOI') or '')
    ident = str(_first(r, 'identifier', '@id', 'id', 'url') or '')
    if not doi and '10.' in ident:
        doi = ident[ident.index('10.'):]
    year = _first(r, 'year', 'publication_year', 'datePublished', 'published', 'date')
    m = re.search(r'(19|20)\d{2}', str(year or ''))
    if not m:
        # Valency puts dates in a `dates` object; the earliest year there is the first publication.
        years = [int(y) for y in re.findall(r'\b((?:19|20)\d{2})-', json.dumps(r.get('dates') or r.get('datestamp') or ''))]
        m = re.match(r'.*', str(min(years))) if years else None
    # Valency's `source` is the corpus (pubmed, arxiv...), not the journal; journal names come from Crossref.
    venue = str(_first(r, 'venue', 'journal', 'isPartOf', 'container_title', 'journal_ref') or '')
    url = str(_first(r, 'url', 'link', 'pdf_url') or (('https://doi.org/' + doi) if doi else ident))
    key = (doi or ident or title).lower()
    cites = _first(r, 'citation_count', 'citationCount', 'cited_by_count', 'citations', 'is_referenced_by_count', 'times_cited', 'n_citations')
    try:
        cites = int(cites)
    except (TypeError, ValueError):
        cites = None
    issn = r.get('issn') or r.get('ISSN') or r.get('issns') or []
    if isinstance(issn, str):
        issn = [x.strip() for x in issn.split(',')]
    return {
        'id': 'bond_' + hashlib.sha256(key.encode()).hexdigest()[:20],
        'doi': doi, 'title': title, 'name': title[:90], 'venue': venue,
        'year': int(m.group(0)) if m else None, 'url': url,
        'pages': [{'page': 0, 'text': abstract}] if abstract.strip() else [],
        'provenance': 'bond' if abstract.strip() else 'bond_metadata', 'kind': 'retrieved',
        'citations': cites, 'issn': issn if isinstance(issn, list) else [],
        'corpus': str(r.get('source') or ''), 'bond_id': str(r.get('id') or ''),
    }


if __name__ == '__main__':
    client = BondClient()
    print('== Bond tools ==')
    for t in client.tools():
        props = list(((t.get('inputSchema') or {}).get('properties') or {}).keys())
        print(f"- {t['name']}: {str(t.get('description', ''))[:100]}  args={props}")
    query = ' '.join(sys.argv[1:]) or 'perovskite solar cell stability'
    tool = client.search_tool()
    print(f'\n== Using search tool: {tool["name"]} ==')
    papers = client.search(query, limit=5)
    for p in papers:
        print(f"- [{p['year']}] {p['title'][:90]} | {p['venue'][:40]} | abstract chars: {len(p['pages'][0]['text']) if p['pages'] else 0} | citations: {p['citations']}")
    if papers:
        print('\nFields Bond returns for the first paper:', sorted(find_records(client.last_raw)[0].keys()))
    if not papers:
        print('No papers parsed. Raw result (first 1500 chars):')
        print(json.dumps(client.last_raw, default=str)[:1500])
