"""Paper ranker: venue quartile (SCImago SJR), citations per year, retrieval relevance, recency.

Plain code, no model calls. Every score comes with a human-readable reason, and no rank is
guessed: an unknown venue stays "unranked" rather than being assigned a tier.

Build the SJR index once from the SCImago download (semicolon-separated CSV):
    python -m backend.ranker build path/to/scimagojr_2025.csv
"""
from __future__ import annotations

import csv
import gzip
import json
import math
import re
import sys
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INDEX_PATH = ROOT / 'config' / 'sjr_index.json.gz'
STOP = {'the', 'of', 'and', 'in', 'for', 'on', 'an', '&'}
QUARTILE_POINTS = {'Q1': 40, 'Q2': 28, 'Q3': 15, 'Q4': 8}
UNRANKED_POINTS = 12  # conferences, books, unmatched venues: neutral, not penalized to zero


def norm_title(name):
    name = (name or '').lower().replace('&', ' and ')
    name = re.sub(r'\(.*?\)', ' ', name)
    return ' '.join(re.sub(r'[^a-z0-9]+', ' ', name).split())


def norm_issn(value):
    v = re.sub(r'[^0-9xX]', '', str(value or '')).upper()
    return v if len(v) == 8 else ''


# --- index build/load --------------------------------------------------------
def build(csv_path, out=INDEX_PATH):
    with open(csv_path, encoding='utf-8-sig', newline='') as f:
        rows = list(csv.reader(f, delimiter=';'))
    head = rows[0]
    col = {name: head.index(name) for name in head if name in ('Title', 'Type', 'Issn', 'SJR', 'SJR Best Quartile', 'H index')}
    year = re.search(r'(19|20)\d{2}', Path(csv_path).name)
    journals = []
    for r in rows[1:]:
        if len(r) < len(head) or r[col['Type']] not in ('journal', 'book series', 'trade journal'):
            continue
        q = r[col['SJR Best Quartile']]
        if q not in QUARTILE_POINTS:
            continue
        sjr = float((r[col['SJR']] or '0').replace(',', '.') or 0)
        issns = [norm_issn(x) for x in r[col['Issn']].split(',') if norm_issn(x)]
        journals.append([r[col['Title']], issns, q, round(sjr, 3), int(r[col['H index']] or 0)])
    data = {'source': 'SCImago Journal Rank', 'year': int(year.group(0)) if year else None, 'journals': journals}
    out.parent.mkdir(parents=True, exist_ok=True)
    with gzip.open(out, 'wt', encoding='utf-8') as f:
        json.dump(data, f, separators=(',', ':'))
    return len(journals)


class SJR:
    def __init__(self, path=INDEX_PATH):
        self.year, self.by_issn, self.by_title, self.by_initial = None, {}, {}, {}
        if not Path(path).exists():
            return
        with gzip.open(path, 'rt', encoding='utf-8') as f:
            data = json.load(f)
        self.year = data.get('year')
        for title, issns, q, sjr, h in data['journals']:
            rec = {'title': title, 'quartile': q, 'sjr': sjr, 'h_index': h}
            for i in issns:
                self.by_issn[i] = rec
            key = norm_title(title)
            # Keep the stronger record if two journals normalize to the same name.
            if key not in self.by_title or self.by_title[key]['sjr'] < sjr:
                self.by_title[key] = rec
            words = [w for w in key.split() if w not in STOP]
            if words:
                self.by_initial.setdefault(words[0][0], []).append((words, rec))

    @property
    def loaded(self):
        return bool(self.by_title)

    def lookup(self, venue='', issns=()):
        for i in issns or ():
            rec = self.by_issn.get(norm_issn(i))
            if rec:
                return rec
        key = norm_title(venue)
        if not key:
            return None
        if key in self.by_title:
            return self.by_title[key]
        # Abbreviations such as "Adv. Energy Mater." -> "Advanced Energy Materials":
        # every abbreviated word must be a prefix of the matching full word, in order.
        abbr = [w for w in key.split() if w not in STOP]
        if not abbr:
            return None
        best = None
        for words, rec in self.by_initial.get(abbr[0][0], ()):
            if len(words) == len(abbr) and all(f.startswith(a) for a, f in zip(abbr, words)):
                if best is None or rec['sjr'] > best['sjr']:
                    best = rec
        return best


_SJR = None


def sjr():
    global _SJR
    if _SJR is None:
        _SJR = SJR()
    return _SJR


# --- scoring -----------------------------------------------------------------
def score(source, today=None):
    """Return a copy of source with rank_score (0-100), rank_reasons and rank details."""
    s = dict(source)
    year_now = (today or date.today()).year
    reasons, points = [], 0.0
    stype = s.get('source_type')

    if stype == 'repository':
        stars = s.get('stars') or 0
        impact = 55 * min(1.0, math.log10(1 + stars) / 4)  # 10k stars = full marks
        points += impact
        reasons.append(f'{stars:,} GitHub stars')
    else:
        # Venue quality (journals only; conference tiers are not used in the physical sciences).
        rec = None
        if stype not in ('textbook', 'uploaded_paper'):
            rec = sjr().lookup(s.get('venue', ''), s.get('issn') or [])
        if rec:
            points += QUARTILE_POINTS[rec['quartile']]
            s['sjr_quartile'], s['sjr_value'] = rec['quartile'], rec['sjr']
            reasons.append(f"{rec['quartile']} journal (SJR {sjr().year or ''})".replace(' )', ')'))
        else:
            points += UNRANKED_POINTS
            if stype not in ('uploaded_paper',):
                reasons.append('venue unranked')
        # Impact: citations per year since publication, so recent papers are not penalized.
        cites, year = s.get('citations'), s.get('year')
        if isinstance(cites, int) and cites >= 0 and isinstance(year, int):
            per_year = cites / max(1, year_now - year + 1)
            points += 35 * min(1.0, math.log10(1 + per_year) / math.log10(51))  # 50/yr = full marks
            s['citations_per_year'] = round(per_year, 1)
            reasons.append(f'{cites:,} citations ({per_year:.0f}/yr)')
        else:
            reasons.append('citations unknown')

    # Relevance to the query: search engine score if supplied, else position in results.
    rel = s.get('retrieval_relevance')
    if isinstance(rel, (int, float)):
        points += 20 * max(0.0, min(1.0, rel))
        if rel >= 0.75:
            reasons.append('strong topic match')

    year = s.get('year')
    if isinstance(year, int) and year >= year_now - 2:
        points += 5
        reasons.append('recent')
    elif isinstance(year, int) and year >= year_now - 5:
        points += 2.5

    s['rank_score'] = round(min(100.0, points))
    s['rank_reasons'] = reasons
    if rec_q := s.get('sjr_quartile'):
        s['rank_status'] = 'registry_supplied'
        s['rank_registry'] = f'SCImago SJR {sjr().year or ""}'.strip()
    elif not s.get('rank_status'):
        s['rank_status'] = 'unverified'
    # The frontend shows `summary` on each source card; put the explanation there.
    if not s.get('summary') or s.get('summary', '').startswith('Rank '):
        s['summary'] = f"Rank {s['rank_score']}/100 · " + ' · '.join(reasons)
    return s


def quartile_eligible(source, desired):
    """SJR-backed eligibility for journals when the user has not supplied a registry record."""
    rec = sjr().lookup(source.get('venue', ''), source.get('issn') or [])
    return (rec['quartile'] in desired, 'registry_supplied') if rec else None


if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == 'build':
        print(f'Indexed {build(sys.argv[2])} journals into {INDEX_PATH}')
    else:
        print(__doc__)
