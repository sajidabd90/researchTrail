"""Live, bounded trail jobs. Same durable queue and model routing as full reviews."""
from __future__ import annotations

import hashlib
import html
import os
import time
import urllib.parse

from .core import bound_context, evidence_context, request_json, uid, validate_output


def media_resources(topic, transport=request_json):
    """Retrieve actual video metadata; never ask a model to invent a video URL."""
    results, note = [], ''
    base = os.environ.get('TRAIL_SEARCH_URL', '').rstrip('/')
    key = os.environ.get('YOUTUBE_API_KEY', '')
    try:
        if base:
            query = urllib.parse.urlencode({'q': topic+' university lecture tutorial', 'categories':'videos', 'format':'json', 'safesearch':1})
            data = transport(base+'/search?'+query)
            for r in data.get('results', [])[:8]:
                if urllib.parse.urlsplit(str(r.get('url',''))).scheme not in ('http','https'):
                    continue
                results.append({'id': hashlib.sha256(r['url'].encode()).hexdigest()[:20], 'title': html.unescape(str(r.get('title','Lecture'))),
                                'url': r['url'], 'description': html.unescape(str(r.get('content','')))[:300],
                                'thumbnail': r.get('thumbnail') or r.get('img_src') or '', 'level':'Video lecture', 'provenance':'searxng_search'})
        elif key:
            query = urllib.parse.urlencode({'part':'snippet','q':topic+' university lecture','type':'video','maxResults':6,'key':key})
            for r in transport('https://www.googleapis.com/youtube/v3/search?'+query).get('items', []):
                video = r.get('id',{}).get('videoId'); s = r.get('snippet',{})
                if video:
                    results.append({'id':video,'title':html.unescape(s.get('title','Lecture')),'url':'https://www.youtube.com/watch?v='+video,
                                    'description':html.unescape(s.get('description',''))[:300], 'thumbnail':s.get('thumbnails',{}).get('medium',{}).get('url',''),
                                    'level':s.get('channelTitle','Video lecture'),'provenance':'youtube_search'})
        else:
            note = 'Video discovery is not connected. Search for lectures externally or ask your workspace administrator to enable it.'
    except Exception as e:
        # Do not expose key-bearing request URLs in user-visible errors.
        note = f'Video discovery is temporarily unavailable ({type(e).__name__}). Other resources are retained.'
    return results, note


def process_guide(runner, run):
    cfg, ws, rid = run['config'], run['workspace'], run['id']
    operation, brief = cfg['guide_operation'], cfg.get('brief', {})
    events = run['events']

    def checkpoint(role, message):
        if runner.store.run(ws,rid)['status'] == 'cancel_requested':
            raise InterruptedError('Guide request cancelled')
        events.append({'id':uid('ev_'),'time':time.time(),'role':role,'phase':operation,'message':message,'mode':'live'})
        runner.store.update(ws,rid,events=events,phase=operation)

    def call(role, task, sources):
        checkpoint(role, task[:180])
        context=evidence_context(sources,cfg['topic'],cfg['roles'][role]['context_chars'])
        context['research_brief']=brief
        if operation == 'personalizeTopics':
            context['profile_background'] = [
                {'name':s.get('name','Profile document'), 'text':' '.join(p['text'] for p in s.get('pages',[]))[:1200]}
                for s in sources if s.get('document_role') == 'background'
            ][:2]
        context=bound_context(context,cfg['roles'][role]['context_chars'])
        return runner.models.call(role,cfg['roles'][role],task,context)

    try:
        topic = cfg['topic']
        for s in runner.store.sources(ws):
            if s['id'] in cfg.get('seed_source_ids', []):
                runner.store.put_source(ws,s,rid)
        sources=runner.store.run_sources(ws,rid)
        if operation in ('discoverTopics','personalizeTopics','getLearningResources','openQuestions','landscape') or operation=='narrowTopic' and brief.get('phase')=='suggestions':
            checkpoint('scout','Retrieving foundational sources for '+topic)
            for s in runner.scout.foundations(topic,cfg.get('policy',{}),cfg.get('ranking_registry',[])):
                runner.store.put_source(ws,s,rid)
            if operation in ('discoverTopics','personalizeTopics','landscape','narrowTopic'):
                # Orientation metadata, after the background. No claim of full-text reading.
                phases = ('journal','conference') if cfg.get('publication_profile') == 'journal_led' else ('conference','journal')
                for phase in phases:
                    checkpoint('scout','Looking for '+phase+' directions in '+topic)
                    for s in runner.scout.papers(topic,phase,cfg.get('venues',[]) if phase=='conference' else [],cfg.get('policy',{}),cfg.get('ranking_registry',[])):
                        runner.store.put_source(ws,s,rid)
            sources=runner.store.run_sources(ws,rid)
        by_id={s['id']:s for s in sources if s.get('document_role') != 'background'}

        def resources(ids):
            return [{'id':sid,'title':by_id[sid].get('title') or by_id[sid].get('name'), 'url':by_id[sid].get('url',''),
                     'year':by_id[sid].get('year'),'description':'Retrieved source · '+str(by_id[sid].get('venue') or 'venue unknown'),
                     'provenance':by_id[sid].get('provenance','retrieved_metadata')} for sid in ids if sid in by_id][:6]

        if operation in ('discoverTopics','personalizeTopics'):
            if not any(s.get('document_role') != 'background' for s in sources):
                raise ValueError('No sources were retrieved for this field. Refine the field or retry the retrieval service.')
            data=call('mapper','Build an introductory taxonomy of '+topic+'. Return topics:[{id,title,simple,technical,whyNow,source_ids:[existing source IDs]}], and followUpQuestions:[{id,label,type,options,required}]. Use 4–8 branches. Also return edges:[{a,b,type,rationale,evidence}] between existing paper IDs, distinguishing shared method, conclusion, deployment and lineage; unsupported relations stay inferred. Connect older foundations to recent directions. Tailor to interests and feedback in research_brief. These are proposed orientations, not verified findings. Do not invent paper names, links or ranks.',sources)
            topics=[]
            for i,t in enumerate(data.get('topics',[])[:10]):
                if isinstance(t,dict) and t.get('title') and any(sid in by_id for sid in t.get('source_ids',[])):
                    topics.append({**{k:str(t.get(k,''))[:900] for k in ('title','simple','technical','whyNow')}, 'id':str(t.get('id') or 'topic-'+str(i)),
                                   'papers':resources(t.get('source_ids',[])), 'source_ids':[sid for sid in t.get('source_ids',[]) if sid in by_id]})
            if not topics:
                raise ValueError('The mapper returned no usable topic branches. Refine the field or retry.')
            output={'topics':topics,'edges':validate_output(data,sources)['edges'],'followUpQuestions':data.get('followUpQuestions',[])[:4],'sourceMode':'live',
                    'sourceNote':f'Agent-proposed taxonomy from {len(sources)} retrieved records. Open the sources to verify each branch.'}
        elif operation=='getLearningResources':
            data=call('reader','Create an accessible learning path for '+topic+'. Return introduction:string and goals:[string]. Explain prerequisites before current research. Use research_brief for interests. No invented resources or numeric claims.',sources)
            videos,note=media_resources(topic)
            output={'introduction':str(data.get('introduction',''))[:1200],'goals':[str(g)[:180] for g in data.get('goals',[])[:5]],
                    'papers':resources([s['id'] for s in sources if s.get('source_type') not in ('textbook','repository')]),
                    'books':resources([s['id'] for s in sources if s.get('source_type')=='textbook']), 'videos':videos,
                    'sourceNote':note or 'Resources retrieved for this topic. Availability and full text vary.',
                    'lectureSearchUrl':'https://www.youtube.com/results?'+urllib.parse.urlencode({'search_query':topic+' university lecture'})}
        elif operation in ('openQuestions','landscape'):
            field = 'questions' if operation == 'openQuestions' else 'landscape'
            task = ('Return questions:[{title,question,why,source_ids}] with four broad learning questions; do not claim novelty.' if operation == 'openQuestions' else
                    'Return landscape:[{title,status,reason,source_ids,evidence:[{source_id,page,quote}]}] for four to six scoped subtopics. Status is Well explored, Active, Emerging or Uncertain. Explain the search scope and evidence limits. Publication counts alone never establish saturation; do not claim exhaustive search.')
            data=call('gaps',task+' Topic: '+topic,sources)
            items=[]
            for item in data.get(field,[])[:8]:
                if not isinstance(item,dict) or not (item.get('title') or item.get('question')):
                    continue
                ids=[sid for sid in item.get('source_ids',[]) if sid in by_id]
                proof=validate_output({'claims':[{'text':item.get('reason',''),'evidence':item.get('evidence',[])}]},sources)['verified_claims']
                status=item.get('status') if proof else 'Uncertain'
                items.append({'title':str(item.get('title',''))[:180], 'question':str(item.get('question',''))[:800],
                              'why':str(item.get('why',''))[:900], 'reason':str(item.get('reason',''))[:1200],
                              'source_ids':ids, 'status':status if status in ('Well explored','Active','Emerging','Uncertain') else 'Uncertain',
                              'evidence':proof[0]['evidence'] if proof else [], 'assessment':'Agent proposal within retrieved scope'})
            if not items:
                raise ValueError('No usable source-linked directions returned. Refine the scope and retry.')
            output={field:items,'sourceMode':'live','sourceNote':'Proposed interpretation of this retrieved corpus; search coverage is incomplete.'}
        elif operation=='narrowTopic':
            if brief.get('phase')=='questions':
                data=call('coordinator','Guide scope selection for '+topic+'. Return questions:[{id,label,help,type:"choice",options:[{value,label,description}],required:true}]. Ask exactly three short, domain-specific questions about the user’s interests, setting and preferred research approach. Include an unsure option. Prefer visual choice cards. Respect the prior answers in research_brief. Do not propose a confirmed gap.',sources)
                if not isinstance(data.get('questions'),list) or len(data['questions'])<3:
                    raise ValueError('Three scope questions are required. Retry with a more specific topic.')
                output={'questions':data['questions'][:3]}
            else:
                data=call('gaps','Propose 3 focused directions for '+topic+' using research_brief answers and refinement. Return candidates:[{id,title,question,technical,simple,why,scope:{task,system,objective},keywords,source_ids}], followUpQuestions:[]. Describe where the evidence needs checking; do not claim novelty or invent papers.',sources)
                candidates=[]
                for i,c in enumerate(data.get('candidates',[])[:4]):
                    if isinstance(c,dict) and c.get('question'):
                        checked=validate_output({'candidates':[c]},sources)['candidates'][0]
                        candidates.append({**checked,'id':str(c.get('id') or i),
                                           'source_ids':[sid for sid in c.get('source_ids',[]) if sid in by_id],
                                           'papers':resources(c.get('source_ids',[]))})
                if not candidates:
                    raise ValueError('No focused directions returned. Refine your scope and retry.')
                output={'candidates':candidates,'followUpQuestions':data.get('followUpQuestions',[])[:4], 'sourceNote':'Proposed scopes awaiting literature and counter-evidence checks.'}
        else:
            data=call('coordinator','Answer the user’s navigation or terminology question in research_brief. Return answer:string. Explain the current step briefly; do not claim to have searched or read evidence that is absent.',sources)
            output={'answer':str(data.get('answer') or data.get('summary') or 'Please ask a more specific question.')[:3000]}
        checkpoint('coordinator','Live guide result ready')
        runner.store.update(ws,rid,result={'guide':output},status='complete',phase='complete',events=events,owner=None)
    except InterruptedError:
        runner.store.update(ws,rid,status='cancelled',events=events,owner=None)
    except Exception as e:
        events.append({'id':uid('ev_'),'time':time.time(),'role':'coordinator','phase':'error','message':f'{type(e).__name__}: {str(e)[:350]}','mode':'live'})
        runner.store.update(ws,rid,status='failed',events=events,owner=None)
