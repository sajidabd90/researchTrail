"""Build the editable user guide and matching in-app help content."""
from pathlib import Path
import json
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parents[1]
OUTPUT=ROOT.parent/'research-trail-user-guide.docx'

QUESTION='Under a fixed total sampling budget, when does combining readout mitigation and zero-noise extrapolation improve estimates as calibration drifts?'

PAGES=[
 {'title':'Research Trail user guide','subtitle':'Quantum mechanics walkthrough and four minute demo','intro':'Use Research Trail to understand quantum mechanics, connect its literature and develop a focused research question. Start with the path that matches your background. The same project follows you as you move between levels.',
  'sections':[
   ('Start the demonstration',[
    'Open research-trail-quantum-demo.html in a modern browser. The landing page asks three starting questions: I’m finding my direction, I already have a topic, and I have papers to build on. These lead into Beginner, Intermediate and Advanced. No model or key is required for Demo.',
    'The Demo badge identifies prepared content. Real curated paper and learning links are labeled separately from illustrative measurements and scripted analysis. A prepared candidate question is not a certified novel research gap.']),
   ('Know your workspace',[
    'Each road has billboards that guide one decision at a time. They hand your answers, papers and instructions into the research workspace. The persistent header switches levels. The journey bar shows your next task; the agent strip shows when work runs.',
    'Your notes, papers and question stay with the project. First entry to another level opens its billboards. Use My billboards to revisit them or the logo to return to the landing page. Advanced prepares papers and an exact question before opening all tools.']),
   ('Use the controls',[
    'Select a concept to see its explanation and reading links. Select a paper or graph node to open its source record. Use Group by topic or Group by venue to reorganize paper connections. Filter relationship types to inspect one kind of connection at a time.',
    'Select Fullscreen on a billboard, map, chart or dialog to expand it. Use Exit fullscreen or Escape to restore the view. Keyboard users can Tab through controls and use Enter or Space to activate a selection.'])],
  'table':(['Path','Starting point','Main outcome'],[
   ['Beginner','I want to learn QM','Field map and broad open questions'],
   ['Intermediate','I know an area','A justified research direction'],
   ['Advanced','I have papers or a question','A scoped gap investigation']])},
 {'title':'Beginner learn the field','intro':'Your goal is to leave with a map of quantum mechanics and enough background to choose what to study next. You do not need to identify a narrow gap to finish this path.',
  'sections':[
   ('Discover',[
    'Choose I’m finding my direction, then Physical sciences and Quantum mechanics. The agents propose branches on a visual domain map. Select Open systems and decoherence, then Build my learning trail.',
    'After selecting Open my field map, the workspace opens at Map. Discover, step 1, introduces the ideas through large illustrated topic cards. Map, step 3, connects concepts to literature. They serve different purposes.']),
   ('Learn',[
    'The learning billboard contains visual reading and video cards. In the workspace, select Learn or Open learning trail for prerequisites, open readings and recorded lectures. The demo links real MIT and Caltech resources.',
    'Add a short note in your notebook about what you understand and what remains unclear. Live learning discovery can retrieve resources through the connected research service.']),
   ('Map',[
    'Select Explore the field map. Unfold the papers for your selected concept, then open Paper connection graph. A topic map explains concepts; the paper graph explains relationships between studies.',
    'Select a connection and inspect its explanation. A shared method, citation, related finding and implementation are separate relationships. Inferred thematic links remain labeled.']),
   ('Open questions',[
    'Select Explore open questions. Choose a broad question and see why it matters, which concepts it touches and which readings provide background. These are learning directions rather than claims of unexplored novelty.']),
   ('Field guide',[
    'Select Save my field guide. Review your concepts, readings, broad questions and notes, then use Export field guide. You can finish here or switch to Intermediate with the same project.'])]},
 {'title':'Intermediate choose a research direction','intro':'Your goal is to see where a subtopic is well explored, where work is developing and which unresolved boundary might support a focused question.',
  'sections':[
   ('Focus',[
    'Choose I already have a topic, or switch to Intermediate. Enter Open systems and decoherence. Choose Explore at the subtopic billboard. Answer exactly three visual questions about your interests, setting and research approach; I’m not sure yet is available.']),
   ('Landscape',[
    'Choose a suggested direction and confirm it. The next billboard asks whether to add papers or instructions; either add context or skip. The workspace opens at Landscape, with status labels, source links and a separate axis caption.',
    'Select Error mitigation and inspect its basis. Well explored refers to an established bounded question; Active and Emerging describe continuing or early work. Uncertain means evidence is insufficient. Demo labels illustrate these judgments without establishing field saturation.']),
   ('Connections',[
    'Select Explore paper connections. Inspect how the papers share methods, evaluation conditions or implementation paths. Use venue grouping to see connections across publications. Open a paper record to inspect its evidence state.']),
   ('Question',[
    'Select Find a focused question. Compare the prepared candidate questions, their scope and their supporting or missing evidence. Choose the calibration-drift example for the video. Refine the wording to identify the method, setting, outcome and constraint.']),
   ('Review',[
    'Select Check this question. Watch the agent strip progress through evidence gathering, mapping and skeptical review in Demo. In Live mode these tasks call the configured backend and models.',
    'Open Review notebook. Record why the direction is worth investigating and which evidence would change your decision. Export the field guide or switch to Advanced to investigate the question in greater depth.'])],
  'table':(['Landscape label','Interpretation'],[
   ['Well explored','Established evidence for a bounded question'],['Active','Continuing methodological or empirical development'],['Emerging','Early work and limited accumulated evidence'],['Uncertain','Insufficient search coverage or readable evidence']])},
 {'title':'Advanced investigate an exact question','intro':'Your goal is to inspect a possible gap from several angles, identify the closest related work and make the remaining uncertainty explicit.',
  'sections':[
   ('Prepare papers',[
    'Choose I have papers to build on, or switch to Advanced. On the first billboard, choose the Quantum mechanics paper pack in Demo. Alternatively, select up to 15 PDFs, or Use my current project papers.',
    'Choosing a pack prepares it automatically. For PDFs, select Prepare papers and see my map. The next billboard appears after preparation. Demo retains filenames only; Live sends PDFs to the research service for indexing.']),
   ('State the question',[
    'On the second billboard, the paper map sits beside the exact-question form. Select Use the example question or type your own question. Include the system, method, outcome and constraint.',
    'Example question: '+QUESTION,
    'Add notes or search boundaries if useful. Select Investigate this question. The full workspace opens and agent progress remains visible.']),
   ('Explore all tools',[
    'Use the Field map, Literature and Paper connection graph to inspect the corpus. Eight gap lenses provide coverage, combinations, claims, evaluations, tradeoffs, implementation connections, limitations and boundaries. The same project and scope apply to every view.',
    'Open Candidate gaps and select a report. Inspect the precise question, closest prior work, supporting passages, counterevidence, scope and remaining uncertainty. Prepared examples remain labeled. A Live report can conclude that a question is already addressed or that evidence is insufficient.']),
   ('Plan and export',[
    'Open First experiments for an optional initial test with a baseline, comparison, measurements, controls and stopping rule. The app proposes a plan; it does not execute an experiment.',
    'Save your interpretation in Review notebook. Export the field guide or project evidence. Advanced exposes all 12 workspace tools, including Agent activity and Master controls.'])]},
 {'title':'Understand sources agents and setup','intro':'Inspect what the system used before relying on a conclusion. A source record, a matching passage and a defensible research interpretation are different evidence states.',
  'sections':[
   ('Where Bond is used',[
    'In Live mode the Source Scout uses connected Valency Bond to discover foundational work, recent papers and prior art. Crossref fills missing bibliographic fields and serves as a fallback. Repeated queries may reuse cached records. Bond metadata or an abstract is not full-text reading.',
    'The learning order starts with concepts and older work. Conference and journal filters depend on the field profile. The QM profile emphasizes journals and relevant conferences; A*/A/B conference grades are used only with an applicable ranking registry. Preprints remain separately labeled.']),
   ('Read an evidence record',[
    'Metadata only means no source text was indexed. Abstract indexed means the available abstract can be inspected. PDF text indexed means supplied text is available. Passage matched means a quotation was found at its stated location. Inferred describes an analytical relationship without direct supporting evidence.',
    'Illustrative benchmark values are synthetic and are not attributed to real papers. Compare their behavior to learn the visualization, then inspect real evidence separately.']),
   ('Connect Live models',[
    'Open Setup. Choose Local Ollama, Rented API or Public or shared endpoint. The starter Ollama preset is qwen3.5:9b. Enter the research-service address and access token, then the inference address and served model name. Use Test connection before running a review.',
    'Model-provider keys are configured on the backend through MODEL_API_KEY or role-specific variants. The workspace token is separate. A public model requires an operating endpoint; the demo does not supply free hosted inference. Master controls lets an administrator assign separate models to specialists.',
    'Selecting Connect Live clears scripted results before real sources load. Failed Live tasks stay visible and do not silently become demo results. You can return to the prepared demonstration using Use demo.'])],
  'table':(['Role','What you receive'],[
   ['Coordinator and scout','Scope, next task and source collection'],['Ranking specialist and reader','Reading priority, passages and background'],['Mapper and gap investigator','Relationships, open questions and candidate gaps'],['Skeptic and experiment designer','Counterevidence and an optional first test']])},
 {'title':'Four minute recording plan','intro':'Keep one project on screen as you move from Beginner to Intermediate to Advanced. Use the prepared QM example for a reproducible recording and retain its Demo labels.',
  'sections':[
   ('Before recording',[
    'Open the quantum demo and select Reset demo to begin with a clean demonstration project. Set a comfortable browser zoom and choose the preferred theme. Keep the agent strip visible. Record a short rehearsal of fullscreen and restore.',
    'The main recording uses prepared results. If you add a Live segment, test the endpoint and source connection first and identify it as a separate Live run. Keep credentials out of the recording.']),
   ('What to emphasize',[
    'Show one concept, one landscape judgment, one paper connection and one skeptical review. Explore two gap lenses in detail and leave the other six visibly available. End with the exported research brief.',
    'The claim for the video is that the tool supports evidence-backed research-question development. Do not describe the prepared candidate as a proven novel discovery.'])],
  'table':(['Time','Action','Point to communicate'],[
   ['0:00-0:20','Show the three starting questions and roads','Choose a starting point in one project'],
   ['0:20-1:00','Beginner billboards; learning cards and field map','Discover ideas before connecting literature'],
   ['1:00-1:45','Intermediate; three questions then landscape','Turn interests into a research direction'],
   ['1:45-2:20','Advanced; prepare papers and state the question','Carry context into a bounded investigation'],
   ['2:20-3:10','Inspect agents, a connection and two lenses','Trace analysis back to the evidence'],
   ['3:10-3:40','Open the gap report and skeptical review','Show related work and remaining uncertainty'],
   ['3:40-4:00','Export; briefly show Setup','Keep the result and choose your compute']])},
 {'title':'Narration for the recording','intro':'This narration follows the seven shots in the recording plan. Leave short pauses for selection, zooming and evidence inspection.',
  'sections':[
   ('Opening',[
    'Research Trail helps us move from learning a field to developing a research question we can defend with evidence. This demonstration uses quantum mechanics. Beginner, Intermediate and Advanced are three starting points into one project.']),
   ('Beginner',[
    'We choose the discovery road, Physical sciences and Quantum mechanics. The billboards help us find a branch and build a learning trail. We choose open systems and decoherence. Reading and video cards introduce the foundations. The workspace separates Discover, which builds intuition, from Map, which connects ideas to papers. Broad open questions help us choose what to study next. We can export our map, reading list and notes as a field guide.']),
   ('Intermediate',[
    'Intermediate begins with our topic and three short questions about interests, setting and approach. We choose a suggested direction, then decide whether to add papers or instructions. Our project continues into the research landscape. We inspect error mitigation, its source links and the basis for its label. The labels distinguish established questions, active work, emerging directions and insufficient evidence. A large publication count alone cannot establish saturation.']),
   ('Advanced',[
    'Advanced begins with two steps. First, prepare our starting papers. We can upload a focused collection or choose the prepared QM pack. The map appears after this step. Next, we put an exact question beside it. Here we ask whether combining readout mitigation with zero-noise extrapolation helps under calibration drift when the complete sampling budget is fixed. That scope gives the investigation something concrete to test.']),
   ('Evidence and agents',[
    'The coordinator organizes discovery, ranking, reading and mapping. In Live mode the source scout can use Valency Bond and connected bibliographic services. The paper connection graph distinguishes shared methods, citation relationships and implementation connections. Each relationship has an explanation. Selecting a paper opens its source record. The eight lenses inspect the same corpus from different angles; here we compare evidence coverage and a tradeoff. The prepared numerical example is labeled illustrative.']),
   ('Skeptical review',[
    'A possible gap becomes useful when we examine the closest prior work and the evidence against it. The skeptical review can narrow the question, find an existing answer or report insufficient evidence. This prepared report demonstrates that process. It does not certify novelty. An optional first experiment identifies a baseline, measurements, controls and a stopping rule.']),
   ('Closing',[
    'We leave with a field map, a connected review and a bounded research question. The project can use managed inference, local Ollama or a compatible external API. The no-setup demo runs without a model. Our goal is to help researchers understand the evidence and choose a direction they can justify.'])]}
]

def shade(cell,fill):
    pr=cell._tc.get_or_add_tcPr();node=OxmlElement('w:shd');node.set(qn('w:fill'),fill);pr.append(node)

def table(doc,headers,rows,widths=None):
    t=doc.add_table(rows=1, cols=len(headers));t.autofit=False
    if widths:
        for c,w in zip(t.columns,widths):c.width=Inches(w)
    for cell,text in zip(t.rows[0].cells,headers):
        shade(cell,'DFE8EF');cell.text=text
        for run in cell.paragraphs[0].runs:run.bold=True
    for row in rows:
        for cell,text in zip(t.add_row().cells,row):cell.text=text
    borders=OxmlElement('w:tblBorders')
    for side in ('top','left','bottom','right','insideH','insideV'):
        x=OxmlElement('w:'+side);x.set(qn('w:val'),'single');x.set(qn('w:sz'),'4');x.set(qn('w:color'),'D9D9D9');borders.append(x)
    t._tbl.tblPr.append(borders)
    for row in t.rows:
        for cell in row.cells:
            cell.vertical_alignment=1
            margins=OxmlElement('w:tcMar')
            for side in ('top','left','bottom','right'):
                n=OxmlElement('w:'+side);n.set(qn('w:w'),'90');n.set(qn('w:type'),'dxa');margins.append(n)
            cell._tc.get_or_add_tcPr().append(margins)
            for p in cell.paragraphs:
                p.paragraph_format.space_after=Pt(3);p.paragraph_format.space_before=Pt(2);p.paragraph_format.line_spacing=1.08
                for run in p.runs:run.font.size=Pt(10)
        keep=OxmlElement('w:cantSplit');row._tr.get_or_add_trPr().append(keep)
    repeat=OxmlElement('w:tblHeader');t.rows[0]._tr.get_or_add_trPr().append(repeat)
    return t

def build():
    doc=Document();sec=doc.sections[0]
    sec.page_width=Inches(8.5);sec.page_height=Inches(11)
    sec.top_margin=sec.bottom_margin=Inches(.65);sec.left_margin=sec.right_margin=Inches(.75)
    normal=doc.styles['Normal'];normal.font.name='Calibri';normal.font.size=Pt(11)
    normal.paragraph_format.line_spacing=1.06;normal.paragraph_format.space_after=Pt(5)
    for name,size in [('Title',29),('Subtitle',12),('Heading 1',22),('Heading 2',13)]:
        st=doc.styles[name];st.font.name='Calibri';st.font.size=Pt(size);st.font.color.rgb=RGBColor(0,0,0)
        st.paragraph_format.space_after=Pt(5 if name=='Heading 2' else 9);st.paragraph_format.space_before=Pt(7 if name=='Heading 2' else 0)
    for i,page in enumerate(PAGES):
        if i:doc.add_page_break()
        doc.add_paragraph(page['title'],'Title' if i==0 else 'Heading 1')
        if page.get('subtitle'):doc.add_paragraph(page['subtitle'],'Subtitle')
        doc.add_paragraph(page['intro'])
        if i==0:table(doc,*page['table'],widths=[1.15,2.25,3.6])
        for title,paragraphs in page['sections']:
            doc.add_paragraph(title,'Heading 2')
            for text in paragraphs:doc.add_paragraph(text)
        if page.get('table') and i!=0:
            widths=[1.3,5.7] if len(page['table'][0])==2 else [1.0,2.7,3.3]
            table(doc,*page['table'],widths=widths)
    p=sec.footer.paragraphs[0];p.alignment=2
    r=p.add_run('Research Trail   |   ');r.font.size=Pt(9)
    fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');p._p.append(fld)
    doc.core_properties.title='Research Trail user guide';doc.core_properties.author='Research Trail team'
    doc.core_properties.subject='Quantum mechanics user journeys and four minute demonstration'
    for root in (doc.styles.element, doc.element):
        for border in list(root.iter(qn('w:pBdr'))):
            border.getparent().remove(border)
    doc.save(OUTPUT)
    (ROOT/'docs/user-guide.json').write_text(json.dumps({'question':QUESTION,'pages':PAGES},ensure_ascii=False,indent=2),encoding='utf-8')
    print(OUTPUT)

if __name__=='__main__':build()
