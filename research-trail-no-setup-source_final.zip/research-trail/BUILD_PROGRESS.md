# Quantum rebuild completed

Authorized scope: guide first, then the full QM semi-demo from the comprehensive design and later clarifications. User resumed the same task during implementation.

Completed: editable seven-page user guide; exact shared in-app flow; four-minute storyboard and narration; coherent Beginner/Intermediate/Advanced paths; persistent project; two Advanced entry billboards; all twelve tools; all eight lenses; venue regions; typed paper connections; larger beginner visuals; app-root fullscreen; notes, pinning and exports; model setup and custom agents; explicit Demo/Live separation.

Prepared corpus: twelve real source records, four short primary abstract excerpts and an isolated eight-record synthetic benchmark. Gap claims remain unvalidated; the demo does not certify novelty. Source policy is field-aware and displays ranking/access uncertainty.

Backend: merged uploaded run-source isolation and quote-normalization fixes while preserving numeric and provenance gates. Added journal-led profile, explicit source reuse, ranking events, open-question/landscape guide operations, scoped source API and SQLite concurrent source updates.

Verification: 48 Python tests passed; frontend, trail, visuals, demo and experience Node suites passed. Guide rendered into seven pages and every page inspected. Real-browser test blocked: Chromium absent. External model/retrieval services, PostgreSQL and Docker not verified. Final packaging and artifact persistence are tracked by the delivery operation.


Restored integration: original three-road landing and entry questions; physical billboard scenes; exactly three adaptive scope questions in Intermediate Explore; optional papers/context; Advanced upload then exact-question billboards. Direct same-document adapter shares project state, agent calls and evidence. Beginner Discover now uses intuition cards and Map uses literature. Intermediate node labels wrap and its orientation caption sits outside the SVG. Advanced keeps all 12 tools and eight lenses, including mobile navigation. Original billboard forms work through fullscreen transitions and preserve drafts. Guide and recording narration match the restored flow.
