"""Preserve the supplied roads and billboards, with a same-document workspace adapter."""
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parent
s=(ROOT/'static/trail.html').read_text(encoding='utf-8')
blocks=list(re.finditer(r'<script[^>]*>([\s\S]*?)</script>',s))
js=blocks[-1].group(1)
body=re.search(r'<body[^>]*>([\s\S]*?)</body>',s).group(1)
body=re.sub(r'<script[^>]*>[\s\S]*?</script>','',body)
body=re.sub(r'<style[^>]*>[\s\S]*?</style>','',body)
body=re.sub(r'<!--[\s\S]*?-->','',body)
styles=[m.group(1) for m in re.finditer(r'<style[^>]*>([\s\S]*?)</style>',s)][1:]
css='\n'.join(styles).replace((ROOT/'static/panels.css').read_text(encoding='utf-8'),'')
body=body.replace('<div id="research-trail-first-person">','<div id="research-trail-first-person" data-panel-title="Research trail billboard">',1)
body=body.replace('Three separate roads. Choose the one that fits where you are.','Three starting questions. Choose the path that fits where you are.')
body=body.replace('Find a topic you enjoy.<br>Get a pack to study it.','New to quantum mechanics?<br>Build your map of the field.')
body=body.replace('Bring your broad topic.<br>Find a specific direction.','Know an area of QM?<br>Follow the evidence toward a gap.')
body=body.replace('Bring your work.<br>Guide the final search.','Have papers or a question?<br>Explore every research view.')
body=body.replace('<div class="fp-heading"><h1>', '<div class="fp-heading"><span class="rt-badge">QUANTUM MECHANICS · YOUR RESEARCH TRAIL</span><h1>')
body=body.replace('Begin at Context','Begin with Papers').replace('Begin at Field','Begin with Discovery')
# Keep the three original entry statements and their route identities.
body=body.replace('<div class="rt-boardhead"><span id="rt-boardlabel">','<div class="rt-boardhead"><span id="rt-boardlabel">')
body=body.replace('<span id="rt-boardtype">Starting point</span></div>','<span id="rt-boardtype">Starting point</span><button class="expand-button" data-expand="research-trail-first-person" aria-label="Fullscreen current billboard" title="Fullscreen billboard">⛶</button></div>')
body=body.replace('<div class="fp-heading"><span', '<div class="fp-heading"><span',1)
body=body.replace('<p>Three starting questions. Choose the path that fits where you are.</p>', '<p>Three starting questions. Choose the path that fits where you are.</p><div class="trail-landing-actions"><button class="rt-button" data-action="start-quantum">Start quantum mechanics demo →</button><button class="rt-textbutton" data-action="resume-workspace">Continue my workspace ↗</button></div>')
js=js.replace("const ctx=canvas.getContext('2d');", "if(!canvas?.getContext)return null;\nlet ctx;try{ctx=canvas.getContext('2d')}catch{return null}if(!ctx)return null;")
js=js.replace("state.route=route;window.parent.postMessage({type:'research-trail:route',route},'*');", "state.route=route;config.onRoute?.(route);")
js=js.replace("window.parent.postMessage({type:'research-trail:field-map',brief:buildBrief()},'*')", "config.openFieldMap?.(buildBrief())")
js=js.replace("    root.querySelectorAll('.fp-active,.fp-trailhead,.rt-guide-panel,.rt-domain-canvas,.rt-topic-preview,.rt-paper-map').forEach(el=>el.setAttribute('data-panel',''));\n    window.ResearchPanels?.refresh(root,'trail-'+state.route+'-'+state.step);", "    root.dataset.panelTitle=initial?'Choose your way in':stepNames[state.step];\n    config.onStateChange?.(snapshot());")
js=js.replace("root.querySelector('#fp-walkstatus').textContent=initial?'Choose your own road':state.step===6?'End of the beginner road · time to learn':'Continue when you’re ready';", "root.querySelector('#fp-walkstatus').textContent=initial?'Choose your own road':state.step===6?'Your learning pack is ready · continue into the field map':'One useful decision at each billboard';")
js=js.replace("state.questions=result.questions.slice(0,6)", "state.questions=result.questions.slice(0,3)")
js=js.replace("Science: ['Physics', 'Biology', 'Chemistry'],", "'Physical sciences': ['Quantum mechanics', 'Physics', 'Chemistry'],\n    Science: ['Biology', 'Earth science'],")
js=js.replace("placeholder='For example: computer engineering'", "placeholder='For example: quantum mechanics'")
js=js.replace('For example: computer engineering','For example: quantum mechanics').replace('For example: adaptive edge AI','For example: open quantum systems')
js=js.replace("['Efficient neural hardware','Battery degradation','Medical AI','Robotic manipulation']", "['Open systems and decoherence','Entanglement','Quantum simulation','Quantum measurement']")
js=js.replace('e.g. quantum mechanics or efficient neural network hardware','e.g. quantum mechanics or quantum error mitigation')
js=js.replace("${uploads('papers','Choose your starting papers · PDF')}", "${uploads('papers','Choose your starting papers · PDF')}${config.hasCurrentPapers?.()?button('Use my current project papers','current-project-papers'):''}")
js=js.replace("if(!files.papers.size&&!state.samplePack){", "if(!files.papers.size&&!state.samplePack&&!config.hasCurrentPapers?.()){")
js=js.replace("    if(b.dataset.removeFile){", "    if(b.dataset.action==='current-project-papers'){await prepareAdvancedPapers();return;}\n    if(b.dataset.removeFile){",1)
# The new demo is QM throughout; preserve the original upload billboard with one complete pack.
start=js.find('<button type="button" class="rt-demo-pack" data-demo-pack="hardware">')
if start>=0:
    end=js.index('</button>',start)+len('</button>');js=js[:start]+js[end:]
js=js.replace("    if(b.dataset.removeFile){", "    if(b.dataset.action==='start-quantum'){await window.ResearchTrail.startRoute('discover');return;}\n    if(b.dataset.action==='resume-workspace'){config.openWorkspace?.();return;}\n    if(b.dataset.removeFile){")
# Keep original in-scene controls; adapters own the corpus and the project.
js=js.replace("function changed() { state.revision++;", "function changed() { state.revision++;")
js=js.replace("state.retryable=false; }\n  function fileMetadata", "state.retryable=false; config.onDraftChange?.(snapshot()); }\n  function fileMetadata")
js=js.replace("function chooseRoute(route) {", "function chooseRoute(route,options={}) {")
js=js.replace("state.history=[0];state.broad='';state.error='';state.retryable=false;lastTask=null;\n    if(route==='topic')state.narrowPhase='entry';", "if(!options.resume){state.history=[0];state.broad='';if(route==='topic')state.narrowPhase='entry';}state.error='';state.retryable=false;lastTask=null;")
old="async startRoute(route,options={}){if(!routeConfig[route])return;await returnToTrail();chooseRoute(route);if(options.topic&&!state.specificTopic)state.specificTopic=options.topic;if(options.field&&!state.field)state.field=options.field;await go(routeConfig[route].entry);},"
new="""async startRoute(route,options={}){if(!routeConfig[route])return;await returnToTrail();chooseRoute(route,options);if(options.topic&&!state.topic)state.topic=options.topic;if(options.field&&!state.field)state.field=options.field;if(options.notes&&!state.notes)state.notes=options.notes;if(options.instructions&&!state.instructions)state.instructions=options.instructions;if(route==='papers'&&options.question&&!state.exactQuestion)state.exactQuestion=options.question;await go(options.resume&&state.step>0?state.step:routeConfig[route].entry);},
    getSnapshot:snapshot,
    getStatus:()=>({step:state.step,route:state.route,busy:!!state.busy,walking,error:state.error,questionIndex:state.questionIndex,questionCount:state.questions.length,narrowPhase:state.narrowPhase,contextPhase:state.contextPhase}),
    async showTrailhead(){cancelRequest();await returnToTrail();await go(0);},
    restore(value){if(!value)return;cancelRequest();routeDrafts.clear();for(const [route,draft]of value.drafts||[])routeDrafts.set(route,{state:JSON.stringify(draft),profile:new Map(),papers:new Map()});Object.assign(state,JSON.parse(initialState),value.current||{}, {busy:null,error:'',retryable:false,graphOpen:false});files.profile.clear();files.papers.clear();render();},
    async reset(){cancelRequest();routeDrafts.clear();files.profile.clear();files.papers.clear();Object.assign(state,JSON.parse(initialState));await returnToTrail();render();},"""
assert old in js
js=js.replace(old,new)
marker='  /* [PUBLIC API]'
helper="""  function snapshot(){const safe=value=>JSON.parse(JSON.stringify(value,(key,v)=>key==='pages'||key==='busy'||key==='job'?undefined:v));return {current:safe({...state,busy:null,job:null,graphOpen:false}),drafts:[...routeDrafts].map(([route,draft])=>[route,safe(JSON.parse(draft.state))])};}
"""
js=js.replace(marker,helper+marker)
js=js.replace('  journeyWorld=createWorld();\n  render();','  journeyWorld=createWorld();\n  if(config.initialSnapshot)window.ResearchTrail.restore(config.initialSnapshot);else render();')
js=js.replace("  function icons() { window.lucide?.createIcons({attrs:{width:17,height:17}}); }", "  function icons(){for(const el of root.querySelectorAll('[data-lucide]')){el.textContent=({compass:'◉',telescope:'⌕',files:'▤',route:'∿','message-circle':'?'}[el.dataset.lucide]||'◇');el.setAttribute('aria-hidden','true');}}")
begin=js.index('<div class="rt-domain-canvas"><svg')
end=js.index('</svg></div>',begin)+len('</svg></div>')
js=js[:begin]+'<div class="rt-domain-canvas">${window.TrailCanvas.fieldMap(state.topics,current?.id,{edges:config.simulation?window.QuantumTrail.prerequisites:[]}).replaceAll("data-concept","data-visual-topic")}</div>'+js[end:]
(ROOT/'static/trail-markup.html').write_text(body,encoding='utf-8')
(ROOT/'static/trail-base.css').write_text(css,encoding='utf-8')
(ROOT/'static/trail-flow.js').write_text(js,encoding='utf-8')
print('Restored original road scene, three entry signs and billboard flow without an iframe.')
