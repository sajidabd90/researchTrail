"""Package the reviewed demo source; exclude runtime data and QA screenshots."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
ROOT=Path(__file__).resolve().parent
OUTPUT=ROOT.parent/'research-trail-no-setup-source.zip'

def package():
    names=['LICENSE','LICENSE-LUCIDE.txt','README.md','DESIGN.md','ARCHITECTURE.md',
           'DEPLOYMENT.md','THIRD_PARTY_NOTICES.md','BUILD_PROGRESS.md','build.py','package.py',
           'restore_trail.py','requirements.txt','requirements-postgres.txt','Dockerfile',
           'compose.yaml','start.sh','start.bat','qa/verification.json']
    for folder,patterns in [('backend',['*.py']),('tests',['*.py','*.cjs']),
                            ('config',['*.json','*.gz','*.yml']),('docs',['*.py','*.json'])]:
        names.extend(str(p.relative_to(ROOT)) for pattern in patterns for p in (ROOT/folder).glob(pattern))
    names.extend('static/'+n for n in ['index.html','app.template.html','workspace.js','workspace.css',
        'visuals.js','canvas.js','quantum-data.js','demo-provider.js','trail-markup.html',
        'trail-base.css','trail-flow.js','trail-adapter.js','trail-merge.css','trail.html','panels.css'])
    with ZipFile(OUTPUT,'w',ZIP_DEFLATED) as archive:
        for name in sorted(set(names)):
            archive.write(ROOT/name,'research-trail/'+name)
        archive.write(ROOT.parent/'research-trail-user-guide.docx','research-trail/docs/user-guide.docx')
    print(f'Packaged {len(set(names))+1} files: {OUTPUT} ({OUTPUT.stat().st_size:,} bytes)')
if __name__=='__main__':package()
