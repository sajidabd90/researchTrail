"""Build a dependency-free browser demo from the supplied trail and source views."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def embedded_bridge():
    return '''<script>
(()=>{
const report=()=>{if(window.parent!==window)window.parent.postMessage({type:'research-trail:height',height:Math.ceil(document.body.getBoundingClientRect().height)},'*');};
if(typeof ResizeObserver!=='undefined')new ResizeObserver(report).observe(document.body);
window.addEventListener('load',report);
window.addEventListener('message',e=>{if(e.source!==window.parent)return;if(e.data?.type==='research-trail:theme')document.documentElement.dataset.theme=e.data.theme;});
})();
</script>'''


def build():
    static = ROOT / 'static'
    trail = (static / 'trail.html').read_text()
    atlas = (static / 'atlas.html').read_text()
    atlas = atlas.replace('</head>', '<style>body{padding:0;margin:0}</style></head>')
    atlas = atlas.replace('</body>', embedded_bridge() + '</body>')
    lenses = (static / 'gap-studio.html').read_text()
    lenses = lenses.replace('</head>', '<style>.shell{min-height:0!important}body{margin:0;padding:0}</style></head>')
    needle = "saved.push({...q,id:'Q'+Date.now().toString(36),view:state.view,created:new Date().toISOString()});"
    assert needle in lenses
    lenses = lenses.replace(needle, needle + "if(window.parent!==window)window.parent.postMessage({type:'research-trail:question',question:q.question,view:state.view},'*');")
    needle = 'renderNav();setSavedCount();renderView();'
    assert needle in lenses
    lenses = lenses.replace(needle, "window.addEventListener('message',e=>{if(e.source===window.parent&&e.data?.type==='research-trail:lens'&&views.some(v=>v.id===e.data.view))navigate(e.data.view)});" + needle)
    lenses = lenses.replace('</body>', embedded_bridge() + '</body>')
    payload = json.dumps({'trail': trail, 'atlas': atlas, 'lenses': lenses}, ensure_ascii=False).replace('<', '\\u003c')
    seeds = (ROOT / 'config' / 'seed_sources.json').read_text().replace('<', '\\u003c')
    template = (static / 'app.template.html').read_text()
    assert template.count('__EMBEDS__') == template.count('__SEEDS__') == 1
    result = template.replace('__EMBEDS__', payload).replace('__SEEDS__', seeds)
    result = result.replace('</head>', '<!-- Bundled Lucide / Feather license notices:\n' + (ROOT / 'LICENSE-LUCIDE.txt').read_text() + '\n--></head>', 1)
    (static / 'index.html').write_text(result)
    (ROOT.parent / 'research-trail-complete-demo.html').write_text(result)
    print(f'Built standalone demo: {len(result.encode()):,} bytes')


if __name__ == '__main__':
    build()
