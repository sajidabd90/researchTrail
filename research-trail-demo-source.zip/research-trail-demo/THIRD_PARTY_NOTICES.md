# Attribution and source boundaries

The new coordinator backend, integration layer and workspace code are supplied under the accompanying MIT license. The user-provided `research-trail-routes.html` remains the original landing design and is integrated through a small route handoff; its existing attribution is preserved.

The landing file embeds Lucide v1.8.0 and declares the ISC license in its source. Its bundled license notice is retained. Lucide project: https://github.com/lucide-icons/lucide — license: https://github.com/lucide-icons/lucide/blob/main/LICENSE

`pypdf` is an external open-source dependency; its own package license applies. Optional `psycopg` and its binary distribution retain their own licenses. PostgreSQL, Python, Docker images, model servers and model weights are external components, not relicensed by this project.

The seed library contains bibliographic metadata, original editorial summaries and external links. It does not contain the full text of papers or textbooks. Repository metadata is not a redistribution of repository source code. The example ranking registry deliberately contains no ranking dataset.

Uploaded PDF text belongs to the project's supplied corpus. It is not included in this distribution. Review exports can include user-requested indexed quotations; original PDF files are not exported automatically.
