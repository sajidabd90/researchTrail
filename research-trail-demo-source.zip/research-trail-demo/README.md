# Research Trail — integrated semi-demo

A guided workspace for understanding a research field, building a review background, connecting evidence, investigating candidate gaps, and optionally planning a first experiment.

## Open the demonstration

Open `static/index.html` in Chrome or Edge. It works without installation or a model. The supplied first-person trail is the landing page. Its discovery, topic and papers routes hand off into the same research workspace.

The separate `research-trail-complete-demo.html` deliverable is the same self-contained build.

The browser demonstration includes the original literature atlas, all eight interactive gap lenses, a reading ledger, conference selection, source policy, review notes, candidate questions, a skeptical-check example, experiment proposals, agent activity and model-role configuration.

**Replay is explicitly labelled.** It makes no inference or live search calls. The eight lens charts use fictional annotations and synthetic benchmarks, separately from the real linked source records. Their saved questions are transferred as unvalidated hypotheses, never as literature evidence.

## Run the real workflow

Requires Python 3.11+ and a model server you provide. On Windows, run `start.bat`. On macOS/Linux, run `bash start.sh`. The scripts create a local environment, install `pypdf`, and start the backend. Alternatively:

```sh
python -m venv .venv
# macOS/Linux:
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m backend.server
# Windows: use .venv\Scripts\python.exe for the last two commands.
```

Open the printed local URL. The served page connects automatically to its local backend. In **Team compute**, assign the actual served model name and endpoint to the coordinator and specialists. Use **Copy coordinator route to all** to share one small model, or mix model sizes and providers by role. Test a connection, then start live mode.

For the standalone HTML, enter the backend URL and the access token printed in the terminal. The inference URL is resolved **from the backend/worker**, not from the user's browser.

Supported adapters:

- Ollama native: `/api/chat`, non-streaming JSON output.
- Chat-compatible serving such as vLLM or llama.cpp: `/v1/chat/completions`, JSON-object output.

No model is downloaded, quantized or rented automatically. Supply a model with a license appropriate to your deployment. Provider credentials are read on the server from `MODEL_API_KEY` or `MODEL_API_KEY_<ROLE>`; do not embed them in model URLs. Backend access tokens stay in the browser session and are excluded from review exports and persisted preferences.

## The hierarchical live workflow

1. The coordinator plans a review from the topic, objective, and optional starting idea.
2. The scout looks up books and older work. The reader creates a foundation draft from available evidence.
3. The run **pauses** for conference selection. Users can choose known venues, accept scout suggestions, or explicitly broaden the field search.
4. Recent conference retrieval and reading happen first; journal retrieval and reading follow.
5. Repository metadata supplies implementation context, including stars, actual subscribers, license metadata and retrieval date.
6. The mapper builds relationships; optional custom specialists investigate bounded tasks; the investigator proposes questions.
7. A targeted counter-search and skeptical review challenge the proposals. The coordinator synthesizes the review. The optional planner proposes, but does not run, an experiment.

Discovery-route users have a separate beginner search entry. Topic and papers routes do not expose that search UI. Specialist retrieval still serves all routes.

## Expert PDFs and evidence

The backend supports up to 15 unique PDFs per project, 10 MiB each, and 250 pages per document. Extraction runs in a separate process with a timeout and resource limits where supported. Text and page numbers are indexed; original PDF bytes are not retained by this prototype. Scanned pages need external OCR.

The reader receives bounded, relevant excerpts rather than all 15 documents at once. A proposed quotation is checked against the indexed source and page. Unsupported claims are separated; invented citations are rejected. This verifies provenance only: matching words do not prove entailment, study quality, consensus, or novelty.

Switch off **Expand beyond my starting papers** for a corpus-limited workflow. The scope is carried into the review export.

## Source scope and ranking

Live public retrieval currently uses Crossref deposited metadata/available abstracts and GitHub repository metadata. It does not provide complete conference coverage, scrape paywalls, fetch arbitrary full-text URLs, or independently determine A*/A/B or journal quartiles. For example, conference papers without suitable Crossref records may be missed.

Strict venue eligibility is on by default. Load a registry with **Conference scope → Ranking registry**. Records must state the venue name, publication year, tier/quartile, and source URL. Rankings are recorded as supplied assertions. Exact venue-name matching and publication-year matching are intentional. Unknown ranks remain quarantined. The included example registry is empty; no ranking data is fabricated or bundled.

Open access, a venue's rank, full-text ingestion, and methodological quality are separate. A metadata record is not a claim that the full paper has been read or can be redistributed. Textbooks are reading links, not copied books. A public repository with unknown license metadata remains unconfirmed as an open-source implementation.

## Deployment profiles

- **Local/small lab:** one process, SQLite, a local quantized model server.
- **Shared group:** PostgreSQL, separate job workers, independently deployed inference servers.
- **Rented inference:** the same adapters point to endpoints controlled by the team; roles may use different model sizes.

See [ARCHITECTURE.md](ARCHITECTURE.md) and [DEPLOYMENT.md](DEPLOYMENT.md). The code is a working prototype, not a claim of production-scale operation. SQLite and local HTTP/PDF workflows were tested here. A live external model endpoint and PostgreSQL deployment were not available for end-to-end integration testing.

## Validation and development

```sh
python build.py
python -m unittest discover -s tests -p "test_*.py" -v
node tests/frontend.cjs
```

The frontend test uses a lightweight DOM harness; it is not a browser screenshot test. Test coverage includes real PDF extraction over HTTP, citation rejection, phase ordering, the venue pause, failure handling, bounded model context, queue claims, adapters, custom specialists, route visibility, question handoff and review export.

The new application code is MIT-licensed. The supplied trail and bundled icon notices retain their original attribution. No model weights, papers, paid services or private documents are included.
