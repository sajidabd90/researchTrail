"""Run with: python -m backend.server. Optional separate workers: --worker-only."""
from __future__ import annotations

import argparse
import base64
import hmac
import json
import multiprocessing
import os
import queue
import re
import secrets
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

from .core import ROOT, ModelClient, Runner, Store, read_pdf_bytes, uid, validate_config


def extraction_child(output, name, data):
    try:
        try:
            import resource
            resource.setrlimit(resource.RLIMIT_AS, (900 * 1024 * 1024, 900 * 1024 * 1024))
            resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
        except (ImportError, ValueError, OSError):
            pass
        output.put({'ok': True, 'source': read_pdf_bytes(name, data)})
    except Exception as e:
        output.put({'ok': False, 'error': str(e)[:400]})


def extract_isolated(name, data):
    ctx = multiprocessing.get_context('spawn')
    output = ctx.Queue()
    process = ctx.Process(target=extraction_child, args=(output, name, data))
    process.start()
    try:
        result = output.get(timeout=45)
        if not result['ok']:
            raise ValueError(result['error'])
        return result['source']
    except queue.Empty:
        raise ValueError('PDF extraction timed out or exceeded the resource limit') from None
    finally:
        process.join(timeout=2)
        if process.is_alive():
            process.terminate()
            process.join(timeout=2)
        output.close()


def worker_loop(store, stop, once=False):
    runner, owner = Runner(store), uid('worker_')
    while not stop.is_set():
        task = store.claim(owner)
        if task:
            runner.process(task)
        elif once:
            return
        else:
            stop.wait(.75)
        if once:
            return


def make_handler(store, api_token, bind_host='127.0.0.1'):
    class Handler(BaseHTTPRequestHandler):
        server_version = 'ResearchTrail/0.1'

        def log_message(self, message, *args):
            # Paths only; model credentials and uploaded content never enter request logs.
            print(f'{self.address_string()} {message % args}')

        def valid_host(self):
            if bind_host in ('127.0.0.1', 'localhost', '::1'):
                host = self.headers.get('Host', '').split(':')[0]
                return host in ('127.0.0.1', 'localhost', '[::1]')
            return True

        def authorized(self):
            token = self.headers.get('Authorization', '')
            return hmac.compare_digest(token, 'Bearer ' + api_token)

        def workspace(self):
            value = self.headers.get('X-Workspace-ID', '')
            if not re.fullmatch(r'[a-zA-Z0-9_-]{6,80}', value):
                raise ValueError('A valid workspace ID header is required')
            return value

        def send_json(self, code, value):
            raw = json.dumps(value, ensure_ascii=False).encode()
            self.send_response(code)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(raw)))
            self.send_header('Cache-Control', 'no-store')
            origin = self.headers.get('Origin')
            allowed = ['null', 'http://localhost:8765', 'http://127.0.0.1:8765'] + os.environ.get('TRAIL_ALLOWED_ORIGINS', '').split(',')
            if origin in allowed:
                self.send_header('Access-Control-Allow-Origin', origin)
                self.send_header('Vary', 'Origin')
            self.end_headers()
            self.wfile.write(raw)

        def do_OPTIONS(self):
            self.send_response(204)
            origin = self.headers.get('Origin', '')
            allowed = ['null', 'http://localhost:8765', 'http://127.0.0.1:8765'] + os.environ.get('TRAIL_ALLOWED_ORIGINS', '').split(',')
            if origin in allowed:
                self.send_header('Access-Control-Allow-Origin', origin)
            self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Workspace-ID')
            self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
            self.end_headers()

        def do_GET(self):
            if not self.valid_host():
                return self.send_json(403, {'error': 'Host header rejected'})
            path = urlsplit(self.path).path
            if path == '/api/health':
                if not self.authorized():
                    return self.send_json(401, {'error': 'Backend access token required'})
                return self.send_json(200, {'ok': True, 'version': '0.1.0', 'database': 'postgresql' if store.pg else 'sqlite', 'modes': ['live'], 'pdf_limit': 15})
            if path.startswith('/api/'):
                if not self.authorized():
                    return self.send_json(401, {'error': 'Backend access token required'})
                try:
                    ws = self.workspace()
                    if path == '/api/sources':
                        sources = store.sources(ws)
                        return self.send_json(200, {'sources': sources})
                    match = re.fullmatch(r'/api/runs/(run_[a-f0-9]+)', path)
                    if match:
                        return self.send_json(200, store.run(ws, match[1]))
                    return self.send_json(404, {'error': 'API route not found'})
                except (ValueError, KeyError) as e:
                    return self.send_json(400, {'error': str(e)})
            # Serve only shipped frontend HTML, never configuration, uploads or the database.
            if path in ('/', '/index.html'):
                file = ROOT / 'static' / 'index.html'
            elif path in ('/trail.html', '/atlas.html', '/gap-studio.html'):
                file = ROOT / 'static' / path.lstrip('/')
            else:
                return self.send_json(404, {'error': 'Page not found'})
            raw = file.read_text()
            if path in ('/', '/index.html') and bind_host in ('127.0.0.1', 'localhost', '::1'):
                bootstrap = json.dumps({'endpoint': f'http://{self.headers.get("Host")}', 'token': api_token}).replace('<', '\\u003c')
                raw = raw.replace('<head>', '<head><script>window.__TRAIL_BOOTSTRAP__=' + bootstrap + ';</script>', 1)
            body = raw.encode()
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            self.wfile.write(body)

        def do_POST(self):
            if not self.valid_host() or not self.authorized():
                return self.send_json(401, {'error': 'Backend access token required'})
            try:
                length = int(self.headers.get('Content-Length', '0'))
                if not 0 < length <= 64 * 1024 * 1024:
                    raise ValueError('JSON request must be at most 64 MiB; split large PDF batches')
                body = json.loads(self.rfile.read(length))
                if not isinstance(body, dict):
                    raise ValueError('Expected a JSON object')
                ws, path = self.workspace(), urlsplit(self.path).path
                if path == '/api/init':
                    store.seed(ws, bool(body.get('hardware', True)))
                    return self.send_json(200, {'sources': store.sources(ws)})
                if path == '/api/provider/test':
                    role = body.get('role', {})
                    agent_role = str(body.get('agent_role', 'coordinator'))
                    if not re.fullmatch(r'[a-z][a-z0-9_]{1,24}', agent_role):
                        raise ValueError('Invalid agent role')
                    config = validate_config({'topic': 'Connection test', 'route': 'topic', 'roles': {'coordinator': role}})
                    began = time.monotonic()
                    output = ModelClient().call(agent_role, config['roles']['coordinator'], 'Return a short JSON connection acknowledgement. No research claims.', {'sources': [], 'excerpts': []})
                    return self.send_json(200, {'ok': True, 'model': role['model'], 'latency_ms': round((time.monotonic() - began) * 1000), 'summary': output['summary']})
                if path == '/api/upload':
                    files = body.get('files', [])
                    if not isinstance(files, list) or not 1 <= len(files) <= 15:
                        raise ValueError('Upload between 1 and 15 PDFs')
                    existing = [s for s in store.sources(ws) if s.get('kind') == 'upload']
                    results = []
                    for f in files:
                        try:
                            name = Path(str(f['name'])).name[:200]
                            data = base64.b64decode(f['data'], validate=True)
                            source = extract_isolated(name, data)
                            if source['id'] not in {s['id'] for s in existing} and len(existing) >= 15:
                                raise ValueError('This project already contains 15 PDFs')
                            store.put_source(ws, source)
                            if source['id'] not in {s['id'] for s in existing}:
                                existing.append(source)
                            results.append({'ok': True, 'source': source})
                        except Exception as e:
                            results.append({'ok': False, 'name': str(f.get('name', 'PDF')), 'error': str(e)[:400]})
                    return self.send_json(200, {'results': results})
                if path == '/api/runs':
                    config = validate_config(body.get('config', {}))
                    return self.send_json(201, store.create_run(ws, config))
                match = re.fullmatch(r'/api/runs/(run_[a-f0-9]+)/(resume|cancel)', path)
                if match:
                    if match[2] == 'resume':
                        return self.send_json(200, store.resume(ws, match[1], body.get('venues', []), body.get('config_patch', {})))
                    store.cancel(ws, match[1])
                    return self.send_json(200, {'ok': True})
                return self.send_json(404, {'error': 'API route not found'})
            except (ValueError, KeyError, TypeError, json.JSONDecodeError) as e:
                return self.send_json(400, {'error': str(e)[:400]})
            except Exception as e:
                return self.send_json(502, {'error': type(e).__name__ + ': ' + str(e)[:400]})
    return Handler


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--workers', type=int, default=1)
    parser.add_argument('--worker-only', action='store_true')
    parser.add_argument('--recover-stale', action='store_true')
    args = parser.parse_args()
    token = os.environ.get('TRAIL_API_TOKEN', '')
    if args.host not in ('127.0.0.1', 'localhost', '::1') and not token:
        parser.error('Set TRAIL_API_TOKEN before exposing a team server')
    token = token or secrets.token_urlsafe(32)
    store, stop = Store(), threading.Event()
    if args.recover_stale:
        store.recover()
    if args.worker_only:
        try:
            worker_loop(store, stop)
        except KeyboardInterrupt:
            stop.set()
        return
    if not 0 <= args.workers <= 16:
        parser.error('--workers must be 0–16')
    for _ in range(args.workers):
        threading.Thread(target=worker_loop, args=(store, stop), daemon=True).start()
    httpd = ThreadingHTTPServer((args.host, args.port), make_handler(store, token, args.host))
    print(f'Research Trail: http://{args.host}:{args.port}')
    print('Open the served page for automatic local connection. For the standalone file, enter this backend token:')
    print(token)
    print('No inference server is started automatically. Configure served models in Team compute.')
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        stop.set()
        httpd.server_close()


if __name__ == '__main__':
    multiprocessing.freeze_support()
    main()
