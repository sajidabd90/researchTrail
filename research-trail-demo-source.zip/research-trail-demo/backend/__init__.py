"""Research Trail: provider-neutral, evidence-grounded workflow."""
