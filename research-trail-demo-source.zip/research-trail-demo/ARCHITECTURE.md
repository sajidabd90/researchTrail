# Architecture and extension points

## Shared contract

The frontend is a self-contained browser application. It keeps notes, route preferences, model routes and candidate questions locally. Uploaded page text and live outputs remain in the active page/backend project; they are not added to browser preference storage. Exporting the review explicitly includes the notes and source quotations selected by that report.

The Python backend supplies authenticated JSON endpoints, page-level PDF extraction, a durable source store, a durable job queue, model adapters and the bounded research workflow. It uses the standard library plus `pypdf`. PostgreSQL deployments additionally use `psycopg`.

Each model role returns structured JSON: a summary, notes, claims, taxonomy, edges, candidates, optional experiments, venue suggestions and an advisory plan. The coordinator proposes the plan and synthesizes the results. The controller enforces the required stage order; it does not execute arbitrary model-authored code or shell commands.

## Agents

| Role | Responsibility |
|---|---|
| coordinator | Plan the review, maintain its objective and synthesize the evidence and limitations. |
| scout | Discover books, older papers, recent conferences, journals and repository metadata; propose venues. |
| reader | Build background, extract supported claims and distinguish metadata from source text. |
| mapper | Produce a taxonomy and typed, source-linked relationships. |
| gaps | Propose focused, unvalidated research questions. |
| skeptic | Seek prior art/counterexamples and avoid unsupported novelty verdicts. |
| experiment | Propose a small controlled experiment; do not execute it. |

Up to three custom specialists can be registered in the interface. Their prompts execute after mapping and before gap investigation. They inherit the same output and evidence contract and can be assigned their own inference endpoint.

## Evidence and metadata

Sources retain their type, URL/DOI, year, venue, rank status, eligibility, provenance, and indexed pages where available. Metadata-only records have no pages. Deposited abstracts use locator/page `0`; uploaded PDFs use physical page numbers starting at `1`.

The excerpt selector scores keyword overlap and preserves source diversity within a configured character budget. This is a deliberately small retrieval implementation, not an embedding index or a guarantee that all relevant passages were found. The final evidence payload is bounded after prior summaries and candidate questions are added. Model-specific tokenization and server context limits still need operator configuration.

The validator checks that the source exists, is eligible or user-provided, the page exists, and the quoted text matches normalized whitespace in that page. It separates unsupported claims and rejects bad citations. Inferred edges remain inferred. All candidate questions remain unvalidated. Passage matching does not establish entailment or novelty.

## Queue and scale

API and workers share the `Store` interface. SQLite uses transactions and `BEGIN IMMEDIATE` for single-host queue claims. PostgreSQL uses `FOR UPDATE SKIP LOCKED`, allowing multiple worker processes to claim different jobs.

Sources, job configuration, outputs and events live in the shared database; there is no required worker-local PDF filesystem. A worker executes one job at a time. More workers increase concurrent reviews; inference capacity must be provisioned separately. Task boundaries are observable. Cancellation takes effect between tasks; an in-flight model request may finish.

Jobs pause in `awaiting_venues` until a user confirms the conference allowlist or explicitly chooses a broader field scope. The pause can update the source policy and supplied rank registry. Explicit stale-job recovery is available with `--recover-stale`; it may re-run prior tasks and should be treated as at-least-once execution.

## What is still a semi-demo

- The supplied first-person trail is integrated through a route/context handoff.
- The existing atlas is a linked hardware seed example. Live mapper output has a separate project-source graph.
- The eight lens charts retain their explicitly synthetic corpus. They do not recalculate from arbitrary uploaded PDFs. Questions can be saved into the main workspace as hypotheses with no fictional evidence attached.
- The beginner search is a local foundation guide. Public specialist retrieval is implemented in the backend.
- Automated venue-rank discovery/verification, robust semantic entailment, systematic-review completeness, OCR and arbitrary full-text connectors remain extensions.
- Shared-token access and project namespaces are not organization identity, role-based authorization, or per-user privacy. Use separate team deployments and an authenticated gateway until a real identity/authorization layer is implemented.
- PostgreSQL support and deployment files are included but were not integration-tested against a running PostgreSQL instance here. External inference was tested through adapter contract stubs, not live model weights.

## Official protocol references

- [Ollama chat endpoint](https://docs.ollama.com/api/chat)
- [vLLM online serving](https://docs.vllm.ai/en/latest/serving/online_serving/)
- [Crossref REST API](https://www.crossref.org/documentation/retrieve-metadata/rest-api/)
- [GitHub stars versus watchers](https://docs.github.com/en/rest/activity/watching)
- [pypdf text extraction and OCR limitations](https://pypdf.readthedocs.io/en/stable/user/extract-text.html)
- [psycopg transactions](https://www.psycopg.org/psycopg3/docs/basic/transactions.html)
