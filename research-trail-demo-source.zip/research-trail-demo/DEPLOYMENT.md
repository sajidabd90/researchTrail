# Running locally or for a team

## One computer

Use `start.bat` on Windows or `bash start.sh` on macOS/Linux. The backend binds to `127.0.0.1:8765` and creates a random access token if `TRAIL_API_TOKEN` is not set. Its locally served page receives a bootstrap connection; standalone-file users can copy the printed token into Team compute.

Start your own inference server separately. In Team compute, assign its actual served model name and backend-reachable URL. Small teams may use one model for every role and one worker. Quantization, supported hardware and memory requirements belong to the selected inference server/model combination; no universal requirement is assumed.

The default database is `data/trail.sqlite`. Keep that directory private and back it up if you need durable sources and job history. Browser notes and preferences are separate from the backend store.

## PostgreSQL and independent workers

Install `requirements-postgres.txt`, set `DATABASE_URL` to a PostgreSQL connection string, and use the same value for the API and workers:

```sh
python -m backend.server --host 0.0.0.0 --workers 0
python -m backend.server --worker-only
```

Set a strong `TRAIL_API_TOKEN` before exposing a non-loopback API. Add the exact frontend origin to `TRAIL_ALLOWED_ORIGINS` if it is hosted separately. Model keys belong in server environment variables `MODEL_API_KEY` or `MODEL_API_KEY_<ROLE>` (for example `MODEL_API_KEY_READER`), never in the frontend or a committed file.

The included `compose.yaml` demonstrates an API, PostgreSQL, and independent workers. Set `TRAIL_API_TOKEN` and `POSTGRES_PASSWORD` in a local `.env` file, then build/start with Docker Compose. You can scale the worker service independently:

```sh
docker compose up --build --scale worker=2
```

Containers must be able to reach the model URL entered in the interface. A worker's `localhost` is that worker container, not a user's laptop. Use an internal service name, routable host address or the team's rented HTTPS inference endpoint as appropriate.

This deployment template does not start a model server or rent hardware. Configure GPU scheduling, model licenses, endpoint credentials, and provider usage limits separately.

## Before a shared production deployment

The prototype uses a shared team access token and project namespaces. It does not implement organization login, RBAC, per-user authorization, quotas, comprehensive audit controls or an internet-facing hardened gateway. Keep team deployments separate, protect the service behind organization authentication, and add those controls before handling multi-tenant/private institutional workloads.

Use TLS at the gateway, a private PostgreSQL network, controlled model endpoints, a backup policy, and explicit resource/concurrency budgets. PDF extraction has size/page/time limits and a separate process; this is not a complete hostile-document sandbox.

The PostgreSQL adapter and Compose template are reviewable implementation artifacts. They were not exercised against a live database/container engine in this build environment.
